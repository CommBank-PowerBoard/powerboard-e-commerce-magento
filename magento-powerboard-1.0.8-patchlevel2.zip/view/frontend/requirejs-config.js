var config = {
    map: {
        '*': {
            'CartObserver': 'Paydock_Powerboard/js/cart-observer',
            'Magento_Checkout/js/action/get-payment-information': 'Paydock_Powerboard/js/action/get-payment-information',
            'Magento_Checkout/js/model/place-order': 'Paydock_Powerboard/js/view/checkout/place-order',
            'WalletMetaValidator': 'Paydock_Powerboard/js/wallet-meta-validator'
        }
    },
    config: {
        mixins: {
            'Magento_Checkout/js/action/set-shipping-information': {
                'Paydock_Powerboard/js/action/set-shipping-information-mixin': true
            },
            'Magento_Checkout/js/model/quote': {
                'Paydock_Powerboard/js/quote-mixin': false
            }
        }
    }
};
