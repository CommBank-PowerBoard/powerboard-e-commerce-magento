define([
    'ko',
    'Magento_Checkout/js/checkout-data',
    'Magento_Checkout/js/model/quote'
], function (
    ko,
    checkoutData,
    quote
) {
    var isValidObservable = ko.observable(false);

    function validateWalletMeta() {
        const inputFieldEmail = window.checkoutConfig.quoteData.customer_email || checkoutData.getInputFieldEmailValue() || "";
        if (!inputFieldEmail) {
            isValidObservable(false);
            return;
        }

        const validatedEmailValue = window.checkoutConfig.quoteData.customer_email || checkoutData.getValidatedEmailValue() || "";
        if (!validatedEmailValue) {
            isValidObservable(false);
            return;
        }

        const address = window.checkoutConfig.quoteData.customer_email ? quote.shippingAddress() : checkoutData.getShippingAddressFromData();
        if (!address || !address.street  || address.street.length === 0 || !address.street[0]) {
            isValidObservable(false);
            return;
        }

        const selectedShippingMethod = quote.shippingMethod();
        if (!selectedShippingMethod) {
            isValidObservable(false);
            return;
        }

        const hasAllRequiredValues = [
            address.firstname?.trim(),
            address.lastname?.trim(),
            address.street[0]?.trim(),
            address.city?.trim(),
            address.regionId?.trim() || address.region_id?.trim() || address.region?.trim(),
            address.postcode?.trim(),
            address.countryId?.trim() || address.country_id?.trim(),
            address.telephone?.trim(),
            window.checkoutConfig.quoteData.store_id,
            window.checkoutConfig.payment.paydockAfterPay.storeName,
            window.checkoutConfig.quoteData.base_currency_code?.trim(),
            inputFieldEmail?.trim(),
            validatedEmailValue?.trim(),
            selectedShippingMethod["method_code"]?.trim()
        ].every(Boolean);

        if (hasAllRequiredValues) {
            const isValid = [
                address.firstname.trim(),
                address.lastname.trim(),
                address.street[0]?.trim(),
                address.city.trim(),
                address.regionId?.trim() || address.region_id?.trim() || address.region?.trim(),
                address.postcode.trim(),
                address.countryId?.trim() || address.country_id?.trim(),
                address.telephone.trim(),
                inputFieldEmail.trim() === validatedEmailValue.trim(),
                selectedShippingMethod["method_code"]?.trim()
            ].every(value => value !== "" && value !== false);

            isValidObservable(isValid);
        } else {
            isValidObservable(false);
        }
    }

    ko.computed(function () {
        validateWalletMeta();
    });

    return {
        isValid: isValidObservable
    };
});
