define([
    'jquery',
    'mage/utils/wrapper',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/model/totals',
    'ko',
    'CartObserver'
], function ($, wrapper, quote, totals, ko, cartObserver) {
    'use strict';

    return function (setShippingInformationAction) {
        return wrapper.wrap(setShippingInformationAction, function (originalAction) {
            cartObserver.setSkipTotalsFlag(true);
            var shippingAddressData = quote.shippingAddress();


            

            var result = originalAction();

            result.done(function () {
                cartObserver.shippingChanged(totals.getSegment("grand_total").value);
                cartObserver.setSkipTotalsFlag(false);
            });

            return result;
        });
    };
});
