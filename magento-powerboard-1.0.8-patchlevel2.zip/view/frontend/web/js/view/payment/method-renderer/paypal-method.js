define([
    "CartObserver",
    'WalletMetaValidator',
    'jquery',
    'ko',
    'Magento_Checkout/js/action/select-payment-method',
    'Magento_Checkout/js/checkout-data',
    'Magento_Checkout/js/view/payment/default',
    'Paydock_Powerboard/js/action/paypal'
], function (cartObserver, walletMetaValidator, $, ko, selectPaymentMethodAction, checkoutData, paymentDefault, loadPaypalButtonAction) {
    'use strict';

    return paymentDefault.extend({
        defaults: {
            template: 'Paydock_Powerboard/payment/paypal-form'
        },
        widgetLoadedPayPal: false,
        payPalPreviousTotal: null,
        isValidationPassed: ko.observable(true),
        
        initialize: function() {
            this._super();

            this.subscribeToFormUpdates();
            this.subscribeToCartUpdates();
            this.loadPayPalButton();
        },
        
        subscribeToFormUpdates: function () {
            walletMetaValidator.isValid.subscribe((isValid) => {
                this.isValidationPassed(isValid);
            });
        },

        subscribeToCartUpdates: function () {
            cartObserver.cartTotalChanged.subscribe((newTotal) => {   
                this.loadPayPalButton();
            });
            cartObserver.shippingChanged.subscribe((newTotal) => {   
                this.loadPayPalButton();
            });
        },

        loadPayPalButton: function() {
            if (checkoutData.getSelectedPaymentMethod() !== this.getCode()) {
                return;
            }

            if(this.payPalPreviousTotal != cartObserver.cartTotal()) {
                $('#paydock_paypal_widget').empty();
                this.widgetLoadedPayPal = false;
            }

            if (this.widgetLoadedPayPal || !this.isValidationPassed) {
                return;
            }

            $('#paydock_paypal_widget').empty();

            loadPaypalButtonAction();

            this.widgetLoadedPayPal = true;
            this.payPalPreviousTotal = cartObserver.cartTotal();
        },

        getCode: function() {
            return this.item.method;
        },

        getLogoSrc: function() {
            return window.checkoutConfig.payment.paydockPaypal.logoSrc ?? '';
        },

        getData: function() {
            return {
                'method': this.getCode(),
                'additional_data': {
                    'response_id': $('input[id="paypal-response-id"]').val()
                }
            };
        },

        isChecked: ko.computed(function() {
            return checkoutData.getSelectedPaymentMethod();
        }),

        selectPaymentMethod: function() {
            selectPaymentMethodAction(this.getData());
            
            checkoutData.setSelectedPaymentMethod(this.getCode());
            
            setTimeout(() => {
                this.loadPayPalButton();
            }, 1500);
        
            return true;
        }
    });
});
