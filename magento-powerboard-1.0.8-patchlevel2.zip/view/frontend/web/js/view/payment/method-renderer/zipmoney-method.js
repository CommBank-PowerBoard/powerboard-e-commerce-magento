define([
    "Magento_Checkout/js/view/payment/default",
    "jquery",
    'ko',
    "Magento_Checkout/js/model/quote",
    "Paydock_Powerboard_Widget",
    "Magento_Checkout/js/checkout-data",
    "Magento_Checkout/js/action/select-payment-method",
    "CartObserver",
    'WalletMetaValidator'
], function (
    Component,
    $,
    ko,
    quote,
    cba,
    checkoutData,
    selectPaymentMethodAction,
    cartObserver,
    walletMetaValidator
) {
    "use strict";

    return Component.extend({
        defaults: {
            template: "Paydock_Powerboard/payment/zipmoney-form",
        },
        buttonZipMoney: null,
        widgetLoadedZipMoney: false,
        isValidationPassed: ko.observable(true),
        
        initialize: function () {
            this._super();

            this.subscribeToFormUpdates();
            this.subscribeToCartUpdates();
            this.loadZipMoneyButton();
        },

        subscribeToFormUpdates: function () {
            walletMetaValidator.isValid.subscribe((isValid) => {
                this.isValidationPassed(isValid);
                if(isValid) {
                    this.setMeta();
                }
            });
        },

        subscribeToCartUpdates: function () {
            cartObserver.cartTotalChanged.subscribe((newTotal) => {   
                this.setMeta();
            });
            cartObserver.shippingChanged.subscribe((newTotal) => {   
                this.setMeta();
            });
        },

        loadZipMoneyButton: function () { 
            if (checkoutData.getSelectedPaymentMethod() !== this.getCode()) {
                return;
            }

            if (this.widgetLoadedZipMoney || !this.isValidationPassed) {
                return;
            }

            let gatewayId = window.checkoutConfig.payment.paydockZipMoney.gatewayId,
                publicKey = window.checkoutConfig.payment.paydockCreditCard.publicKey

            if (typeof publicKey === "undefined" || publicKey.trim() === "") {
                console.error("Error loading widget - no public key defined");
                return;
            }

            this.buttonZipMoney = new cba.ZipmoneyCheckoutButton(
                "#zipmoney-checkout-button",
                publicKey,
                gatewayId
            );
            this.buttonZipMoney.setEnv(this.getEnvironment());
            this.buttonZipMoney.onFinishInsert(
                'input[id="zipmoney-checkout-button-payment-source-token"]',
                "payment_source_token"
            );
            
            this.setMeta();

            this.buttonZipMoney.on("finish", (data) => {
                this.paydockPlaceOrder();
            });

            this.widgetLoadedZipMoney = true;
            
            return;
        },
        
        setMeta: function() {
            if(!this.buttonZipMoney) { return }
            
            let shippingAddress = quote.shippingAddress(),
                billingAddress = quote.billingAddress(),
                currency = window.checkoutConfig.quoteData.base_currency_code;
                
            this.buttonZipMoney.setMeta({
                first_name: shippingAddress.firstname,
                tokenize: true,
                last_name: shippingAddress.lastname,
                email:
                    quote.guestEmail ??
                    window.checkoutConfig.quoteData.customer_email,
                gender: "",
                charge: {
                    amount: cartObserver.cartTotal(),
                    currency: currency,
                    shipping_type: "delivery",
                    shipping_address: {
                        first_name: shippingAddress.firstname,
                        last_name: shippingAddress.lastname,
                        line1: shippingAddress.street[0] ?? "",
                        line2: shippingAddress.street[1] ?? "",
                        country: shippingAddress.countryId,
                        postcode: shippingAddress.postcode,
                        city: shippingAddress.city,
                        state: shippingAddress.region,
                    },
                    billing_address: {
                        first_name: billingAddress.firstname,
                        last_name: billingAddress.lastname,
                        line1: billingAddress.street[0] ?? "",
                        line2: billingAddress.street[1] ?? "",
                        country: billingAddress.countryId,
                        postcode: billingAddress.postcode,
                        city: billingAddress.city,
                        state: billingAddress.region,
                    },
                    items: this.getCartItems(),
                },
                statistics: {
                    account_created: "",
                    sales_total_number: "",
                    sales_total_amount: "",
                    sales_avg_value: "",
                    sales_max_value: "",
                    refunds_total_amount: "",
                    previous_chargeback: "",
                    currency: currency,
                    last_login: "",
                },
            });
        },
        
        getCartItems: function () {
            let quoteItems = quote.getItems(),
                cartItems = [];

            for (let i = 0; i < quoteItems.length; i++) {
                cartItems.push({
                    name: quoteItems[i]["name"],
                    amount: quoteItems[i]["row_total"],
                    quantity: quoteItems[i]["qty"],
                    reference: quoteItems[i]["description"],
                });
            }

            return cartItems;
        },

        getCode: function () {
            return this.item.method;
        },

        getEnvironment: function () {
            return (
                window.checkoutConfig.payment.paydockCreditCard.environment ??
                "production_cba"
            );
        },

        getLogoSrc: function () {
            return window.checkoutConfig.payment.paydockZipMoney.logoSrc ?? "";
        },

        selectPaymentMethod: function () {
            selectPaymentMethodAction(this.getData());
            checkoutData.setSelectedPaymentMethod(this.getCode());

            setTimeout(() => {
                this.loadZipMoneyButton();
            }, 1500);
            return true;
        },

        paydockPlaceOrder: function () {
            $("#paydock-zipmoney-place-token-order").click();
            return;
        },

        getData: function () {
            return {
                method: this.item.method,
                additional_data: {
                    payment_token: $(
                        'input[id="zipmoney-checkout-button-payment-source-token"]'
                    ).val(),
                },
            };
        }
    });
});
