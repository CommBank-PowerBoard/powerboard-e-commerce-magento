<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Api;

interface GuestThreeDSRequestManagementInterface
{
    /**
     * @param string $paymentToken
     * @param string $cartId
     * @param mixed $browserDetails
     * @return string|null
     */
    public function place3dsPreAuthRequest(string $paymentToken, string $cartId, mixed $browserDetails): ?string;
}
