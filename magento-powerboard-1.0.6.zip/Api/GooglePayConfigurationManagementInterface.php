<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Api;

interface GooglePayConfigurationManagementInterface
{
    public const DEFAULT_XML_PATH_ACTIVE = 0;
    public const DEFAULT_XML_PATH_TITLE = 'Google Pay';
    public const DEFAULT_XML_PATH_GATEWAY_ID = '';
    public const DEFAULT_XML_PATH_SORT_ORDER = '40';
    public const XML_PATH_ACTIVE = 'payment/paydock_googlepay/active';
    public const XML_PATH_TITLE = 'payment/paydock_googlepay/title';
    public const XML_PATH_GATEWAY_ID = 'payment/paydock_googlepay/gateway_id';

    /**
     * @return bool
     */
    public function isActive(): bool;

    /**
     * @return string
     */
    public function getTitle(): string;

    /**
     * @return string
     */
    public function getGatewayId(): string;
}

