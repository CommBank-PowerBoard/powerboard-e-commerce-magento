<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Api;

interface TokenWalletInterface
{
    /**
     * @param string $cartId
     * @return string|bool
     */
    public function generateWalletToken(string $cartId): string|bool;
}
