define([
    'Magento_Checkout/js/model/payment/renderer-list',
    'uiComponent'
], function (
    rendererList,
    Component
) {
    'use strict';

    let config = window.checkoutConfig.payment,
        afterPay = 'paydockAfterPay',
        applePay = 'paydockApplePay',
        googlepay = 'paydockGooglePay',
        paydockCc = 'paydockCreditCard',
        paypal = 'paydockPaypal',
        zipMoney = 'paydockZipMoney',
        isSafari = navigator.userAgent && /^((?!chrome|android).)*safari/i.test(navigator.userAgent);

    if (config[paydockCc] && config[paydockCc].active && config[paydockCc].publicKey) {
        rendererList.push({
            type: 'paydock_cc',
            component: 'Paydock_Powerboard/js/view/payment/method-renderer/creditcard-method'
        });
    }

    if (config[paypal] && config[paypal].active) {
        rendererList.push({
            type: 'paydock_paypal',
            component: 'Paydock_Powerboard/js/view/payment/method-renderer/paypal-method'
        });
    }

    if (config[googlepay] && config[googlepay].active) {
        rendererList.push({
            type: 'paydock_googlepay',
            component: 'Paydock_Powerboard/js/view/payment/method-renderer/googlepay-method'
        });
    }

    if (config[applePay] && config[applePay].active && isSafari) {
        rendererList.push({
            type: 'paydock_applepay',
            component: 'Paydock_Powerboard/js/view/payment/method-renderer/applepay-method'
        });
    }

    if (config[afterPay] && config[afterPay].active) {
        rendererList.push({
            type: 'paydock_afterpay',
            component: 'Paydock_Powerboard/js/view/payment/method-renderer/afterpay-method'
        });
    }

    if (config[zipMoney] && config[zipMoney].active) {
        rendererList.push({
            type: 'paydock_zipmoney',
            component: 'Paydock_Powerboard/js/view/payment/method-renderer/zipmoney-method'
        });
    }

    return Component.extend({});
});