<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model;

use Paydock\Powerboard\Api\CreditCardConfigurationManagementInterface;
use Paydock\Powerboard\Api\ConfigurationManagementInterface;
use Paydock\Powerboard\Helper\StoreHelper;


class CreditCardConfigurationManagement implements CreditCardConfigurationManagementInterface {
    /**
     * @var ConfigurationManagementInterface
     */
    private ConfigurationManagementInterface $configurationManagement;

    /**
     * @param ConfigurationManagementInterface $configurationManagement
     * @param StoreHelper $storeHelper
     */

    /**
     * @var StoreHelper
     */
    private StoreHelper $storeHelper;

    public function __construct(
        ConfigurationManagementInterface $configurationManagement,
        StoreHelper $storeHelper
    ) {
        $this->configurationManagement = $configurationManagement;
        $this->storeHelper = $storeHelper;
    }

    /**
     * @inheritDoc
     */
    public function isActive(): bool {
        return (bool)$this->storeHelper->getStoreViewConfig(self::XML_PATH_ACTIVE)
            && $this->configurationManagement->isActive();
    }

    /**
     * @inheritDoc
     */
    public function canSaveCard(): bool {
        return (bool)$this->storeHelper->getStoreViewConfig(self::XML_PATH_SAVE_CARD);
    }

    /**
     * @inheritDoc
     */
    public function is3DS(): bool {
        return (bool)$this->storeHelper->getStoreViewConfig(self::XML_PATH_3DS);
    }

    /**
     * @inheritDoc
     */
    public function isBackendOrder(): bool {
        return (bool)$this->storeHelper->getStoreViewConfig(self::XML_PATH_BACKEND_ORDERS);
    }

    /**
     * @inheritDoc
     */
    public function getGatewayId(): string {
        return (string)$this->storeHelper->getStoreViewConfig(self::XML_PATH_GATEWAY_ID);
    }

    /**
     * @inheritDoc
     */
    public function getCssInput(): string {
        return (string)$this->storeHelper->getStoreViewConfig(self::XML_PATH_CSS_INPUT);
    }

    /**
     * @inheritDoc
     */
    public function getCssLabel(): string {
        return (string)$this->storeHelper->getStoreViewConfig(self::XML_PATH_CSS_LABEL);
    }


    /**
     * @inheritDoc
     */
    public function getCssSubmitButton(): string {
        return (string)$this->storeHelper->getStoreViewConfig(self::XML_PATH_CSS_SUBMIT);
    }

    /**
     * @inheritDoc
     */
    public function getBackendCssInput(): string {
        return (string)$this->storeHelper->getStoreViewConfig(self::XML_PATH_BACKEND_CSS_INPUT);
    }

    /**
     * @inheritDoc
     */
    public function getBackendCssLabel(): string {
        return (string)$this->storeHelper->getStoreViewConfig(self::XML_PATH_BACKEND_CSS_LABEL);
    }

    /**
     * @inheritDoc
     */
    public function getAvailableCardTypes(): array {
        $ccTypes = $this->storeHelper->getStoreViewConfig(self::XML_PATH_CC_TYPES);

        return !empty($ccTypes) ? explode(',', $ccTypes) : [];
    }

    /**
     * @inheritDoc
     */
    public function canDirectCharge(): bool {
        return (bool)$this->storeHelper->getStoreViewConfig(self::XML_PATH_DIRECT_CHARGE);
    }
}
