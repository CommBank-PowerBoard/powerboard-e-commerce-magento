<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model;


use Paydock\Powerboard\Api\PaypalConfigurationManagementInterface;
use Paydock\Powerboard\Api\ConfigurationManagementInterface;
use Paydock\Powerboard\Helper\StoreHelper;

class PaypalConfigurationManagement implements PaypalConfigurationManagementInterface {

    /**
     * @var ConfigurationManagementInterface
     */
    private ConfigurationManagementInterface $configurationManagement;

    /**
     * @param ConfigurationManagementInterface $configurationManagement
     * @param StoreHelper $storeHelper
     */
    /**
     * @var StoreHelper
     */
    private StoreHelper $storeHelper;

    public function __construct(
        ConfigurationManagementInterface $configurationManagement,
        StoreHelper $storeHelper
    ) {
        $this->configurationManagement = $configurationManagement;
        $this->storeHelper = $storeHelper;
    }

    /**
     * @inheritDoc
     */
    public function isActive(): bool {
        return (bool)($this->storeHelper->getStoreViewConfig(self::XML_PATH_ACTIVE))
            && $this->configurationManagement->isActive();
    }

    /**
     * @inheritDoc
     */
    public function getTitle(): string {
        return (string)$this->storeHelper->getStoreViewConfig(self::XML_PATH_TITLE);
    }

    /**
     * @inheritDoc
     */
    public function getGatewayId(): string {
        return (string)$this->storeHelper->getStoreViewConfig(self::XML_PATH_GATEWAY_ID);
    }

    /**
     * @inheritDoc
     */
    public function isPayLater(): bool {
        return (bool)$this->storeHelper->getStoreViewConfig(self::XML_PATH_PAY_LATER);
    }

    /**
     * @inheritDoc
     */
    public function getStyleLayout(): string {
        return PaypalConfigurationManagementInterface::DEFAULT_XML_PATH_STYLE_LAYOUT;
    }

    /**
     * @inheritDoc
     */
    public function getStyleColor(): string {
        return (string)$this->storeHelper->getStoreViewConfig(self::XML_PATH_STYLE_COLOR);
    }

    /**
     * @inheritDoc
     */
    public function getStyleShape(): string {
        return PaypalConfigurationManagementInterface::DEFAULT_XML_PATH_STYLE_SHAPE;
    }

    /**
     * @inheritDoc
     */
    public function isStyleTagline(): bool {
        return (bool)$this->storeHelper->getStoreViewConfig(self::XML_PATH_STYLE_TAGLINE);
    }

    /**
     * @inheritDoc
     */
    public function getStyleLabel(): string {
        return (string)$this->storeHelper->getStoreViewConfig(self::XML_PATH_STYLE_LABEL);
    }
}
