<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model;

use Paydock\Powerboard\Api\AfterPayConfigurationManagementInterface;
use Paydock\Powerboard\Api\ConfigurationManagementInterface;
use Paydock\Powerboard\Helper\StoreHelper;

class AfterPayConfigurationManagement implements AfterPayConfigurationManagementInterface {


    /**
     * @var ConfigurationManagementInterface
     * @var StoreHelper
     */
    private ConfigurationManagementInterface $configurationManagement;

    /**
     * @var StoreHelper
     */
    private StoreHelper $storeHelper;

    /**
     * @param ConfigurationManagementInterface $configurationManagement
     */

    public function __construct(
        ConfigurationManagementInterface $configurationManagement,
        StoreHelper $storeHelper
    ) {
        $this->configurationManagement = $configurationManagement;
        $this->storeHelper = $storeHelper;
    }

    /**
     * @inheritDoc
     */
    public function isActive(): bool {
        return (bool)($this->storeHelper->getStoreViewConfig(self::XML_PATH_ACTIVE))
            && $this->configurationManagement->isActive();
    }

    /**
     * @inheritDoc
     */
    public function getTitle(): string {
        return (string)$this->storeHelper->getStoreViewConfig(self::XML_PATH_TITLE);
    }

    /**
     * @inheritDoc
     */
    public function getGatewayId(): string {
        return (string)$this->storeHelper->getStoreViewConfig(self::XML_PATH_GATEWAY_ID);
    }

    /**
     * @inheritDoc
     */
    public function getMpid(): string {
        return (string)$this->storeHelper->getStoreViewConfig(self::XML_PATH_MPID);
    }

    /**
     * @inheritDoc
     */
    public function getPlacementId(): string {
        return (string)$this->storeHelper->getStoreViewConfig(self::XML_PATH_PLACEMENT_ID);
    }
}
