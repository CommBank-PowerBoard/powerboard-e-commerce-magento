/**
 * @api
 */
define([
    'jquery',
    'Paydock_Powerboard/js/model/error-handler',
    'Magento_Checkout/js/model/url-builder',
    'mage/storage',
    'Magento_Checkout/js/model/full-screen-loader',
    'Magento_Checkout/js/model/quote',
    'Paydock_Powerboard_Widget',
], function ($, errorHandler, urlBuilder, storage, fullScreenLoader, quote, cba) {
    'use strict';

    var placeOrder = function (responseId) {
        if (responseId) {
            $('input[id="googlepay-response-id"]').val(responseId);
            $('#paydock-googlepay-place-token-order').click();
        } else {
            errorHandler.process('Error processing request, please try again');
        }
    }

    return function () {
        let serviceUrl;

        serviceUrl = urlBuilder.createUrl(
            '/paydock/wallet/token/:cartId',
            {
                cartId:  quote.getQuoteId()
            }
        );

        fullScreenLoader.startLoader();

        return storage.get(
            serviceUrl,
            false
        ).done(
            function (response) {
                let result = JSON.parse(response),
                    environment = window.checkoutConfig.payment.paydockCreditCard.environment ?? 'production_cba';

                if (result.success) {
                    let button = new cba.WalletButtons('#paydock_googlepay_widget', result.token_wallet, {
                        amount_label: 'Total',
                        country: 'AU',
                        wallets: ['google'],
                        style: {
                            google: {
                                button_type: 'buy',
                                button_size_mode: 'static',
                                button_color: 'black',
                            }
                        },
                    });
                
                    button.setEnv(environment);
                    button.onUnavailable(() => console.error('No wallet buttons available'));
                    button.onPaymentSuccessful((response) => {
                        placeOrder(response.data.id);
                    });
                    
                    button.onUpdate((data) => {
                        setTimeout(function () {
                            button.update({ success: true, body: {} });
                        }, 3000);
                    });
                    button.load();
                } else {
                    errorHandler.process(result.error);
                }

            }
        ).fail(
            function (response) {
                errorHandler.process(response);
            }
        ).always(
            function (response) {
                fullScreenLoader.stopLoader();
            }
        );
    };
});
