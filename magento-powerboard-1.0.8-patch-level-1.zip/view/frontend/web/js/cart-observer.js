define([
    'ko',
    'Magento_Checkout/js/model/totals',
    'Magento_Checkout/js/model/quote',
    "Magento_Checkout/js/checkout-data"
], function (
    ko,
    totals,
    quote,
    checkoutData
) {
    "use strict";

    var currentPaymentMethod = ko.observable(
        checkoutData.getSelectedPaymentMethod() ?? null
    );

    var cartTotal = ko.observable(
        getGrandTotal()
    );

    function updateCartTotal() {
        var grandTotal = getGrandTotal();
        cartTotal(grandTotal);
    }

    function getGrandTotal() {
        return totals.getSegment("grand_total") ? totals.getSegment("grand_total").value : 0;
    }

    function subscribe() {
        // Subscribe to cart total updates
        totals.totals.subscribe(function () {
            updateCartTotal();
        });

        // Subscribe to shipping method updates
        quote.shippingMethod.subscribe(function () {
            updateCartTotal();
        });

        // Subscribe to payment method changes
        quote.paymentMethod.subscribe(function (newPaymentMethod) {
            if (newPaymentMethod && newPaymentMethod.method) {
                currentPaymentMethod(newPaymentMethod.method);
            }
        });
    }

    subscribe();

    return {
        cartTotal: cartTotal,
        currentPaymentMethod: currentPaymentMethod
    };
});
