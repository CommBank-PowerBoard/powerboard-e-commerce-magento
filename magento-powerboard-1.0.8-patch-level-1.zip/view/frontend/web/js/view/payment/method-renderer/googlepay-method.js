// Example changes for googlepay-method.js
define([
    "Magento_Checkout/js/view/payment/default",
    "jquery",
    'ko',
    "Paydock_Powerboard/js/action/googlepay",
    "Magento_Checkout/js/action/select-payment-method",
    "Magento_Checkout/js/checkout-data",
    "CartObserver",
    'WalletMetaValidator'
], function (
    paymentDefault,
    $,
    ko,
    loadGooglePayButtonAction,
    selectPaymentMethodAction,
    checkoutData,
    cartObserver,
    walletMetaValidator
) {
    "use strict";
    return paymentDefault.extend({
        defaults: {
            template: "Paydock_Powerboard/payment/googlepay-form",
        },
        isWalletMetaValidGooglePay: null,
        widgetLoadedGooglePay: false,
        googlePayPreviousTotal: null,

        initialize: function () {
            this._super();

            this.subscribeToCartUpdates();
            this.subscribeToWalletMetaValidatorUpdates();
            this.loadGooglePayButton();

        },

        subscribeToWalletMetaValidatorUpdates: function () {
            var walletValidator = new walletMetaValidator('paydock_googlepay', this.walletMetaCallbackGooglePay.bind(this));
            this.isWalletMetaValidGooglePay = walletValidator.isValid; 
        },

        subscribeToCartUpdates: function () {
            cartObserver.cartTotal.subscribe((newTotal) => {      
                this.reloadGooglePay();
            });
        },

        walletMetaCallbackGooglePay: function (isValid) {
            if(isValid) {
                setTimeout(() => {
                    this.loadGooglePayButton();
                }, 1500);
            }
        },

        reloadGooglePay: function () {
            $('#paydock_googlepay_widget').empty();
            this.widgetLoadedGooglePay = false;
            setTimeout(() => {
                this.loadGooglePayButton();
            }, 1500);
        },

        loadGooglePayButton: function() {
            if (checkoutData.getSelectedPaymentMethod() !== this.getCode()) {
                return;
            }

            if (this.widgetLoadedGooglePay || !this.isWalletMetaValidGooglePay) {
                return;
            }

            if(this.googlePayPreviousTotal === cartObserver.cartTotal()) {
                return
            }

            $('#paydock_googlepay_widget').empty();
            loadGooglePayButtonAction();

            this.widgetLoadedGooglePay = true;
            this.googlePayPreviousTotal = cartObserver.cartTotal();
        },

        isChecked: ko.computed(function() {
            return checkoutData.getSelectedPaymentMethod();
        }),

        getCode: function () {
            return this.item.method;
        },

        getLogoSrc: function () {
            return window.checkoutConfig.payment.paydockGooglePay.logoSrc ?? "";
        },

        getData: function () {
            return {
                method: this.getCode(),
                additional_data: {
                    response_id: $('input[id="googlepay-response-id"]').val(),
                },
            };
        },

        selectPaymentMethod: function () {
            selectPaymentMethodAction(this.getData());
            checkoutData.setSelectedPaymentMethod(this.getCode());

            setTimeout(() => {
                this.loadGooglePayButton();
            }, 1500);

            return true;
        }
    });
});
