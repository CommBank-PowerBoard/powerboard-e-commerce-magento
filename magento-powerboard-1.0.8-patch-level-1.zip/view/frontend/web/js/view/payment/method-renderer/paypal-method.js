define([
    "CartObserver",
    'jquery',
    'ko',
    'Magento_Checkout/js/action/select-payment-method',
    'Magento_Checkout/js/checkout-data',
    'Magento_Checkout/js/view/payment/default',
    'Paydock_Powerboard/js/action/paypal',
    'WalletMetaValidator'
], function (cartObserver, $, ko, selectPaymentMethodAction, checkoutData, paymentDefault, loadPaypalButtonAction, walletMetaValidator) {
    'use strict';

    return paymentDefault.extend({
        defaults: {
            template: 'Paydock_Powerboard/payment/paypal-form'
        },
        isWalletMetaValidPayPal: null,
        widgetLoadedPayPal: false,
        walletMetaValidatorInstancePayPal: null,
        payPalPreviousTotal: null,

        initialize: function() {
            this._super();

            this.subscribeToCartUpdates();
            this.subscribeToWalletMetaValidatorUpdates();
            this.loadPayPalButton();
        },
        
        subscribeToCartUpdates: function () {
            cartObserver.cartTotal.subscribe((newTotal) => {   
                this.reloadPayPal();
            });
        },

        subscribeToWalletMetaValidatorUpdates: function () {
            var walletValidator = new walletMetaValidator('paydock_paypal', this.walletMetaCallbackPayPal.bind(this));
            this.isWalletMetaValidPayPal = walletValidator.isValid; 
        },

        walletMetaCallbackPayPal: function (isValid) {
            if(isValid) {
                setTimeout(() => {
                    this.loadPayPalButton();
                }, 1500);
            }
        },

        reloadPayPal: function () {     
            $('#paydock_paypal_widget').empty();
            this.widgetLoadedPayPal = false;
            setTimeout(() => {
                this.loadPayPalButton();
            }, 1500);
        },

        loadPayPalButton: function() {
            if (checkoutData.getSelectedPaymentMethod() !== this.getCode()) {
                return;
            }

            if (this.widgetLoadedPayPal || !this.isWalletMetaValidPayPal) {
                return;
            }

            if(this.payPalPreviousTotal === cartObserver.cartTotal()) {
                return
            }

            $('#paydock_paypal_widget').empty();
            loadPaypalButtonAction();

            this.widgetLoadedPayPal = true;
            this.payPalPreviousTotal = cartObserver.cartTotal();
        },

        getCode: function() {
            return this.item.method;
        },

        getLogoSrc: function() {
            return window.checkoutConfig.payment.paydockPaypal.logoSrc ?? '';
        },

        getData: function() {
            return {
                'method': this.getCode(),
                'additional_data': {
                    'response_id': $('input[id="paypal-response-id"]').val()
                }
            };
        },

        isChecked: ko.computed(function() {
            return checkoutData.getSelectedPaymentMethod();
        }),

        selectPaymentMethod: function() {
            selectPaymentMethodAction(this.getData());
            checkoutData.setSelectedPaymentMethod(this.getCode());

            setTimeout(() => {
                this.loadPayPalButton();
            }, 1500);
            
            return true;
        }
    });
});
