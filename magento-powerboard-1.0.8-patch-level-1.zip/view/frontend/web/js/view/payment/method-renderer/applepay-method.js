define([
    "jquery",
    "ko",
    "Magento_Payment/js/view/payment/cc-form",
    "Paydock_Powerboard/js/action/applepay",
    "Magento_Checkout/js/action/select-payment-method",
    "Magento_Checkout/js/checkout-data",
    "CartObserver",
    'WalletMetaValidator'
], function (
    $,
    ko,
    Component,
    loadApplePayAction,
    selectPaymentMethodAction,
    checkoutData,
    cartObserver,
    walletMetaValidator
) {
    "use strict";

    return Component.extend({
        defaults: {
            template: "Paydock_Powerboard/payment/applepay-form",
        },
        isWalletMetaValidApplePay: null,
        widgetLoadedApplePay: false,
        applePayPreviousTotal: null,

        initialize: function () {
            this._super();

            this.subscribeToUpdates();
            this.subscribeToWalletMetaValidatorUpdates();
            this.loadApplePayButton();
        },

        subscribeToWalletMetaValidatorUpdates: function () {
            var walletValidator = new walletMetaValidator('paydock_applepay', this.walletMetaCallbackApplePay.bind(this));
            this.isWalletMetaValidApplePay = walletValidator.isValid; 
        },

        subscribeToUpdates: function () {
            cartObserver.cartTotal.subscribe(function (newTotal) {
                this.reloadApplePay();
                
            }.bind(this));
        },

        walletMetaCallbackApplePay: function (isValid) {
            if (isValid) {
                setTimeout(() => {
                    this.loadApplePayButton();
                }, 1500);
            }
        },

        reloadApplePay: function () {   
            $('#paydock_applepay_widget').empty()
            this.widgetLoadedApplePay = false;
            setTimeout(() => {
                this.loadApplePayButton();
            }, 1500);
        },

        loadApplePayButton: function () {
            if (checkoutData.getSelectedPaymentMethod() !== this.getCode()) {
                return;
            }

            if (this.widgetLoadedApplePay || !this.isWalletMetaValidApplePay()) {
                return;
            }

            if(this.applePayPreviousTotal === cartObserver.cartTotal()) {
                return
            }

            $('#paydock_applepay_widget').empty()
            loadApplePayAction();

            this.widgetLoadedApplePay = true;
            this.applePayPreviousTotal = cartObserver.cartTotal();
        },

        isChecked: ko.computed(function() {
            return checkoutData.getSelectedPaymentMethod();
        }),

        getCode: function () {
            return this.item.method;
        },

        getLogoSrc: function () {
            return window.checkoutConfig.payment.paydockApplePay.logoSrc ?? "";
        },

        getData: function () {
            return {
                method: this.item.method,
                additional_data: {
                    response_id: $('input[id="applepay-response-id"]').val(),
                },
            };
        },

        selectPaymentMethod: function () {
            selectPaymentMethodAction(this.getData());
            checkoutData.setSelectedPaymentMethod(this.getCode());
            
            setTimeout(() => {
                this.loadApplePayButton();
            }, 1500);

            return true;
        },
    });
});
