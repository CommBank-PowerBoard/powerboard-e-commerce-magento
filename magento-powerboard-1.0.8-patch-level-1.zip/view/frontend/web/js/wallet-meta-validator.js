define([
    'ko',
    'Magento_Checkout/js/checkout-data',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/model/payment/method-list'
], function (
    ko,
    checkoutData,
    quote,
    paymentMethodList
) {
    var WalletMetaValidator = function (paymentCode, callback) {
        if (!paymentCode || typeof callback !== 'function') {
            throw new Error("Payment code and callback are required to initialize WalletMetaValidator.");
        }

        var walletMetaObservable = ko.observable(false);
        var subscription = null;

        function validateWalletMeta() {
            const inputFieldEmail = window.checkoutConfig.quoteData.customer_email || checkoutData.getInputFieldEmailValue() || "";
            if (!inputFieldEmail) {
                walletMetaObservable(false);
                return false;
            }

            const validatedEmailValue = window.checkoutConfig.quoteData.customer_email || checkoutData.getInputFieldEmailValue() || "";
            if (!validatedEmailValue) {
                walletMetaObservable(false);
                return false;
            }

            const address = window.checkoutConfig.quoteData.customer_email ? quote.shippingAddress() : checkoutData.getShippingAddressFromData();
            if (!address || !address.street  || address.street.length === 0 || !address.street[0]) {
                walletMetaObservable(false);
                return false;
            }

            const selectedShippingMethod = quote.shippingMethod();
            if (!selectedShippingMethod) {
                walletMetaObservable(false);
                return false;
            }

            const hasAllRequiredValues = [
                address.firstname?.trim(),
                address.lastname?.trim(),
                address.street[0]?.trim(),
                address.city?.trim(),
                address.regionId?.trim() || address.region_id?.trim() || address.region?.trim(),
                address.postcode?.trim(),
                address.countryId?.trim() || address.country_id?.trim(),
                address.telephone?.trim(),
                window.checkoutConfig.quoteData.store_id,
                window.checkoutConfig.payment.paydockAfterPay.storeName,
                window.checkoutConfig.quoteData.base_currency_code?.trim(),
                inputFieldEmail?.trim(),
                validatedEmailValue?.trim(),
                selectedShippingMethod["method_code"]?.trim()
            ].every(Boolean);

            if (hasAllRequiredValues) {
                const isValid = [
                    address.firstname.trim(),
                    address.lastname.trim(),
                    address.street[0]?.trim(),
                    address.city.trim(),
                    address.regionId?.trim() || address.region_id?.trim() || address.region?.trim(),
                    address.postcode.trim(),
                    address.countryId?.trim() || address.country_id?.trim(),
                    address.telephone.trim(),
                    inputFieldEmail.trim() === validatedEmailValue.trim(),
                    selectedShippingMethod["method_code"]?.trim()
                ].every(value => value !== "" && value !== false);

                walletMetaObservable(isValid);
                if (isPaymentMethodActive() && callback) {
                    callback(isValid);
                }
            } else {
                walletMetaObservable(false);
                if (isPaymentMethodActive() && callback) {
                    callback(false);
                }
            }
        }

        function isPaymentMethodActive() {
            return checkoutData.getSelectedPaymentMethod() === paymentCode ? true : false;
        }

        function subscribe() {
            subscription = walletMetaValidator.subscribe(function (newValue) {
                if (isPaymentMethodActive() && callback) {
                    callback(newValue);
                }
            });
        }

        function dispose() {
            if (subscription) {
                subscription.dispose();
            }
        }

        var walletMetaValidator = ko.computed(function () {
            return validateWalletMeta();
        });

        subscribe();

        return {
            dispose: dispose,
            walletMetaValidator: walletMetaValidator,
            isValid: walletMetaObservable
        };
    };

    return WalletMetaValidator;
});
