define(["jquery", "uiComponent", "ko", "Paydock_Powerboard_Widget"], function ($, Component, ko, paydock) {
    "use strict";
    return Component.extend({
        config: {},
        widget: null,

        initialize: function () {
            this._super();
            this.config = this.config.payment.paydockCreditCard ?? {};
            this.initWidget();
            this.initEventListeners();
            this.initOverride();
        },

        initWidget: function () {
            let publicKey = this.getPublicKey();
            if (typeof publicKey === "undefined" || publicKey.trim() === "") {
                console.error("Error loading widget - no public key defined");
                return;
            }
            
            this.widget = new paydock.HtmlWidget('#paydock_widget', publicKey, "not_configured", "card", "card_payment_source_with_cvv");
            this.initWidgetStyles(this.widget);

           
            this.widget.onFinishInsert("#paydock_cc-token", "payment_source");
            this.widget.useCheckoutAutoSubmit();

            this.widget.on("validation", function (data) {
                if (data.form_valid) {
                    let errContainer = $("#payment-paydock-error");
                    errContainer.html("");
                    errContainer.css("display", "none");
                }
            });

            this.widget.setEnv(this.getEnvironment());
            this.widget.load();
        },

        getCode: function () {
            return "paydock_cc";
        },

        getPublicKey: function () {
            return this.config.publicKey ?? "";
        },

        getEnvironment: function () {
            return this.config.environment ?? "production_cba";
        },

        getCss: function () {
            return JSON.parse(this.config.css || "{}");
        },

        getBackendCssLabel: function () {
            return JSON.parse(this.config.cssBackendLabel || "{}");
        },

        getBackendCssInput: function () {
            return JSON.parse(this.config.cssBackendInput || "{}");
        },

        initEventListeners: function () {
            var $editForm = jQuery("#edit_form");
            var self = this;
            $editForm.on("beforeSubmitOrder", async function (event) {
                if (window.order.paymentMethod !== "paydock_cc") {
                    return true;
                }

                let errContainer = $("#payment-paydock-error");

                if (!self.widget.isValidForm()) {
                    errContainer.html("Please enter payment details");
                    errContainer.css("display", "block");
                    $editForm.trigger("processStop");
                    return false;
                }

                errContainer.html("");
                errContainer.css("display", "none");

                return await self
                    .submitWidget()
                    .then((response) => {
                        return true;
                    })
                    .catch((error) => {
                        errContainer.html("Gateway error, please try again");
                        errContainer.css("display", "block");
                        $editForm.trigger("processStop");
                        self.widget.reload();
                        return false;
                    });
            });
        },

        initOverride: function () {
            if (window.AdminOrder !== "undefined") {
                (function (submit) {
                    window.AdminOrder.prototype.submit = async function () {
                        var $editForm = jQuery("#edit_form"),
                            beforeSubmitOrderEvent;
                        if ($editForm.valid()) {
                            $editForm.trigger("processStart");
                            beforeSubmitOrderEvent =
                                jQuery.Event("beforeSubmitOrder");
                            $editForm.trigger(beforeSubmitOrderEvent);
                            let result = await beforeSubmitOrderEvent.result;
                            if (result !== false) {
                                $editForm.trigger("submitOrder");
                            }
                        }
                    };
                })(window.AdminOrder.prototype.submit);
            }
        },

        submitWidget: async function () {
            var self = this;
            return new Promise((resolve, reject) => {
                var submitted = false;
                self.widget.on("submit", function (data) {
                    submitted = true;
                });

                self.widget.on("finish", function (data) {
                    if (!submitted) {
                        reject(false);
                    }

                    resolve(true);
                });

                self.widget.trigger("submit_form", {});
            }).then((result) => {
                return false;
            });
        },

        initWidgetStyles: function (widget) {
            widget.setFormLabels({ card_name: "Card Holder Name *" });
            widget.setFormLabels({ card_number: "Card Number *" });
            widget.setFormLabels({ card_ccv: "Security Number *" });
            widget.setFormLabels({ expire_month: "Expiry *" });
            widget.setFormFields(["card_name*", "card_number*", "card_ccv*"]);
            widget.setFormPlaceholders({
                card_name: "Card Holder Name",
                card_number: "Card Number",
                card_ccv: "CCV",
            });

            var supportedCardTypes = [];
            $.each(
                this.config.availableCardTypes,
                function (index, value) {
                    switch (value) {
                        case "DN":
                            supportedCardTypes.push("diners");
                            break;
                        case "AE":
                            supportedCardTypes.push("amex");
                            break;
                        case "MC":
                            supportedCardTypes.push("mastercard");
                            break;
                        case "JCB":
                            supportedCardTypes.push("japcb");
                            break;
                        case "VI":
                            supportedCardTypes.push("visa");
                            break;
                        default:
                            break;
                    }
                }
            );

            if (supportedCardTypes.length > 0) {
                widget.setSupportedCardIcons(supportedCardTypes, true);
            }

            widget.setStyles(this.getCss());
            widget.setElementStyle("label", this.getBackendCssLabel());
            widget.setElementStyle("input", this.getBackendCssInput());
            widget.setTexts({ finish_text: "Processing..." });
            widget.useAutoResize();
        },
    });
});
