<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare (strict_types = 1);

namespace Paydock\Powerboard\Block\Adminhtml\System\Config\Form\Field;

use Magento\Backend\Block\Template\Context;
use Magento\Config\Block\System\Config\Form\Field;
use Magento\Config\Model\Config\Source\Enabledisable;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Paydock\Powerboard\Api\AfterPayConfigurationManagementInterface;

class AfterpayActiveActionField extends Field
{
    /**
     * @param AbstractElement $element
     * @return string
     */
    protected function _getElementHtml(AbstractElement $element): string
    {
        $html = parent::_getElementHtml($element);
        $htmlId = $element->getHtmlId();
        $paymentHtmlId = str_replace('_active', '', $htmlId);
        $inheritHtmlId = $htmlId . '_inherit';
        $script = "
            <script>
                require(['jquery'], function ($) {
                    $(document).ready(function () {
                        function updateAfterpayActiveAction() {
                            if (parseInt($('#{$htmlId}').val()) === " . Enabledisable::DISABLE_VALUE . ") {
                                ".$this->renderAfterpayScripts($paymentHtmlId)."
                            }
                        }
                        updateAfterpayActiveAction();
                        $('#{$htmlId}').on('change', function () {
                            updateAfterpayActiveAction();
                            $('#{$inheritHtmlId}').prop('checked', false );
                        });
                    });
                });
            </script>
        ";

        return $html . $script;
    }

    /**
     * Backend admin script on active toggle
     *
     * @param string $paymentHtmlId
     * @return string
     */
    public function renderAfterpayScripts(string $paymentHtmlId): string
    {
        $afterpayTitle = afterpayConfigurationManagementInterface::DEFAULT_XML_PATH_TITLE;
        $afterpayGatewayId = afterpayConfigurationManagementInterface::DEFAULT_XML_PATH_GATEWAY_ID;
        $afterpayMPID = afterpayConfigurationManagementInterface::DEFAULT_XML_PATH_MPID;
        $afterpayPlacementId= afterpayConfigurationManagementInterface::DEFAULT_XML_PATH_PLACEMENT_ID;
        $afterpaySortOrder = afterpayConfigurationManagementInterface::DEFAULT_XML_PATH_SORT_ORDER;
        $scripts = "
            $('#{$paymentHtmlId} input[type=\"text\"]').val('');
            $('#{$paymentHtmlId} input[type=\"checkbox\"]').prop('checked', true );
            $('#{$paymentHtmlId}_gateway_id').val('{$afterpayGatewayId}').prop('disabled', true);
            $('#{$paymentHtmlId}_title').val('{$afterpayTitle}').prop('disabled', true);
            $('#{$paymentHtmlId}_mpid').val('{$afterpayMPID}').prop('disabled', true);
            $('#{$paymentHtmlId}_placement_id').val('{$afterpayPlacementId}').prop('disabled', true);
            $('#{$paymentHtmlId}_sort_order').val('{$afterpaySortOrder}').prop('disabled', true);
        ";
        return $scripts;
    }
}
