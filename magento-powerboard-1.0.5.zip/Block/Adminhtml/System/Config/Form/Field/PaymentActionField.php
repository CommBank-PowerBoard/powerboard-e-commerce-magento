<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Block\Adminhtml\System\Config\Form\Field;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Config\Model\Config\Source\Enabledisable;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Payment\Model\MethodInterface;

class PaymentActionField extends Field
{
    /**
     * @param AbstractElement $element
     * @return string
     */
    protected function _getElementHtml(AbstractElement $element): string
    {
        $html = parent::_getElementHtml($element);
        $htmlId = $element->getHtmlId();
        $paymentHtmlId = str_replace('_payment_action', '', $htmlId);
        $script = "
            <script>
                require(['jquery'], function ($) {
                    $(document).ready(function () {
                        function updatePaymentAction() {
                            if ($('#{$htmlId}').val() !== '".MethodInterface::ACTION_AUTHORIZE_CAPTURE."') {
                                $('#{$paymentHtmlId}_direct_charge').val(".Enabledisable::DISABLE_VALUE.");
                            }
                        }
                        updatePaymentAction();
                        $('#{$htmlId}').on('change', function () {
                            updatePaymentAction();
                        });
                    });
                });
            </script>
        ";

        return $html . $script;
    }
}
