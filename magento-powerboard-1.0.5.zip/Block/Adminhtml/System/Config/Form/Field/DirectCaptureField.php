<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Block\Adminhtml\System\Config\Form\Field;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Config\Model\Config\Source\Enabledisable;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Payment\Model\MethodInterface;

class DirectCaptureField extends Field
{
    /**
     * @param AbstractElement $element
     * @return string
     */
    protected function _getElementHtml(AbstractElement $element): string
    {
        $html = parent::_getElementHtml($element);
        $htmlId = $element->getHtmlId();
        $paymentHtmlId = str_replace('_direct_charge', '', $htmlId);
        $script = "
            <script>
                require(['jquery'], function ($) {
                    $(document).ready(function () {
                        function updatePaymentAction() {
                            if (parseInt($('#{$htmlId}').val()) === ".Enabledisable::ENABLE_VALUE.") {
                                $('#{$paymentHtmlId}_payment_action').val('".MethodInterface::ACTION_AUTHORIZE_CAPTURE."');
                            }
                        }
                        updatePaymentAction();
                        $('#{$htmlId}').on('change', function () {
                            updatePaymentAction();
                        });
                    });
                });
            </script>
        ";

        return $html . $script;
    }
}
