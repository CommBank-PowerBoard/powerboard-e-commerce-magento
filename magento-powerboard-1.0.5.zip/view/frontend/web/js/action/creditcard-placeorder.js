define([
    'jquery'
], function($) {
    return function() {
        $('#paydock-creditcard-place-token-order').click();
        return;
    };
});
