define([
    'jquery',
    'Paydock_Powerboard/js/model/creditcard'
], function($,creditCardModel) {
    'use strict';

    return {

        initStyles: function(widget) {
            widget.setFormLabels({card_name: 'Card Holder Name *'});
            widget.setFormLabels({card_number: 'Card Number *'});
            widget.setFormLabels({card_ccv: 'Security Number *'});
            widget.setFormLabels({expire_month: 'Expiry *'});
            widget.setFormFields(['card_name*', 'card_number*', 'card_ccv*']);
            widget.setFormPlaceholders({
                card_name: 'Card Holder Name',
                card_number: 'Card Number',
                card_ccv: 'CCV',
            });

            var supportedCardTypes = [];
            $.each(window.checkoutConfig.payment.paydockCreditCard.availableCardTypes, function(index, value) {
                switch(value) {
                    case "DN": supportedCardTypes.push("diners"); break;
                    case "AE": supportedCardTypes.push("amex"); break;
                    case "MC": supportedCardTypes.push("mastercard"); break;
                    case "JCB": supportedCardTypes.push("japcb"); break;
                    case "VI": supportedCardTypes.push("visa"); break;
                    default: break;
                }
            });

            if(supportedCardTypes.length > 0) {
                widget.setSupportedCardIcons(supportedCardTypes, true);
            }

            widget.setStyles(creditCardModel.getCss());
            widget.setElementStyle('submit_button', creditCardModel.getButtonCss());
            widget.setElementStyle('label', creditCardModel.getLabelCss());
            widget.setElementStyle('input', creditCardModel.getInputCss());
            widget.setTexts({submit_button: 'Place Order'});
            widget.useAutoResize();
        },  

    };
});
