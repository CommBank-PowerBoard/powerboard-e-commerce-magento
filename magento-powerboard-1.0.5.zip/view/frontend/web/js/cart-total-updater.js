
define([
    "jquery",
    "Magento_Customer/js/customer-data",
    "Magento_Checkout/js/model/totals"
], function ($, customerData, totals) {
    'use strict';

    const cartTotalKey = 'cartTotal';
    var cart = customerData.get('cart');

    
    var count = cart().summary_count;
    var currentItems = [...cart().items];

    function updateCartTotal() {
        const grandTotal = totals.getSegment("grand_total") 
            ? totals.getSegment("grand_total").value 
            : 0;

        localStorage.setItem(cartTotalKey, grandTotal);
    }

    function logCartChanges(cart) {



    }

    cart.subscribe(function () {

        logCartChanges(cart());

        
        if (cart().summary_count !== count) {
            for (let i = 0; i < cart().summary_count; i++) {
                var foundItem = currentItems.find(x => x.item_id == cart().items[i].item_id);
                var currentItem = cart().items[i];

                if (foundItem && foundItem.qty < currentItem.qty) {
                    var qtyChange = currentItem.qty - foundItem.qty;

                }
            }
        }

        
        count = cart().summary_count;
        currentItems = [...cart().items];
    });

    
    customerData.get('cart').subscribe(function (cart) {

        logCartChanges(cart);
        if (cart.items.length > 0) {

            updateCartTotal();
        }
    });

    
    $(document).ready(function () {


        updateCartTotal();
    });

    

});