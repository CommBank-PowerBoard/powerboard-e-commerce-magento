define([
    'jquery',
    'Magento_Checkout/js/model/totals'
], function (
    $,
    totals
) {
    "use strict";

    var CartObserver = (function () {
        var instance;

        function init() {
            var cartTotal = totals.getSegment("grand_total") ? totals.getSegment("grand_total").value : 0;
            var callback = null;
            var subscription = null;

            function subscribe() {
                subscription = totals.totals.subscribe(function (newTotals) {
                    var grandTotal = newTotals && totals.getSegment("grand_total") ? totals.getSegment("grand_total").value : 0;
                    if (cartTotal !== grandTotal) {
                        cartTotal = grandTotal;
                        if (callback) {
                            callback(grandTotal);
                        }
                    }
                });
            }

            function setCallback(newCallback) {
                callback = newCallback;
            }

            function dispose() {
                if (subscription) {
                    subscription.dispose();
                }
            }

            subscribe();

            return {
                setCallback: setCallback,
                dispose: dispose
            };
        }


        return {
            getInstance: function () {
                if (!instance) {
                    instance = init();
                }
                return instance;
            }
        };
    })();

    return CartObserver;
});