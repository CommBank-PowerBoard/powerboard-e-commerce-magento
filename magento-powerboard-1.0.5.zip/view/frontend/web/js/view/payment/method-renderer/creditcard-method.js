define(
    [
        'Magento_Checkout/js/view/payment/default',
        'jquery',
        'Paydock_Powerboard/js/action/creditcard-init',
        'Paydock_Powerboard/js/model/creditcard',
        'Magento_Checkout/js/action/select-payment-method',
        'Magento_Checkout/js/checkout-data',
        'Magento_Customer/js/model/customer',
        'Paydock_Powerboard/js/action/place-3ds-order',
        'Magento_Checkout/js/model/payment/method-list'
    ],
    function (Component, $, initCreditCardWidget, creditCardModel, selectPaymentMethodAction, checkoutData, customer, place3DSOrderAction, methodList) {
        'use strict';

        return Component.extend({
            widgetLoaded: false,
            defaults: {
                template: 'Paydock_Powerboard/payment/creditcard-form',
                showCustomerLoggedInElements: false,
                showCustomerLoggedInPaymentSourceElements: false,
            },

            /**
             * {@inheritdoc}
             */
            initialize: function() {
                this._super();
            },

            initObservable: function () {
                this._super()
                    .observe([
                        'showCustomerLoggedInElements',
                        'showCustomerLoggedInPaymentSourceElements'
                    ]);
                return this;
            },

            getSelectedPaymentMethod: function() {
                if (checkoutData.getSelectedPaymentMethod()) {
                    return checkoutData.getSelectedPaymentMethod();
                }

                if (methodList().length === 1 && methodList()[0].method === this.getCode()) {
                    return methodList()[0].method;
                }

                return null;
            },

            /**
             * Create Paydock widget
             */
            initWidget: function() {
                let selectedPaymentMethod = this.getSelectedPaymentMethod();
                if (selectedPaymentMethod === null || this.widgetLoaded || selectedPaymentMethod !== this.getCode()) {
                    return;
                }

                initCreditCardWidget(this.showCustomerLoggedInPaymentSourceElements);
                this.widgetLoaded = true;

                let customerIsLoggedIn = customer.isLoggedIn();
                if (customerIsLoggedIn) {
                    let paydockCustomerId = self.customer().paydock_customer_id;
                    if (typeof customer.customerData.extension_attributes !== 'undefined') {
                        paydockCustomerId = customer.customerData.extension_attributes.paydock_customer_id;
                    }
                    if (this.canSaveCard()) {
                        this.showCustomerLoggedInElements(true);
                        if (paydockCustomerId) {
                            this.initAccordian();
                        }
                    }
                }        
            },

            selectPaymentMethod: function() {

                selectPaymentMethodAction(this.getData());
                checkoutData.setSelectedPaymentMethod(this.item.method);

                if (!this.widgetLoaded) {

                    this.initWidget();
                }

                return true;
            },

            /**
             * Render Paydock widget if its not loaded
             */
            renderPaymentSource: function () {
                this.initWidget();
                return true;
            },

            /**
             * Render Accordian
             */
            initAccordian: function () {
                $("#paydock_cc-payment-method-content-wrapper").accordion({
                    activate: "0",
                    openedState: "active",
                    closedState: "inactive",
                    collapsible: false
                });
                return;
            },
    
            /**
             * Toggle Credit Card Widget
             */
            toggleCreditCardWidget: function (data, event) {
                let target = $(event.currentTarget).data('target');
                if (target) {
                    $('#' + target).click();
                }
                $('#paydock_cc-save').prop('checked', false);

                return;
            },

            placeThreeDSOrder: function () {
                let paymentToken = $('#paydock_cc-token').val(),
                    existingPaymentSource = true;

                place3DSOrderAction(paymentToken, existingPaymentSource);
            },

            getCode: function() {
                return creditCardModel.getCode();
            },

            paydockPlaceOrder: function() {
                return;
            },

            canSaveCard: function() {
                return creditCardModel.canSaveCard();
            },

            is3Ds: function() {
                return creditCardModel.is3ds();
            },

            /**
             * Get list of available CC types
             *
             * @returns {Array}
             */
            getCcAvailableTypes: function () {
                return window.checkoutConfig.payment.paydockCreditCard.availableCardTypes ?? [];
            },

            /**
             * Get payment icons
             * @param {String} type
             * @returns {Boolean}
             */
            getIcons: function (type) {
                return window.checkoutConfig.payment.paydockCreditCard.icons.hasOwnProperty(type) ?
                    window.checkoutConfig.payment.paydockCreditCard.icons[type]
                    : false;
            },

            /**
             * @returns {String}
             */
            getLogoSrc: function() {
                return window.checkoutConfig.payment.paydockCreditCard.logoSrc ?? '';
            },

            /**
             * @returns {Object}
             */
            getData: function() {
                return {
                    'method': this.item.method,
                    'additional_data': {
                        'payment_token': $('#paydock_cc-token').val(),
                        'cc_save': creditCardModel.canSaveCard() && $('#paydock_cc-save').is(':checked'),
                        'payment_source_id': $('#paydock_cc-payment_source_id').val(),
                        'charge_3ds_id': $('#paydock_cc-charge_3ds_id').val()
                    }
                };
            }
        });
    }
);

