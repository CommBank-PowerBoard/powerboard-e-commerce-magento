define([
    'Magento_Checkout/js/view/payment/default',
    'uiRegistry',
    'jquery',
    'ko',
    'Magento_Checkout/js/model/quote',
    'Paydock_Powerboard/js/model/error-handler',
    'Paydock_Powerboard_Widget',
    'Magento_Checkout/js/checkout-data',
    'Magento_Checkout/js/action/select-payment-method',
    'Magento_Checkout/js/model/totals',
    'CartObserver',
    'WalletMetaValidator'
], function (paymentDefault, registry, $, ko, quote, errorHandler, cba, checkoutData, selectPaymentMethodAction, totals, cartObserver, walletMetaValidator) {
    'use strict';

    return paymentDefault.extend({
        defaults: {
            template: 'Paydock_Powerboard/payment/afterpay-form'
        },
        
        buttonAfterpay: null,
        cartTotalAfterpay: null,
        cartObserverInstanceAfterpay: null,
        selectedPaymentMethodAfterpay: null,
        isWalletMetaValidAfterpay: null,
        walletMetaValidatorInstanceAfterpay: null,
        widgetLoadedAfterpay: false,
    
        initialize: function() {
            this._super();
            var self = this;
             
            this.cartTotalAfterpay = totals.getSegment("grand_total") ? totals.getSegment("grand_total").value : 0;
            
            this.selectedPaymentMethodAfterpay = ko.computed(function() {
                return quote.paymentMethod() ? quote.paymentMethod().method : null;
            }, this);

            this.cartObserverInstanceAfterpay = cartObserver.getInstance();
            
            this.walletMetaValidatorInstanceAfterpay = walletMetaValidator.getInstance();
            this.isWalletMetaValidAfterpay = this.walletMetaValidatorInstanceAfterpay.isValid; 

            if (this.selectedPaymentMethodAfterpay() === this.getCode()) {
                this.cartObserverInstanceAfterpay.setCallback(this.cartObserverCallbackAfterpay.bind(this));
                this.walletMetaValidatorInstanceAfterpay.setCallback(this.walletMetaCallbackAfterpay.bind(this));
            }

            this.selectedPaymentMethodAfterpay.subscribe(function (newMethod) {
                if (newMethod === self.getCode()) {
                    self.cartObserverInstanceAfterpay.setCallback(self.cartObserverCallbackAfterpay.bind(self));
                    self.walletMetaValidatorInstanceAfterpay.setCallback(self.walletMetaCallbackAfterpay.bind(self));
                }
            });
        },

        walletMetaCallbackAfterpay: function (isValid) {
            if(isValid) {
                this.setMeta();
            }
        },
        
        cartObserverCallbackAfterpay: function (newTotal) {
            this.cartTotalAfterpay = newTotal;
            this.setMeta();
        },

        loadAfterpayButton: function() {
            let gatewayId = window.checkoutConfig.payment.paydockAfterPay.gatewayId,
            publicKey = window.checkoutConfig.payment.paydockCreditCard.publicKey
            
            if (this.widgetLoadedAfterpay || !this.isWalletMetaValidAfterpay()) {

                return;
            }

            if (!publicKey || !publicKey.trim()) {
                console.error('Error loading widget - no public key defined');
                return;
            }

            this.buttonAfterpay = new cba.AfterpayCheckoutButton('#afterpay-checkout-button', publicKey, gatewayId);
            this.buttonAfterpay.setEnv(this.getEnvironment());
            this.buttonAfterpay.onFinishInsert('input[id="afterpay-checkout-button-payment-source-token"]', 'payment_source_token');
            this.buttonAfterpay.showEnhancedTrackingProtectionPopup(true);

            this.setMeta();

            this.buttonAfterpay.on("finish", (data) => {
                this.paydockPlaceOrder();
            });

            this.buttonAfterpay.on('error', function (data) {
                let messageContainer = registry.get('checkout.steps.billing-step.payment.payments-list.paydock_afterpay.checkout.steps.billing-step.payment.payments-list.paydock_afterpay.messages').messageContainer;
                errorHandler.process(data.error, messageContainer);
            });

            this.widgetLoadedAfterpay = true;
        },

        setMeta: function() {
            if(!this.buttonAfterpay) { return }
            

            let address = quote.shippingAddress();
            
            this.buttonAfterpay.setMeta({
                amount: this.cartTotalAfterpay,
                currency: window.checkoutConfig.quoteData.base_currency_code,
                reference: quote.getQuoteId(),
                email: quote.guestEmail || window.checkoutConfig.quoteData.customer_email,
                first_name: address.firstname,
                last_name: address.lastname,
                address_line: address.street[0] || '',
                address_line2: address.street[1] || '',
                address_city: address.city,
                address_state: address.region,
                address_postcode: address.postcode,
                address_country: address.countryId,
                phone: address.telephone
            });
        },

        getCode: function() {
            return this.item.method;
        },

        getEnvironment: function() {
            return window.checkoutConfig.payment.paydockCreditCard.environment || 'production_cba';
        },

        getLogoSrc: function() {
            return window.checkoutConfig.payment.paydockAfterPay.logoSrc || '';
        },

        getMpid: function() {
            return window.checkoutConfig.payment.paydockAfterPay.mpid || '';
        },

        getPlacementId: function() {
            return window.checkoutConfig.payment.paydockAfterPay.placementId || '';
        },

        getCurrencyCode: function() {
            return window.checkoutConfig.quoteData.base_currency_code || '';
        },

        getLocale: function() {
            return window.checkoutConfig.payment.paydockAfterPay.locale || '';
        },

        getQuoteTotal: function() {
            return quote.totals() ? quote.totals()['base_grand_total'] : 0;
        },

        selectPaymentMethod: function () {

            selectPaymentMethodAction(this.getData());
            checkoutData.setSelectedPaymentMethod(this.item.method);
            
            if (!this.widgetLoadedAfterpay && this.isWalletMetaValidAfterpay()) {
                this.loadAfterpayButton();
            }

            return true;
        },

        paydockPlaceOrder: function() {
            $('#paydock-afterpay-place-token-order').click();
            return;
        },

        getData: function() {
            return {
                'method': this.item.method,
                'additional_data': {
                    'payment_token': $('input[id="afterpay-checkout-button-payment-source-token"]').val()
                }
            };
        }
    });
});
