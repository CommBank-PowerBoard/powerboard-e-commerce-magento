define([
    "jquery",
    "ko",
    "Magento_Payment/js/view/payment/cc-form",
    "Paydock_Powerboard/js/action/applepay",
    "Magento_Checkout/js/action/select-payment-method",
    "Magento_Checkout/js/checkout-data",
    "CartObserver",
    "Magento_Checkout/js/model/quote",
    'WalletMetaValidator'
], function (
    $,
    ko,
    Component,
    loadApplePayAction,
    selectPaymentMethodAction,
    checkoutData,
    cartObserver,
    quote,
    walletMetaValidator
) {
    "use strict";

    return Component.extend({
        defaults: {
            template: "Paydock_Powerboard/payment/applepay-form",
        },

        cartTotalApplePay: null,
        cartObserverInstanceApplePay: null,
        isWalletMetaValidApplePay: null,
        widgetLoadedApplePay: false,
        walletMetaValidatorInstanceApplePay: null,
        selectedPaymentMethodApplePay: null,

        /**
         * {@inheritdoc}
         */
        initialize: function () {
            this._super();
            var self = this;
            
            this.walletMetaValidatorInstanceApplePay = walletMetaValidator.getInstance();
            this.isWalletMetaValidApplePay = this.walletMetaValidatorInstanceApplePay.isValid; 
            
            this.cartObserverInstanceApplePay = cartObserver.getInstance();

            // Observe changes in the selected payment method
            this.selectedPaymentMethodApplePay = ko.computed(function() {
                return quote.paymentMethod() ? quote.paymentMethod().method : null;
            });

            this.selectedPaymentMethodApplePay.subscribe(function(newMethod) {
                if (newMethod === self.getCode()) {
                    self.cartObserverInstanceApplePay.setCallback(self.cartObserverCallbackApplePay.bind(self));
                    self.walletMetaValidatorInstanceApplePay.setCallback(self.walletMetaCallbackApplePay.bind(self));
                } 
            });

            // If this payment method is already selected, initialize observer immediately
            if (this.selectedPaymentMethodApplePay() === this.getCode()) {
                this.cartObserverInstanceApplePay.setCallback(this.cartObserverCallbackApplePay.bind(this));
                this.walletMetaValidatorInstanceApplePay.setCallback(this.walletMetaCallbackApplePay.bind(this));
            }

            if (checkoutData.getSelectedPaymentMethod() === this.getCode() && !this.widgetLoadedApplePay) {
                this.loadApplePayButton();
            }
        },

        walletMetaCallbackApplePay: function (isValid) {
            if (isValid && !this.widgetLoadedApplePay) {
                this.loadApplePayButton();
            }
        },

        cartObserverCallbackApplePay: function (newTotal) {
            this.cartTotalApplePay = newTotal;
            this.widgetLoadedApplePay = false;
            loadApplePayAction();
        },

        /**
         * Create Apple pay widget
         */
        loadApplePayButton: function () {
            if (this.widgetLoadedApplePay || !this.isWalletMetaValidApplePay()) {
                return;
            }
            loadApplePayAction();
            this.widgetLoadedApplePay = true;
        },

        isChecked: ko.computed(function() {
            return quote.paymentMethod() ? quote.paymentMethod().method : null;
        }),

        /**
         * @returns {String}
         */
        getCode: function () {
            return this.item.method;
        },

        /**
         * @returns {String}
         */
        getLogoSrc: function () {
            return window.checkoutConfig.payment.paydockApplePay.logoSrc ?? "";
        },

        /**
         * @returns {Object}
         */
        getData: function () {
            return {
                method: this.item.method,
                additional_data: {
                    response_id: $('input[id="applepay-response-id"]').val(),
                },
            };
        },

        /**
         * @return {Boolean}
         */
        selectPaymentMethod: function () {

            selectPaymentMethodAction(this.getData());
            checkoutData.setSelectedPaymentMethod(this.item.method);
            
            if (!this.widgetLoadedApplePay) {
                setTimeout(() => {
                    this.loadApplePayButton();
                }, 1500);
            }

            return true;
        },
    });
});
