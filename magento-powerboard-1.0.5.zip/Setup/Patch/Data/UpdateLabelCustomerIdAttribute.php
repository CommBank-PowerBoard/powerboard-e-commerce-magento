<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Setup\Patch\Data;

use Magento\Customer\Model\Customer;
use Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Paydock\Powerboard\Api\Data\PaydockCustomerInterface;

class UpdateLabelCustomerIdAttribute implements DataPatchInterface {

    /**
     * ModuleDataSetupInterface
     *
     * @var ModuleDataSetupInterface
     */
    private $moduleDataSetup;

    /**
     * EavSetupFactory
     *
     * @var EavSetupFactory
     */
    private $eavSetupFactory;

    /**
     * @param ModuleDataSetupInterface $moduleDataSetup
     * @param EavSetupFactory $eavSetupFactory
     */
    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup,
        EavSetupFactory $eavSetupFactory
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
        $this->eavSetupFactory = $eavSetupFactory;
    }

    /**
     * {@inheritdoc}
     */
    public static function getDependencies()
    {
        return [];
    }

    /**
     * {@inheritdoc}
     */
    public function getAliases()
    {
        return [];
    }

    /**
     * {@inheritdoc}
     */
    public function apply() {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $this->moduleDataSetup]);

        $eavSetup->updateAttribute(
            Customer::ENTITY,
            PaydockCustomerInterface::CUSTOMER_ID,
            'frontend_label',
            'PowerBoard Customer ID'
        );

        $eavSetup->updateAttribute(
            Customer::ENTITY,
            PaydockCustomerInterface::CUSTOMER_ID,
            'note',
            'Customer ID in the PowerBoard system'
        );

        return $this;
    }
}
