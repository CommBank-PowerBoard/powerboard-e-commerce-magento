<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model\Config\Source;

class StyleShape implements \Magento\Framework\Data\OptionSourceInterface
{
    private const RECT = 'rect';
    private const PILL = 'pill';

    /**
     * @return array
     */
    public function toOptionArray(): array
    {
        return [
            [
                'value' => self::PILL,
                'label' => __('Pill')
            ],
            [
                'value' => self::RECT,
                'label' => __('Rect')
            ]
        ];
    }
}
