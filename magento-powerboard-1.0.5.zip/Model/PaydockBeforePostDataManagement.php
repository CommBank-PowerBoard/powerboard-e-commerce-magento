<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model;

use Magento\Framework\App\Area;
use Magento\Framework\App\State;
use Magento\Framework\Exception\LocalizedException;
use Paydock\Powerboard\Api\PaydockBeforePostDataManagementInterface;

class PaydockBeforePostDataManagement implements PaydockBeforePostDataManagementInterface
{
    private const ALLOWED_ENDPOINTS = [
        '/charges/i'
    ];

    private const DISALLOWED_ENDPOINTS = [
        '/refunds/i'
    ];
    
     /**
     * @var State
     */
    private State $state;

    /**
     * @param State $state
     */
    public function __construct(
        State $state
    ) {
        $this->state = $state;
    }

    /**
     * @inheritDoc
     */
    public function execute(array $postData, string $endpoint): array
    {
        /**
         * Note: no need to check if postData is empty, there are some calls
         * where postData is not populated eg. capture()
         */
        try {
            $areaCode = $this->state->getAreaCode();
        } catch (LocalizedException $e) {
            $areaCode = '';
        }
        
        if ($areaCode !== Area::AREA_ADMINHTML) {
            if (isset($postData['initialization_source'])) {
                unset($postData['initialization_source']);
            }
            
            return $postData;
        }

        if (array_key_exists('initialization_source', $postData)) {
            return $postData;
        }

        foreach (self::DISALLOWED_ENDPOINTS as $disallowedEndpoint) {
            if (preg_match($disallowedEndpoint, $endpoint)) {
                return $postData;
            }
        }

        foreach (self::ALLOWED_ENDPOINTS as $allowedEndpoint) {
            if (preg_match($allowedEndpoint, $endpoint)) {
                $postData['initialization_source'] = 'MOTO';
                return $postData;
            }
        }
        
        return $postData;
    }
}

