<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Paydock\Powerboard\Api\AfterPayConfigurationManagementInterface;
use Paydock\Powerboard\Api\ApplePayConfigurationManagementInterface;
use Paydock\Powerboard\Api\ConfigurationManagementInterface;
use Paydock\Powerboard\Api\CreditCardConfigurationManagementInterface;
use Paydock\Powerboard\Api\Data\PaydockAfterPayInterface;
use Paydock\Powerboard\Api\Data\PaydockApplePayInterface;
use Paydock\Powerboard\Api\Data\PaydockCreditCardInterface;
use Paydock\Powerboard\Api\Data\PaydockGooglePayInterface;
use Paydock\Powerboard\Api\Data\PaydockPaypalInterface;
use Paydock\Powerboard\Api\Data\PaydockZipMoneyInterface;
use Paydock\Powerboard\Api\GooglePayConfigurationManagementInterface;
use Paydock\Powerboard\Api\PaypalConfigurationManagementInterface;
use Paydock\Powerboard\Api\ZipMoneyConfigurationManagementInterface;

class ConfigurationManagement implements ConfigurationManagementInterface
{
    /**
     * @var ScopeConfigInterface
     */
    private ScopeConfigInterface $scopeConfig;

    /**
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(ScopeConfigInterface $scopeConfig)
    {
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * @inheritDoc
     */
    public function isActive(): bool
    {
        return (bool)$this->scopeConfig->getValue(self::XML_PATH_ACTIVE, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @inheritDoc
     */
    public function getBaseUrl(): string
    {
        return self::BASE_URL[$this->getEnvironment()];
    }

    /**
     * {@inheritdoc}
     */
    public function getEnvironment(): string
    {
        return $this->scopeConfig->getValue(self::XML_PATH_ENVIRONMENT, ScopeInterface::SCOPE_STORE) ?? '';
    }

    /**
     * {@inheritdoc}
     */
    public function getSecretKey(): string
    {
        return $this->scopeConfig->getValue(self::XML_PATH_SECRET_KEY, ScopeInterface::SCOPE_STORE) ?? '';
    }

    /**
     * {@inheritdoc}
     */
    public function getPublicKey(): string
    {
        return $this->scopeConfig->getValue(self::XML_PATH_PUBLIC_KEY, ScopeInterface::SCOPE_STORE) ?? '';
    }

    /**
     * {@inheritdoc}
     */
    public function getCss(): string
    {
        return $this->scopeConfig->getValue(self::XML_PATH_CSS, ScopeInterface::SCOPE_STORE) ?? '';
    }

    /**
     * {@inheritdoc}
     */
    public function getGatewayIdByPayment(string $paymentMethod): ?string
    {
        $path = null;
        switch ($paymentMethod) {
            case PaydockCreditCardInterface::METHOD_CODE:
                $path = CreditCardConfigurationManagementInterface::XML_PATH_GATEWAY_ID;
                break;
            case PaydockPaypalInterface::METHOD_CODE:
                $path = PaypalConfigurationManagementInterface::XML_PATH_GATEWAY_ID;
                break;
            case PaydockApplePayInterface::METHOD_CODE:
                $path = ApplePayConfigurationManagementInterface::XML_PATH_GATEWAY_ID;
                break;
            case PaydockGooglePayInterface::METHOD_CODE:
                $path = GooglePayConfigurationManagementInterface::XML_PATH_GATEWAY_ID;
                break;
            case PaydockAfterPayInterface::METHOD_CODE:
                $path = AfterPayConfigurationManagementInterface::XML_PATH_GATEWAY_ID;
                break;
            case PaydockZipMoneyInterface::METHOD_CODE:
                $path = ZipMoneyConfigurationManagementInterface::XML_PATH_GATEWAY_ID;
                break;
        }

        return $path ? $this->scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE) : '';
    }


}

