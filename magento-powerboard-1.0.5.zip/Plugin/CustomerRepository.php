<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Plugin;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Api\Data\CustomerInterface;
use Magento\Framework\Api\ExtensionAttributesFactory;
use Paydock\Powerboard\Api\Data\PaydockCustomerInterface;

class CustomerRepository
{
    /**
     * @var ExtensionAttributesFactory
     */
    private ExtensionAttributesFactory $extensionAttributesFactory;

    /**
     * @param ExtensionAttributesFactory $extensionAttributesFactory
     */
    public function __construct(ExtensionAttributesFactory $extensionAttributesFactory)
    {
        $this->extensionAttributesFactory = $extensionAttributesFactory;
    }

    /**
     * @param CustomerRepositoryInterface $subject
     * @param CustomerInterface $customer
     * @return CustomerInterface
     */
    public function afterGet(CustomerRepositoryInterface $subject, CustomerInterface $customer): CustomerInterface
    {
        return $this->addPaydockCustomerIdToExtensionAttributes($customer);
    }

    /**
     * @param CustomerRepositoryInterface $subject
     * @param CustomerInterface $customer
     * @return CustomerInterface
     */
    public function afterGetById(CustomerRepositoryInterface $subject, CustomerInterface $customer): CustomerInterface
    {
        return $this->addPaydockCustomerIdToExtensionAttributes($customer);
    }

    /**
     * @param CustomerInterface $customer
     * @return CustomerInterface
     */
    private function addPaydockCustomerIdToExtensionAttributes(CustomerInterface $customer): CustomerInterface
    {
        $extensionAttributes = $customer->getExtensionAttributes();
        if ($extensionAttributes === null) {
            $extensionAttributes = $this->extensionAttributesFactory->create(CustomerInterface::class);
        }

        $paydockCustomerId = $customer->getCustomAttribute(PaydockCustomerInterface::CUSTOMER_ID);
        if (!$paydockCustomerId) {
            return $customer;
        }

        $extensionAttributes->setPaydockCustomerId($paydockCustomerId->getValue());
        $customer->setExtensionAttributes($extensionAttributes);

        return $customer;
    }
}

