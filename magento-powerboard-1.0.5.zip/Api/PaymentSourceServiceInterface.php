<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Api;

interface PaymentSourceServiceInterface
{
    public const ENDPOINT_PAYMENT_SOURCES = '/v1/vault/payment_sources';

    /**
     * @param string $paymentToken
     * @return string|null
     */
    public function getSessionToken(string $paymentToken): ?string;

    /**
     * @param string $paymentToken
     * @return string|null
     */
    public function getPermanentToken(string $paymentToken): ?string;
}

