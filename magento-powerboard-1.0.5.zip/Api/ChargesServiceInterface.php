<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Api;

use Magento\Quote\Model\Quote;
use Magento\Sales\Api\Data\OrderInterface;

interface ChargesServiceInterface
{
    public const ENDPOINT_PREAUTH = '/v1/charges?capture=false';
    public const ENDPOINT_CAPTURE = '/v1/charges/%s/capture';
    public const ENDPOINT_CHARGES_3DS = '/v1/charges/3ds';
    public const ENDPOINT_CHARGES_WALLET = '/v1/charges/wallet';
    public const ENDPOINT_REFUNDS = '/v1/charges/%s/refunds';
    public const ENDPOINT_DIRECT_CAPTURE = '/v1/charges';

    /**
     * @param OrderInterface $order
     * @param string $vaultToken
     * @return string
     */
    public function preAuthoriseWithVaultToken(OrderInterface $order, string $vaultToken): string;

    /**
     * @param OrderInterface $order
     * @param string $charge3dsId
     * @return string
     */
    public function preAuthoriseWith3dsChargeId(OrderInterface $order, string $charge3dsId): string;

    /**
     * @param string $chargeId
     * @return array
     */
    public function capture(string $chargeId): array;

    /**
     * @param OrderInterface $order
     * @param string $token
     * @return array
     */
    public function directCapture(OrderInterface $order, string $token): array;

    /**
     * @param Quote $quote
     * @param string $vaultToken
     * @param array $browserDetails
     * @return array
     */
    public function place3dsPreAuthRequest(Quote $quote, string $vaultToken, array $browserDetails): array;

    /**
     * @param Quote $quote
     * @return array
     */
    public function getWalletToken(Quote $quote): array;

    /**
     * @param string $chargeId
     * @param float $amount
     * @param bool $fullRefund
     * @return array
     */
    public function placeRefund(string $chargeId, float $amount, bool $fullRefund): array;

    /**
     * @param OrderInterface $order
     * @param string $vaultToken
     * @return array
     */
    public function paymentSourceDirectCharge(OrderInterface $order, string $vaultToken): array;

    /**
     * @param OrderInterface $order
     * @param string $vaultToken
     * @return array
     */
    public function placeDirectChargeWithVaultToken(OrderInterface $order, string $vaultToken): array;

    /**
     * @param OrderInterface $order
     * @param string $charge3dsId
     * @return array
     */
    public function placeDirectChargeWith3dsChargeId(OrderInterface $order, string $charge3dsId): array;

    /**
     * @param OrderInterface $order
     * @param string $vaultToken
     * @return array
     */
    public function directCharge(OrderInterface $order, string $vaultToken): array;
}

