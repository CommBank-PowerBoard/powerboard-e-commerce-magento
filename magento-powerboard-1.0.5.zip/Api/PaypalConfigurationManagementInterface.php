<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Api;

interface PaypalConfigurationManagementInterface
{
    public const DEFAULT_XML_PATH_ACTIVE = 1;
    public const DEFAULT_XML_PATH_TITLE = 'PayPal';
    public const DEFAULT_XML_PATH_GATEWAY_ID = '';
    public const DEFAULT_XML_PATH_STYLE_LAYOUT = 'horizontal';
    public const DEFAULT_XML_PATH_STYLE_COLOR = 'gold';
    public const DEFAULT_XML_PATH_STYLE_SHAPE = 'rect';
    public const DEFAULT_XML_PATH_STYLE_TAGLINE = '0';
    public const DEFAULT_XML_PATH_STYLE_LABEL = '';
    public const DEFAULT_XML_PATH_SORT_ORDER = '50';
    public const XML_PATH_ACTIVE = 'payment/paydock_paypal/active';
    public const XML_PATH_TITLE = 'payment/paydock_paypal/title';
    public const XML_PATH_GATEWAY_ID = 'payment/paydock_paypal/gateway_id';
    public const XML_PATH_PAY_LATER = 'payment/paydock_paypal/pay_later';
    public const XML_PATH_STYLE_COLOR = 'payment/paydock_paypal/style_color';
    public const XML_PATH_STYLE_TAGLINE = 'payment/paydock_paypal/style_tagline';
    public const XML_PATH_STYLE_LABEL = 'payment/paydock_paypal/style_label';

    /**
     * @return bool
     */
    public function isActive(): bool;

    /**
     * @return string
     */
    public function getTitle(): string;

    /**
     * @return string
     */
    public function getGatewayId(): string;

    /**
     * @return bool
     */
    public function isPayLater(): bool;

    /**
     * @return string
     */
    public function getStyleLayout(): string;

    /**
     * @return string
     */
    public function getStyleColor(): string;

    /**
     * @return string
     */
    public function getStyleShape(): string;

    /**
     * @return bool
     */
    public function isStyleTagline(): bool;

    /**
     * @return string
     */
    public function getStyleLabel(): string;
}
