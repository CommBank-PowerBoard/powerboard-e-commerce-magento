<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway;

use Magento\Customer\Api\AddressRepositoryInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Api\Data\CustomerInterface;
use Magento\Framework\App\Area;
use Magento\Framework\App\State;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Sales\Api\Data\OrderInterface;
use Paydock\Powerboard\Api\CustomersServiceInterface;
use Paydock\Powerboard\Api\Data\PaydockCustomerInterface;
use Paydock\Powerboard\Api\GatewayServiceInterface;
use Paydock\Powerboard\Model\CreditCardConfigurationManagement;
use Psr\Log\LoggerInterface;

class CustomersService implements CustomersServiceInterface
{
    /**
     * @var GatewayServiceInterface
     */
    private GatewayServiceInterface $gatewayService;

    /**
     * @var AddressRepositoryInterface
     */
    private AddressRepositoryInterface $addressRepository;

    /**
     * @var CreditCardConfigurationManagement
     */
    private CreditCardConfigurationManagement $creditCardConfigurationManagement;

    /**
     * @var State
     */
    private State $state;

    /**
     * @var Json
     */
    private Json $json;

    /**
     * @var CustomerRepositoryInterface
     */
    private CustomerRepositoryInterface $customerRepository;

    /**
     * @var LoggerInterface
     */
    private LoggerInterface $logger;

    /**
     * @param GatewayServiceInterface $gatewayService
     * @param AddressRepositoryInterface $addressRepository
     * @param CreditCardConfigurationManagement $creditCardConfigurationManagement
     * @param State $state
     * @param Json $json
     * @param CustomerRepositoryInterface $customerRepository
     * @param LoggerInterface $logger
     */
    public function __construct(
        GatewayServiceInterface $gatewayService,
        AddressRepositoryInterface $addressRepository,
        CreditCardConfigurationManagement $creditCardConfigurationManagement,
        State $state,
        Json $json,
        CustomerRepositoryInterface $customerRepository,
        LoggerInterface $logger
    ) {
        $this->gatewayService = $gatewayService;
        $this->addressRepository = $addressRepository;
        $this->creditCardConfigurationManagement = $creditCardConfigurationManagement;
        $this->state = $state;
        $this->json = $json;
        $this->customerRepository = $customerRepository;
        $this->logger = $logger;
    }

    /**
     * @inheritDoc
     */
    public function getCustomerById(string $paydockCustomerId): ?array
    {
        $endpoint = sprintf(self::ENDPOINT_CUSTOMERS_GET, $paydockCustomerId);
        $response = $this->gatewayService->get($endpoint);

        return $response ?? null;
    }

    /**
     * @inheritDoc
     */
    public function getCustomerIdById(string $paydockCustomerId): ?string
    {
        $response = $this->getCustomerById($paydockCustomerId);

        if ($response === null) {
            return null;
        }

        return $response['data'][0]['_id'] ?? null;
    }

    /**
     * @inheritDoc
     */
    public function getPaymentSourcesById(string $paydockCustomerId): ?string
    {
        $response = $this->getCustomerById($paydockCustomerId);

        return isset($response['data'][0]['payment_sources']) ? $this->json->serialize($response['data'][0]['payment_sources']) : null;
    }

    /**
     * @inheritDoc
     */
    public function getVaultTokenById(string $paydockCustomerId): ?string
    {
        $customer = $this->getCustomerById($paydockCustomerId);

        if (!$customer) {
            return null;
        }

        if (!isset($customer['data'][0]['payment_sources'])) {
            return null;
        }

        if (!isset($customer['data'][0]['default_source'])) {
            return null;
        }

        $defaultPaymentSource = $customer['data'][0]['default_source'];
        foreach($customer['data'][0]['payment_sources'] as $paymentSource) {
            if ($defaultPaymentSource === $paymentSource['_id']) {
                return $paymentSource['vault_token'];
            }
        }

        return null;
    }

    /**
     * @inheritDoc
     */
    public function getQueryTokenById(string $paydockCustomerId): ?string
    {
        $response = $this->getCustomerById($paydockCustomerId);
        $areaCode = null;
        try {
            $areaCode = $this->state->getAreaCode();
        } catch (LocalizedException $e) {
        }

        if ($areaCode === Area::AREA_WEBAPI_REST) {
            $response = ['query_token' => $response['query_token'] ?? null];
            return $this->json->serialize($response);
        } else {
            return $response['query_token'] ?? null;
        }
    }

    /**
     * @inheritDoc
     * @throws LocalizedException
     */
    public function createCustomer(CartInterface | OrderInterface $order, string $vaultToken): string
    {
        $customerId = (int)$order->getCustomerId();
        $customer = $this->getMagentoCustomerById($customerId);
        $endpoint = self::ENDPOINT_CUSTOMERS;
        
        $phone = $this->getPhoneNumber($customer, $order);
        if (!$phone) {
            throw new LocalizedException(__("Error creating customer - missing phone number"));
        }
        
        $customerPayload = $this->buildCustomerPayload($customer, $phone, $vaultToken);
        $response = $this->gatewayService->post($endpoint, $customerPayload);

        if ($response === null) {
            throw new LocalizedException(__("Error creating customer at gateway"));
        }

        $paydockCustomerId = $response['data']['_id'];

        $this->savePaydockCustomerId($customer, $paydockCustomerId);

        return $paydockCustomerId;
    }

    /**
    * @param CustomerInterface $customer
    * @param string $paydockCustomerId
    * @return void
    */
    private function savePaydockCustomerId(CustomerInterface $customer, string $paydockCustomerId): void
    {
        try {
            $customer->setCustomAttribute(PaydockCustomerInterface::CUSTOMER_ID, $paydockCustomerId);
            $this->customerRepository->save($customer);
        } catch (LocalizedException $e) {
            $this->logger->critical(__("Unable to save paydock customer ID to customer: %1", $e->getMessage()));
            return;
        }
    }

    /**
     * @param CustomerInterface $customer
     * @param string $phone
     * @param string $vaultToken
     * @return array
     */
    private function buildCustomerPayload(CustomerInterface $customer, string $phone, string $vaultToken): array
    {
        return [
            'first_name' => $customer->getFirstname(),
            'last_name' => $customer->getLastname(),
            'email' => $customer->getEmail(),
            'phone' => $phone,
            'payment_source' => [
                'vault_token' => $vaultToken
            ]
        ];
    }

    /**
     * @param int $customerId
     * @return CustomerInterface
     * @throws LocalizedException
     */
    private function getMagentoCustomerById(int $customerId): CustomerInterface
    {
        try {
            $customer = $this->customerRepository->getById($customerId);
        } catch (NoSuchEntityException $e) {
            throw new LocalizedException(__('Customer not found'));
        }

        return $customer;
    }

    /**
     * @param CustomerInterface $customer
     * @param CartInterface|OrderInterface $order
     * @return string|null
     */
    private function getPhoneNumber(CustomerInterface $customer, CartInterface | OrderInterface $order): ?string
    {
        if ($customer->getDefaultBilling()) {
            return $this->getPhoneForCustomer($customer);
        }
        
        return $this->getPhoneForOrder($order);
    }

    /**
     * @param CustomerInterface $customer
     * @return string
     */
    private function getPhoneForCustomer(CustomerInterface $customer): string
    {
        $billingAddressId = $customer->getDefaultBilling();
        if (!$billingAddressId) {
            return '';
        }

        try {
            $billingAddress = $this->addressRepository->getById($billingAddressId);
            return $billingAddress->getTelephone() ?? '';
        } catch (LocalizedException $e) {
            return '';
        }
    }

    /**
     * @param CartInterface|OrderInterface $order
     * @return string
     */
    private function getPhoneForOrder(CartInterface | OrderInterface $order): string
    {
        $billingAddress = $order->getBillingAddress();
        return $billingAddress->getTelephone();
    }

    /**
     * @inheritDoc
     */
    public function addPaymentSource(string $paydockCustomerId, array $paymentSourcedetail, ?string $defaultPaymentSourceId = null): ?array
    {
        $endpoint = sprintf(self::ENDPOINT_CUSTOMERS_POST, $paydockCustomerId);
        $postData = [
            'payment_source' => $paymentSourcedetail
        ];
        if ($defaultPaymentSourceId) {
            $postData['default_source'] = $defaultPaymentSourceId;
        }
        $response = $this->gatewayService->post($endpoint, $postData);

        return $response ?? null;
    }

    /**
     * @inheritDoc
     */
    public function addVaultTokenPaymentSource(string $paydockCustomerId, string $vaultToken): ?array
    {
        if (!$vaultToken) {
            return null;
        }
        $paymentSourcedetail = [
            'vault_token' => $vaultToken
        ];
        return $this->addPaymentSource($paydockCustomerId, $paymentSourcedetail);
    }

    /**
     * @inheritDoc
     */
    public function getCustomerPaymentSourceById(string $paydockCustomerId): ?string
    {

        $customer = $this->getCustomerById($paydockCustomerId);
        $response = $customer ? $this->buildCustomerCreditCardPaymentSourceResponse($customer) : null;
        return $this->json->serialize($response);
    }

    /**
     * @param array $customer
     * @return array
     */
    private function buildCustomerCreditCardPaymentSourceResponse(array $customer): array
    {
        $response = [
            'query_token' => $customer['query_token'] ?? null,
            'data' => [
                [
                    'payment_sources' => []
                ]
            ]
        ];
        if (isset($customer['data'][0]['payment_sources'])) {
            $creditCardGatewayId = $this->creditCardConfigurationManagement->getGatewayId();
            $paymentSourcesArray = [];
            foreach($customer['data'][0]['payment_sources'] as $paymentSource) {
                if ($paymentSource['status'] === 'active') {
                    $paymentSourcesArray[] = $paymentSource;
                }
            }
            $response['data'][0]['payment_sources'] = $paymentSourcesArray;
        }
        return $response;
    }

    /**
     * @inheritDoc
     */
    public function saveVaultTokenToCustomerPaymentSource(string $paydockCustomerId, string $vaultToken): ?string
    {
        try {
            if (empty($paydockCustomerId)) {
                $this->logger->critical(__("Error generating vault token: Unable to retrieve paydock customer ID"));
                return null;
            }
            $customer = $this->addVaultTokenPaymentSource($paydockCustomerId, $vaultToken);
            if (empty($customer)) {
                $this->logger->critical(__("Error generating vault token: Unable to add vault token to customer"));
                return null;
            }
            return $this->getVaultTokenPaymentSource($customer, $vaultToken);
        } catch (LocalizedException $e) {
            $this->logger->critical(__("Error generating vault token: %1", $e->getMessage()));
            return null;
        }
    }

    /**
     * @param array $customer
     * @param string $vaultToken
     * @return string|null
     */
    private function getVaultTokenPaymentSource(array $customer, string $vaultToken): ?string
    {
        $paymentSources = $customer['data']['payment_sources'] ?? [];
        foreach ($paymentSources as $paymentSource) {
            if (
                $paymentSource['status'] === 'active'
                && isset($paymentSource['vault_token'])
                && $paymentSource['vault_token'] === $vaultToken
            ) {
                return $vaultToken;
            }
        }
        return null;
    }
}

