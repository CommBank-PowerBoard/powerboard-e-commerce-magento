<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway\Http\Client;

use Magento\Framework\Exception\LocalizedException;

class TransactionRefund extends AbstractTransaction
{
    /**
     * @inheritdoc
     * @throws LocalizedException
     */
    protected function process(array $data): array
    {
        $chargeId = $data['charge_id'];
        $amount = $data['amount'];
        $full = $data['full'] ?? true;

        if ($chargeId === null || $amount === null) {
            throw new LocalizedException(__('Unable to proceed. One of the required parameters is empty.'));
        }

        return $this->chargesService->placeRefund($chargeId, $amount, $full);
    }
}

