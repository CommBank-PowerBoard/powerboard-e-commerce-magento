<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway\Http\Client;

use Magento\Framework\Exception\LocalizedException;

class TransactionAuthorise extends AbstractTransaction
{
    /**
     * @inheritdoc
     * @throws LocalizedException
     */
    protected function process(array $data): array
    {
        $payment = $data['payment'];
        $vaultToken = $data['vault_token'] ?? '';
        $charge3dsId = $data['charge_3ds_id'] ?? '';

        if ($vaultToken === null && $charge3dsId === null) {
            throw new LocalizedException(__('Unable to proceed. Vault token and charge ID are empty.'));
        }
        
        $authoriseResponse = null;
        
        if ($charge3dsId && $this->creditCardConfigurationManagement->is3DS()) {
            $authoriseResponse = [
                'data' => [
                    '_id' => $this->chargesService->preAuthoriseWith3dsChargeId($payment->getOrder(), $charge3dsId)
                ]
            ];
        }

        if ($vaultToken) {
            $authoriseResponse = [
                'data' => [
                    '_id' => $this->chargesService->preAuthoriseWithVaultToken($payment->getOrder(), $vaultToken)
                ]
            ];
        }
        
        if (!$authoriseResponse) {
            throw new LocalizedException(__("Error processing authorise transaction"));
        }

        if ($this->paymentManagement->canSaveCard($payment) && !$this->creditCardConfigurationManagement->is3DS()) {
            try {
                $this->savePaymentSource($payment, $vaultToken);
            } catch (LocalizedException $e) {
                $this->logger->critical(__("Error saving payment source: %1". $e->getMessage()));
            }
        }
        
        return $authoriseResponse;
    }
}

