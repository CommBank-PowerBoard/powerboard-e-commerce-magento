<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway\Http\Client;

use Magento\Framework\Exception\LocalizedException;

class WalletTransactionSale extends AbstractTransaction
{
    /**
     * @inheritdoc
     * @throws LocalizedException
     */
    protected function process(array $data): array
    {
        $lastTransactionId = $data['id'] ?? '';
        if ($lastTransactionId === null) {
            throw new LocalizedException(__('Unable to proceed. No response from wallet.'));
        }

        /**
         * This will be handled by PaymentDetailsHandler and TransactionIdHandler
         * @see di.xml
         */
        return [
            'data' => [
                '_id' => $lastTransactionId
            ]
        ];
    }
}

