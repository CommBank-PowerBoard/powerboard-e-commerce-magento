<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway\Http\Client;

use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Api\Data\OrderPaymentInterface;

class TransactionSale extends AbstractTransaction
{
    /**
     * @inheritdoc
     * @throws LocalizedException
     */
    protected function process(array $data): array
    {
        $chargeId = $data['charge_id'] ?? '';

        if ($chargeId) {
            // Capture a pre-authorised request
            return $this->chargesService->capture($chargeId);
        }

        $payment = $data['payment'];
        $vaultToken = $data['vault_token'] ?? null;
        $charge3dsId = $data['charge_3ds_id'] ?? null;

        if ($vaultToken === null && $charge3dsId === null) {
            throw new LocalizedException(__('Unable to proceed. Vault token and charge ID are empty.'));
        }
        
        if ($charge3dsId && $this->creditCardConfigurationManagement->is3DS()) {
            return $this->process3dsCharge($payment, $vaultToken, $charge3dsId);
        }
        
        if ($vaultToken) {
            if ($this->creditCardConfigurationManagement->canDirectCharge()) {
                return $this->processDirectCharge($payment, $vaultToken);
            }

            return $this->processPreauthCapture($payment, $vaultToken);
        }
        
        throw new LocalizedException(__("Error processing sale transaction"));
    }

    /**
     * @param OrderPaymentInterface $payment
     * @param string $vaultToken
     * @param string $charge3dsId
     * @return array
     * @throws LocalizedException
     */
    private function process3dsCharge(OrderPaymentInterface $payment, string $vaultToken, string $charge3dsId): array
    {
        if ($this->creditCardConfigurationManagement->canDirectCharge()) {
            $chargeResponse = $this->chargesService->placeDirectChargeWith3dsChargeId($payment->getOrder(), $charge3dsId);
        } else {
            $chargeId = $this->chargesService->preAuthoriseWith3dsChargeId($payment->getOrder(), $charge3dsId);
            $this->eventManager->dispatch('paydock_capture_before', ['payment' => $payment, 'charge_id' => $chargeId]);
            $chargeResponse = $this->chargesService->capture($chargeId);
        }

        if ($this->paymentManagement->canSaveCard($payment)) {
            try {
                $this->savePaymentSource($payment, $vaultToken);
            } catch (LocalizedException $e) {
                $this->logger->critical(__("Error saving payment source: %1". $e->getMessage()));
            }
        }
        
        return $chargeResponse;
    }

    /**
     * @param OrderPaymentInterface $payment
     * @param string $vaultToken
     * @return array
     * @throws LocalizedException
     */
    private function processDirectCharge(OrderPaymentInterface $payment, string $vaultToken): array
    {
        $saleResponse = $this->chargesService->placeDirectChargeWithVaultToken($payment->getOrder(), $vaultToken);

        if ($this->paymentManagement->canSaveCard($payment) && !$this->creditCardConfigurationManagement->is3DS()) {
            try {
                $this->savePaymentSource($payment, $vaultToken);
            } catch (LocalizedException $e) {
                $this->logger->critical(__("Error saving payment source: %1". $e->getMessage()));
            }
        }

        return $saleResponse;
    }

    /**
     * @param OrderPaymentInterface $payment
     * @param string $vaultToken
     * @return array
     * @throws LocalizedException
     */
    private function processPreauthCapture(OrderPaymentInterface $payment, string $vaultToken): array
    {
        $chargeId = $this->chargesService->preAuthoriseWithVaultToken($payment->getOrder(), $vaultToken);
        $this->eventManager->dispatch('paydock_capture_before', ['payment' => $payment, 'charge_id' => $chargeId]);

        $saleResponse = $this->chargesService->capture($chargeId);

        if ($this->paymentManagement->canSaveCard($payment) && !$this->creditCardConfigurationManagement->is3DS()) {
            try {
                $this->savePaymentSource($payment, $vaultToken);
            } catch (LocalizedException $e) {
                $this->logger->critical(__("Error saving payment source: %1". $e->getMessage()));
            }
        }

        return $saleResponse;
    }
}

