<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway;

use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\HTTP\Client\Curl;
use Magento\Framework\Module\ModuleListInterface;
use Magento\Framework\Serialize\Serializer\Json;
use Paydock\Powerboard\Api\ConfigurationManagementInterface;
use Paydock\Powerboard\Api\GatewayServiceInterface;
use Paydock\Powerboard\Api\PaydockBeforePostDataManagementInterface;
use Paydock\Powerboard\Exception\GatewayException;
use Psr\Log\LoggerInterface;

class GatewayService implements GatewayServiceInterface
{
    /**
     * @var ConfigurationManagementInterface
     */
    private ConfigurationManagementInterface $configurationManagement;

    /**
     * @var Json
     */
    private Json $json;

    /**
     * @var Curl
     */
    private Curl $curl;

    /**
     * @var LoggerInterface
     */
    private LoggerInterface $logger;

    /**
     * @var PaydockBeforePostDataManagementInterface
     */
    private PaydockBeforePostDataManagementInterface $paydockBeforePostDataManagement;

    /**
     * @var ProductMetadataInterface
     */
    private ProductMetadataInterface $productMetadata;

    /**
     * @var ModuleListInterface
     */
    private ModuleListInterface $moduleList;

    /**
     * @param ConfigurationManagementInterface $configurationManagement
     * @param Json $json
     * @param Curl $curl
     * @param LoggerInterface $logger
     * @param PaydockBeforePostDataManagementInterface $paydockBeforePostDataManagement
     * @param ProductMetadataInterface $productMetadata
     * @param ModuleListInterface $moduleList
     */
    public function __construct(
        ConfigurationManagementInterface $configurationManagement,
        Json $json,
        Curl $curl,
        LoggerInterface $logger,
        PaydockBeforePostDataManagementInterface $paydockBeforePostDataManagement,
        ProductMetadataInterface $productMetadata,
        ModuleListInterface $moduleList
    ) {
        $this->configurationManagement = $configurationManagement;
        $this->json = $json;
        $this->curl = $curl;
        $this->logger = $logger;
        $this->paydockBeforePostDataManagement = $paydockBeforePostDataManagement;
        $this->productMetadata = $productMetadata;
        $this->moduleList = $moduleList;
    }

    /**
     * @inheritDoc
     */
    public function get(string $endpoint, array $headers = []): ?array
    {
        $this->configureCurl($headers);
        $this->buildHeaders();
        $uri = sprintf('%s%s', $this->configurationManagement->getBaseUrl(), $endpoint);
        try {
            $this->curl->get($uri);
            return $this->parseResponse(true);
        } catch (GatewayException $e) {
            $this->logger->critical(__("Error making GET request to %1", $endpoint));
            return null;
        }
    }

    /**
     * @inheritDoc
     */
    public function post(string $endpoint, array $postData = [], array $headers = []): ?array
    {
        $this->configureCurl($headers);
        $this->buildHeaders();
        $uri = sprintf('%s%s', $this->configurationManagement->getBaseUrl(), $endpoint);
        try {
            $postData = $this->paydockBeforePostDataManagement->execute($postData, $endpoint);
            $serialisedPostData = empty($postData) ? '{}' : $this->json->serialize($postData);
            $this->curl->post($uri, $serialisedPostData);
            return $this->parseResponse(true);
        } catch (GatewayException $e) {
            $this->logger->critical(__("Error making POST request to %1: %2", $uri, $e->getMessage()));
            return null;
        }
    }

    /**
     * @param array $headers
     * @return void
     */
    private function configureCurl(array $headers = []): void
    {
        $this->buildHeaders($headers);
        $this->curl->setOption(CURLOPT_ENCODING, '');
        $this->curl->setOption(CURLOPT_RETURNTRANSFER, true);
        $this->curl->setOption(CURLOPT_MAXREDIRS, 3);
        $this->curl->setOption(CURLOPT_TIMEOUT, 30);
        $this->curl->setOption(CURLOPT_FOLLOWLOCATION, true);
        $this->curl->setOption(CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
    }

    /**
     * @param array $headers
     * @return void
     */
    private function buildHeaders(array $headers = []): void
    {
        $headers['x-user-secret-key'] = $this->configurationManagement->getSecretKey();
        $headers['Content-Type'] = 'application/json';
        $headers['X-Magento-Meta'] = sprintf(
            'V%s_%s_%s',
            $this->getModuleVersion(),
            $this->getEdition(),
            $this->productMetadata->getVersion()
        );

        $this->curl->setHeaders($headers);
    }

    /**
     * @return string
     */
    private function getEdition(): string
    {
        $edition = $this->productMetadata->getEdition();
        return match (strtoupper($edition)) {
            'COMMUNITY' => 'OPENSOURCE',
            'ENTERPRISE' => 'COMMERCE',
            default => 'UNKNOWN',
        };
    }

    /**
     * @return string
     */
    private function getModuleVersion(): string
    {
        $module = $this->moduleList->getOne('Paydock_Powerboard');
        return $module['setup_version'];
    }

    /**
     * @param bool $needsResponse
     * @return array|null
     * @throws GatewayException
     */
    private function parseResponse(bool $needsResponse = false): ?array
    {
        if ($this->curl->getStatus() !== 200 && $this->curl->getStatus() !== 201) {
            $message = __(
                "(%1) Gateway returned error status",
                $this->curl->getStatus()
            );

            throw new GatewayException($message);
        }

        if ($needsResponse && empty($this->curl->getBody())) {
            $message = __(
                "(%1) Gateway returned empty response",
                $this->curl->getStatus(),
            );

            throw new GatewayException($message);
        }

        $response = $this->json->unserialize($this->curl->getBody());
        if (!array_key_exists('status', $response)) {
            $message = __(
                "Unknown response received from Gateway"
            );

            throw new GatewayException($message);
        }

        if ((int)$response['status'] !== 200 && (int)$response['status'] !== 201) {
            $message = __(
                "(%1) Error from Gateway: %2",
                $response['status'],
                $response['error'] ?? 'Unknown error'
            );

            throw new GatewayException($message);
        }

        if (!$needsResponse) {
            return null;
        }

        return $response['resource'];
    }
}

