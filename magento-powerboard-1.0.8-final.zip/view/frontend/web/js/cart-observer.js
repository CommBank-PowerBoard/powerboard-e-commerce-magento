define(['ko', 'Magento_Checkout/js/model/totals'], function (ko, totals) {
    "use strict";

    var skipTotals = false;

    var cartTotal = ko.computed(function() {
        return totals.getSegment("grand_total") ? totals.getSegment("grand_total").value : 0;
    })

    var cartTotalChanged = ko.observable(totals.getSegment("grand_total") ? totals.getSegment("grand_total").value : 0);
    var shippingChanged = ko.observable(0);

    function subscribe() {
        totals.totals.subscribe(function () {

            if (skipTotals) {
                return;
            }

            var grandTotal = totals.getSegment("grand_total") ? totals.getSegment("grand_total").value : 0;
            cartTotalChanged(grandTotal);
        });
    }

    function setSkipTotalsFlag(value) {
        skipTotals = value;
    }

    subscribe();

    return {
        cartTotal: cartTotal,
        cartTotalChanged: cartTotalChanged,
        shippingChanged: shippingChanged,
        setSkipTotalsFlag: setSkipTotalsFlag
    };
});
