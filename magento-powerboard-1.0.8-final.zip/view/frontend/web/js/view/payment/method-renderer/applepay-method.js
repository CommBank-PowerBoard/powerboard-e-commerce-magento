define([
    "jquery",
    "ko",
    "Magento_Payment/js/view/payment/cc-form",
    "Paydock_Powerboard/js/action/applepay",
    "Magento_Checkout/js/action/select-payment-method",
    "Magento_Checkout/js/checkout-data",
    "CartObserver",
    'WalletMetaValidator'
], function (
    $,
    ko,
    Component,
    loadApplePayAction,
    selectPaymentMethodAction,
    checkoutData,
    cartObserver,
    walletMetaValidator
) {
    "use strict";

    return Component.extend({
        defaults: {
            template: "Paydock_Powerboard/payment/applepay-form",
        },
        widgetLoadedApplePay: false,
        applePayPreviousTotal: null,
        isValidationPassed: ko.observable(true),

        initialize: function () {
            this._super();

            this.subscribeToFormUpdates();
            this.subscribeToCartUpdates();
            this.loadApplePayButton();
        },

        subscribeToFormUpdates: function () {
            walletMetaValidator.isValid.subscribe((isValid) => {
                this.isValidationPassed(isValid);
            });
        },

        subscribeToCartUpdates: function () {
            cartObserver.cartTotalChanged.subscribe((newTotal) => {     
                this.loadApplePayButton();
            });

            cartObserver.shippingChanged.subscribe((newTotal) => {   
                this.loadApplePayButton();
            });
        },

        loadApplePayButton: function () {
            if (checkoutData.getSelectedPaymentMethod() !== this.getCode()) {
                return;
            }

            if(this.applePayPreviousTotal != cartObserver.cartTotal()) {
                $('#paydock_applepay_widget').empty();
                this.widgetLoadedApplePay = false;
            }

            if (this.widgetLoadedApplePay || !this.isValidationPassed) {
                return;
            }

            $('#paydock_applepay_widget').empty()
            loadApplePayAction();

            this.widgetLoadedApplePay = true;
            this.applePayPreviousTotal = cartObserver.cartTotal();
        },

        isChecked: ko.computed(function() {
            return checkoutData.getSelectedPaymentMethod();
        }),

        getCode: function () {
            return this.item.method;
        },

        getLogoSrc: function () {
            return window.checkoutConfig.payment.paydockApplePay.logoSrc ?? "";
        },

        getData: function () {
            return {
                method: this.item.method,
                additional_data: {
                    response_id: $('input[id="applepay-response-id"]').val(),
                },
            };
        },

        selectPaymentMethod: function () {
            selectPaymentMethodAction(this.getData());
            checkoutData.setSelectedPaymentMethod(this.getCode());
            
            setTimeout(() => {
                this.loadApplePayButton();
            }, 1500);

            return true;
        },
    });
});
