define([
    'Magento_Checkout/js/view/payment/default',
    'uiRegistry',
    'jquery',
    'ko',
    'Magento_Checkout/js/model/quote',
    'Paydock_Powerboard/js/model/error-handler',
    'Paydock_Powerboard_Widget',
    'Magento_Checkout/js/checkout-data',
    'Magento_Checkout/js/action/select-payment-method',
    'CartObserver',
    'WalletMetaValidator'
], function (paymentDefault, registry, $, ko, quote, errorHandler, cba, checkoutData, selectPaymentMethodAction, cartObserver, walletMetaValidator) {
    'use strict';

    return paymentDefault.extend({
        defaults: {
            template: 'Paydock_Powerboard/payment/afterpay-form'
        },
        
        buttonAfterpay: null,
        widgetLoadedAfterpay: false,
        isValidationPassed: ko.observable(true),

        initialize: function() {
            this._super();
             
            this.subscribeToFormUpdates();
            this.subscribeToCartUpdates();
        },

        subscribeToFormUpdates: function () {
            walletMetaValidator.isValid.subscribe((isValid) => {
                this.isValidationPassed(isValid);
                if(isValid) {
                    this.setMeta();
                }
            });
        },

        subscribeToCartUpdates: function () {
            cartObserver.cartTotalChanged.subscribe((newTotal) => { 
                this.setMeta();
            });
            cartObserver.shippingChanged.subscribe((newTotal) => {  
                this.setMeta();
            });
        },

        loadAfterpayButton: function() {
            if (checkoutData.getSelectedPaymentMethod() !== this.getCode()) {
                return;
            }

            if (this.widgetLoadedAfterpay || !this.isValidationPassed) {
                return;
            }

            let gatewayId = window.checkoutConfig.payment.paydockAfterPay.gatewayId,
            publicKey = window.checkoutConfig.payment.paydockCreditCard.publicKey
            
            if (!publicKey || !publicKey.trim()) {
                console.error('Error loading widget - no public key defined');
                return;
            }

            this.buttonAfterpay = new cba.AfterpayCheckoutButton('#afterpay-checkout-button', publicKey, gatewayId);
            this.buttonAfterpay.setEnv(this.getEnvironment());
            this.buttonAfterpay.onFinishInsert('input[id="afterpay-checkout-button-payment-source-token"]', 'payment_source_token');
            this.buttonAfterpay.showEnhancedTrackingProtectionPopup(true);
            this.buttonAfterpay.on("finish", (data) => {
                this.paydockPlaceOrder();
            });
            this.buttonAfterpay.on('error', function (data) {
                let messageContainer = registry.get('checkout.steps.billing-step.payment.payments-list.paydock_afterpay.checkout.steps.billing-step.payment.payments-list.paydock_afterpay.messages').messageContainer;
                errorHandler.process(data.error, messageContainer);
            });
            
            this.widgetLoadedAfterpay = true;
            this.setMeta();
            return;
        },

        setMeta: function() {
            if(!this.buttonAfterpay || !this.isValidationPassed || !this.widgetLoadedAfterpay) { return }

            let address = quote.shippingAddress();

            let meta = {
                amount: cartObserver.cartTotal(),
                currency: window.checkoutConfig.quoteData.base_currency_code,
                reference: quote.getQuoteId(),
                email: quote.guestEmail || window.checkoutConfig.quoteData.customer_email,
                first_name: address.firstname,
                last_name: address.lastname,
                address_line: address.street[0] || '',
                address_line2: address.street[1] || '',
                address_city: address.city,
                address_state: address.region,
                address_postcode: address.postcode,
                address_country: address.countryId,
                phone: address.telephone
            };

            

            this.buttonAfterpay.setMeta(meta);
        },

        getCode: function() {
            return this.item.method;
        },

        getEnvironment: function() {
            return window.checkoutConfig.payment.paydockCreditCard.environment || 'production_cba';
        },

        getLogoSrc: function() {
            return window.checkoutConfig.payment.paydockAfterPay.logoSrc || '';
        },

        getMpid: function() {
            return window.checkoutConfig.payment.paydockAfterPay.mpid || '';
        },

        getPlacementId: function() {
            return window.checkoutConfig.payment.paydockAfterPay.placementId || '';
        },

        getCurrencyCode: function() {
            return window.checkoutConfig.quoteData.base_currency_code || '';
        },

        getLocale: function() {
            return window.checkoutConfig.payment.paydockAfterPay.locale || '';
        },

        getQuoteTotal: function() {
            return quote.totals() ? quote.totals()['base_grand_total'] : 0;
        },

        selectPaymentMethod: function () {

            selectPaymentMethodAction(this.getData());
            checkoutData.setSelectedPaymentMethod(this.getCode());
            
            this.loadAfterpayButton();

            return true;
        },

        paydockPlaceOrder: function() {
            $('#paydock-afterpay-place-token-order').click();
            return;
        },

        getData: function() {
            return {
                'method': this.item.method,
                'additional_data': {
                    'payment_token': $('input[id="afterpay-checkout-button-payment-source-token"]').val()
                }
            };
        },

        isChecked: ko.computed(function() {
            return checkoutData.getSelectedPaymentMethod();
        }),
    });
});
