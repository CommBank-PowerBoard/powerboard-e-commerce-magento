define([
    'mage/utils/wrapper',
    'Magento_Checkout/js/model/quote',
    'CartObserver'
], function (wrapper, quote, cartObserver) {
    'use strict';

    return function (originalSelectShippingMethod) {
        return wrapper.wrap(originalSelectShippingMethod, function (originalFunction, shippingMethod) {
            cartObserver.setSkipTotalsFlag(true);
                        
            originalFunction(shippingMethod);

            return quote.shippingMethod();
        });
    };
});
