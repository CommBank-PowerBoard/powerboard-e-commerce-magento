<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway\Http\Client;

use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Api\Data\OrderPaymentInterface;

class TransactionSale extends AbstractTransaction {

    /**
     * @inheritdoc
     * @throws LocalizedException
     */
    protected function process(array $data): array {
        $payment = $data['payment'];

        $vaultToken = $data['vault_token'] ?? null;
        $charge3dsId = $data['charge_3ds_id'] ?? null;


        if ($charge3dsId && $this->creditCardConfigurationManagement->is3DS()) {
            $this->paydockLogger->info('TransactionSale::processing with charge_3ds_id', ['$charge3dsId' => $charge3dsId]);
            return $this->process3dsCharge($payment, $vaultToken, $charge3dsId);
        }

        if ($vaultToken) {
            $this->paydockLogger->info('TransactionSale::processing with vault_token');
            return $this->processDirectCharge($payment, $vaultToken);
        }

        throw new LocalizedException(__("Error processing sale transaction"));
    }

    /**
     * @param OrderPaymentInterface $payment
     * @param string $vaultToken
     * @param string $charge3dsId
     * @return array
     * @throws LocalizedException
     */
    private function process3dsCharge(OrderPaymentInterface $payment, ?string $vaultToken, string $charge3dsId): array {
        $chargeResponse = $this->chargesService->placeDirectChargeWith3dsChargeId($payment->getOrder(), $charge3dsId);

        $this->paydockLogger->info('TransactionSale::process3dsCharge');

        $this->quoteHelper->updatePaydockHistory(['3ds_charged' => $chargeResponse['data']['_id']]);

        // NEED TO PUT A CHECK HERE TO MAKE SURE THE VAULT IS THERE AND THEY ARE SIGNED IN
        if ($this->paymentManagement->canSaveCard($payment) && $vaultToken) {
            try {
                $this->savePaymentSource($payment, $vaultToken);
            } catch (LocalizedException $e) {
                $this->logger->critical(__("Error saving payment source: %1" . $e->getMessage()));
            }
        }

        return $chargeResponse;
    }

    /**
     * @param OrderPaymentInterface $payment
     * @param string $vaultToken
     * @return array
     * @throws LocalizedException
     */
    private function processDirectCharge(OrderPaymentInterface $payment, string $vaultToken): array {
        $saleResponse = $this->chargesService->placeDirectChargeWithVaultToken($payment->getOrder(), $vaultToken);

        $this->quoteHelper->updatePaydockHistory(['direct_charged' => $saleResponse['data']['_id']]);

        if ($this->paymentManagement->canSaveCard($payment)) {
            try {
                $this->savePaymentSource($payment, $vaultToken);
            } catch (LocalizedException $e) {
                $this->logger->critical(__("Error saving payment source: %1" . $e->getMessage()));
            }
        }

        return $saleResponse;
    }
}
