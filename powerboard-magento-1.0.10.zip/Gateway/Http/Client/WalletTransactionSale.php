<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway\Http\Client;

use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Api\Data\OrderPaymentInterface;

class WalletTransactionSale extends AbstractTransaction {
    /**
     * @inheritdoc
     * @throws LocalizedException
     */
    protected function process(array $data): array {
        $chargeId = $data['id'] ?? null;
        $paymentToken = $data['payment_token'] ?? null;

        $this->paydockLogger->info('WalletTransactionSale::process', ['$chargeId' => $chargeId, '$paymentToken' => $paymentToken]);

        if ($chargeId === null && $paymentToken === null) {
            throw new LocalizedException(__('Unable to proceed. No response from wallet.'));
        }

        if ($paymentToken) {
            $payment = $data['payment'];
            $chargeId = $this->processDirectCharge($payment, $paymentToken);

            $this->paydockLogger->info('WalletTransactionSale::process::with_payment_token', ['$chargeId' => $chargeId]);
        }

        $this->quoteHelper->updatePaydockHistory(['wallet_charged' => $chargeId]);
        /**
         * This will be handled by PaymentDetailsHandler and TransactionIdHandler
         * @see di.xml
         */
        return [
            'data' => [
                '_id' => $chargeId
            ]
        ];
    }

    /**
     * @param OrderPaymentInterface $payment
     * @param string $paymentToken
     * @return array
     * @throws LocalizedException
     */
    private function processDirectCharge(OrderPaymentInterface $payment, string $paymentToken): ?string {
        $this->paydockLogger->info('WalletTransactionSale::processDirectCharge');

        $order = $payment->getOrder();

        $this->paydockLogger->info('WalletTransactionSale::processDirectCharge call directCapture');
        $saleResponse = $this->chargesService->directCapture($order, $paymentToken);

        $this->quoteHelper->updatePaydockHistory(['wallet_direct_charged' => $saleResponse['data']['_id']]);

        return $saleResponse['data']['_id'] ?? null;
    }
}
