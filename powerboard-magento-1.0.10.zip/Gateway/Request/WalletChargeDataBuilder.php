<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway\Request;

use Magento\Payment\Gateway\Request\BuilderInterface;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use Paydock\Powerboard\Gateway\Helper\SubjectReader;
use Paydock\Powerboard\Logger\PaydockLogger;

class WalletChargeDataBuilder implements BuilderInterface {
    /**
     * @var SubjectReader
     */
    private SubjectReader $subjectReader;

    /**
     * @var PaydockLogger
     */
    private PaydockLogger $paydockLogger;

    /**
     * Constructor
     *
     * @param SubjectReader $subjectReader
     */
    public function __construct(SubjectReader $subjectReader, PaydockLogger $paydockLogger) {
        $this->subjectReader = $subjectReader;
        $this->paydockLogger = $paydockLogger;
    }

    /**
     * @inheritdoc
     */
    public function build(array $buildSubject): array {
        $paymentDO = $this->subjectReader->readPayment($buildSubject);

        /** @var OrderPaymentInterface $payment */
        $payment = $paymentDO->getPayment();
        $responseId = (string)$payment->getAdditionalInformation('response_id');
        $paymentToken = (string)$payment->getAdditionalInformation('payment_token');

        $this->paydockLogger->info('WalletChargeDataBuilder::build', ['$responseId' => $responseId, '$paymentToken' => $paymentToken]);

        return [
            'payment' => $payment,
            'id' => $responseId,
            'payment_token' => $paymentToken
        ];
    }
}
