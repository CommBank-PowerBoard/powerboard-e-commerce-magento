var config = {
	map: {
		'*': {
			'Magento_Checkout/js/model/place-order': 'Paydock_Powerboard/js/view/checkout/place-order',
			'cookie-manager': 'Paydock_Powerboard/js/cookie-manager'
		}
	}
}
