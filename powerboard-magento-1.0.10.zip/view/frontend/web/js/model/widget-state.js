define(['ko'], function (ko) {
	'use strict'

	return {
		showSavedSources: ko.observable(false),
		showCreditCardWidget: ko.observable(false),
		hasSavedSources: ko.observable(false),
		show3DSWidget: ko.observable(false)
	}
})
