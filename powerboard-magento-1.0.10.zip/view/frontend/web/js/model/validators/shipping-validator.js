define(['ko', 'uiRegistry', 'Magento_Checkout/js/checkout-data', 'Magento_Checkout/js/model/quote'], function (ko, registry, checkoutData, quote) {
	'use strict'

	const isShippingValid = ko.observable(false)

	function validateShipping(shipping) {
		const customerEmail = window.checkoutConfig.quoteData.customer_email || null
		const guestEmail = checkoutData.getInputFieldEmailValue()
		const validatedEmail = checkoutData.getValidatedEmailValue()

		if (!customerEmail && guestEmail !== validatedEmail) return false

		const email = customerEmail ?? validatedEmail
		if (!email) return false

		const isVirtual = quote.isVirtual()

		if (isVirtual) {
			var emailValid = email.trim() !== ''
			var billingValid = quote.billingAddress() !== null
			return emailValid && billingValid
		}

		const address = shipping.source.get('shippingAddress')
		if (!address) return false

		const valid = shipping.validateShippingInformation()
		return valid && email.trim() !== ''
	}

	function initObserver(shipping) {
		if (!shipping || typeof shipping.validateShippingInformation !== 'function') return

		ko.computed(() => {
			isShippingValid(validateShipping(shipping))
		})
	}

	registry.async('checkout.steps.shipping-step.shippingAddress')(initObserver)

	return {
		isShippingValid
	}
})
