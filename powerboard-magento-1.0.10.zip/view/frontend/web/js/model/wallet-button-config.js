define(['ko'], function (ko) {
	'use strict'

	return {
		walletButtonConfig: ko.observable({
			afterpay: {
				buttonSelector: '#paydock_afterpay_widget',
				tokenSelector: "input[id='afterpay-response-id']",
				placeOrderSelector: '#paydock-afterpay-place-order',
				payload: {
					country: 'AU',
					request_shipping: false,
					style: {
						afterpay: {
							button_type: 'mint'
						}
					}
				},
				methodCode: 'paydock_afterpay'
			},
			applepay: {
				buttonSelector: '#paydock_applepay_widget',
				tokenSelector: "input[id='applepay-response-id']",
				placeOrderSelector: '#paydock-applepay-place-order',
				payload: {
					amount_label: 'Total',
					country: 'AU',
					wallets: ['apple'],
					request_shipping: false,
					style: {
						button_type: 'buy'
					},
					apple_pay_capabilities: ['credentials_available', 'credentials_status_unknown', 'credentials_unavailable']
				},
				methodCode: 'paydock_applepay'
			},
			googlepay: {
				buttonSelector: '#paydock_googlepay_widget',
				tokenSelector: "input[id='googlepay-response-id']",
				placeOrderSelector: '#paydock-googlepay-place-order',
				payload: {
					amount_label: 'Total',
					country: 'AU',
					wallets: ['google'],
					style: {
						google: {
							button_type: 'buy',
							button_size_mode: 'static',
							button_color: 'black'
						}
					}
				},
				methodCode: 'paydock_googlepay'
			},
			paypal: {
				buttonSelector: '#paydock_paypal_widget',
				tokenSelector: "input[id='paypal-response-id']",
				placeOrderSelector: '#paydock-paypal-place-order',
				payload: {
					amount_label: 'Payment Amount',
					country: 'AU',
					request_shipping: true,
					pay_later: window.checkoutConfig.payment.paydockPaypal.pay_later ?? false,
					style: {
						layout: window.checkoutConfig.payment.paydockPaypal.style_layout ?? 'horizontal',
						color: window.checkoutConfig.payment.paydockPaypal.style_color ?? 'gold',
						shape: window.checkoutConfig.payment.paydockPaypal.style_shape ?? 'rect',
						tagline: window.checkoutConfig.payment.paydockPaypal.style_layout != 'vertical' && window.checkoutConfig.payment.paydockPaypal.style_tagline ? window.checkoutConfig.payment.paydockPaypal.style_tagline : false,
						label: window.checkoutConfig.payment.paydockPaypal.style_label ?? ''
					}
				},
				methodCode: 'paydock_paypal'
			}
		}),

		getConfig: function (walletType) {
			return this.walletButtonConfig()[walletType] || null
		}
	}
})
