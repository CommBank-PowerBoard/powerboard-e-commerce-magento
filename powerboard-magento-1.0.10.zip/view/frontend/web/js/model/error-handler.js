define(['uiRegistry', 'Magento_Checkout/js/model/error-processor', 'Magento_Checkout/js/model/quote', 'Magento_Checkout/js/model/full-screen-loader'], function (registry, errorProcessor, quote, fullScreenLoader) {
	'use strict'

	window.registry = registry
	return {
		process: function (response) {
			var messageContainer = registry.get('checkout.errors').messageContainer

			var method = quote.paymentMethod().method
			if (method) {
				var component = registry.get(`checkout.steps.billing-step.payment.payments-list.${method}.checkout.steps.billing-step.payment.payments-list.${method}.messages`)
				if (component && component.messageContainer) {
					messageContainer = component.messageContainer
				}
			}

			if (typeof response === 'string') {
				response = this.buildResponse(response)
			}

			errorProcessor.process(response, messageContainer)
		},

		buildResponse: function (responseText) {
			return {
				status: 400,
				responseText: '{"message": "' + responseText + '"}'
			}
		}
	}
})
