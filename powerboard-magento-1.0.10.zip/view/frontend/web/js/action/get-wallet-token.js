define(['Magento_Checkout/js/model/url-builder', 'mage/storage', 'Magento_Checkout/js/model/quote'], function (urlBuilder, storage, quote) {
	'use strict'

	return async function getToken(force = false) {
		let serviceUrl =
			urlBuilder.createUrl('/paydock/wallet/token/:cartId', {
				cartId: quote.getQuoteId()
			}) +
			'?force=' +
			encodeURIComponent(force)

		try {
			let response = await storage.get(serviceUrl, false)
			return JSON.parse(response)
		} catch (error) {
			throw error
		}
	}
})
