define(['jquery', 'Paydock_Powerboard_Widget', 'Paydock_Powerboard/js/model/widget-state', 'Paydock_Powerboard/js/model/error-handler', 'Paydock_Powerboard/js/model/creditcard', 'Paydock_Powerboard/js/action/get-paydock-customer-id', 'Paydock_Powerboard/js/action/get-payment-sources', 'Paydock_Powerboard/js/action/get-3ds-token'], function (
	$,
	cba,
	widgetState,
	errorHandler,
	creditCardModel,
	getPaydockCustomerId,
	getPaymentSources,
	get3dsToken
) {
	'use strict'

	var widgetAccessToken = creditCardModel.getWidgetAccessToken()
	let environment = creditCardModel.getEnvironment()

	var clearWidgets = function () {
		$('#paydock_widget').empty()
		$('#paydock_3ds_widget').empty()
		$('#paydock_payment_source_widget').empty()
	}

	var initWidgetStyles = function (widget) {
		widget.setFormLabels({card_name: 'Card Holder Name *'})
		widget.setFormLabels({card_number: 'Card Number *'})
		widget.setFormLabels({card_ccv: 'Security Number *'})
		widget.setFormLabels({expire_month: 'Expiry *'})
		widget.setFormFields(['card_name*', 'card_number*', 'card_ccv*'])
		widget.setFormPlaceholders({
			card_name: 'Card Holder Name',
			card_number: 'Card Number',
			card_ccv: 'CCV'
		})

		var supportedCardTypes = []
		$.each(window.checkoutConfig.payment.paydockCreditCard.availableCardTypes, function (index, value) {
			switch (value) {
				case 'DN':
					supportedCardTypes.push('diners')
					break
				case 'AE':
					supportedCardTypes.push('amex')
					break
				case 'MC':
					supportedCardTypes.push('mastercard')
					break
				case 'JCB':
					supportedCardTypes.push('japcb')
					break
				case 'VI':
					supportedCardTypes.push('visa')
					break
				default:
					break
			}
		})

		if (supportedCardTypes.length > 0) {
			widget.setSupportedCardIcons(supportedCardTypes, true)
		}

		widget.setStyles(creditCardModel.getCss())
		widget.setElementStyle('submit_button', creditCardModel.getButtonCss())
		widget.setElementStyle('label', creditCardModel.getLabelCss())
		widget.setElementStyle('input', creditCardModel.getInputCss())
		widget.setTexts({submit_button: 'Place Order'})
		widget.useAutoResize()
	}

	var initCCWidget = function () {
		clearWidgets()

		initPaymentSourcesWidget()

		let widget = new cba.HtmlWidget('#paydock_widget', widgetAccessToken, 'not_configured', 'card', 'card_payment_source_with_cvv')
		initWidgetStyles(widget)
		widget.onFinishInsert('#paydock_cc-token', 'payment_source')
		widget.on('finish', function (data) {
			$('#paydock_cc-payment_source_id').val('')
			if (creditCardModel.is3ds()) {
				let token = $('#paydock_cc-token').val()
				init3DSWidget(token)
			} else {
				$('#paydock-creditcard-place-token-order').click()
			}
		})
		widget.setEnv(environment)
		widget.load()
	}

	var showCreditCardWidget = function () {
		widgetState.showCreditCardWidget(true)
		widgetState.showSavedSources(false)
		widgetState.hasSavedSources(false)
		widgetState.show3DSWidget(false)
	}

	var showSavedSourcesWidget = function () {
		widgetState.showCreditCardWidget(false)
		widgetState.showSavedSources(true)
		widgetState.hasSavedSources(true)
		widgetState.show3DSWidget(false)
	}

	var show3DSWidget = function () {
		widgetState.showCreditCardWidget(false)
		widgetState.showSavedSources(false)
		widgetState.hasSavedSources(true)
		widgetState.show3DSWidget(true)
	}

	var initPaymentSourcesWidget = function () {
		let paydockCustomerId = getPaydockCustomerId()

		if (paydockCustomerId) {
			getPaymentSources(paydockCustomerId)
				.then((paymentSources) => {
					if (paymentSources.payment_sources.length > 0) {
						var paymentSourcesWidget = new cba.HtmlPaymentSourceWidget('#paydock_payment_source_widget', widgetAccessToken, paymentSources.query_token)
						paymentSourcesWidget.onSelectInsert('#paydock_cc-payment_source_id', 'payment_source_id')
						paymentSourcesWidget.setEnv(environment)
						paymentSourcesWidget.filterByTypes(['card'])
						paymentSourcesWidget.setStyles(creditCardModel.getPaymentSourcesCss())
						paymentSourcesWidget.load()
						paymentSourcesWidget.on('afterLoad', function (data) {
							showSavedSourcesWidget()
						})
						paymentSourcesWidget.on('unselect', function (data) {
							$('#paydock_cc-payment_source_id').val('')
						})
					} else {
						showCreditCardWidget()
					}
				})
				.catch((error) => {
					errorHandler.process(error)
					showCreditCardWidget()
				})
		} else {
			showCreditCardWidget()
		}
	}

	var init3DSWidget = function (token, isPaymentSource = false) {
		get3dsToken(token, isPaymentSource)
			.then((queryToken) => {
				if (queryToken) {
					show3DSWidget()
					$('#paydock_cc-token').val('')

					let environment = creditCardModel.getEnvironment()

					let widget = new cba.Canvas3ds('#paydock_3ds_widget', queryToken)
					widget.setEnv(environment)
					widget.on('chargeAuthSuccess', function (data) {
						$('#paydock_cc-payment_source_id').val('')
						$('#paydock_cc-charge_3ds_id').val(data.charge_3ds_id)
						$('#paydock-creditcard-place-token-order').click()
					})
					widget.on('chargeAuthReject', function (data) {
						errorHandler.process('Your payment failed, please try again')
						initCCWidget()
					})

					widget.on('chargeAuthCancelled', function (data) {
						errorHandler.process('Your payment failed, please try again')
						initCCWidget()
					})
					widget.load()
				}
			})
			.catch((error) => {
				errorHandler.process(error)
				initCCWidget()
			})
	}

	return {
		initCCWidget: initCCWidget,
		init3DSWidget: init3DSWidget
	}
})
