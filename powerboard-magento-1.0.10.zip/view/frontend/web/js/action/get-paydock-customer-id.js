define(['Magento_Customer/js/model/customer', 'Magento_Customer/js/customer-data'], function (customer, customerData) {
	'use strict'

	return function () {
		let customerIsLoggedIn = customer.isLoggedIn()
		if (!customerIsLoggedIn) {
			return null
		}

		let paydockCustomerId = customer.customerData.extension_attributes.paydock_customer_id || null

		return paydockCustomerId
	}
})
