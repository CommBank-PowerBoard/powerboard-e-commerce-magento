define(['jquery', 'Magento_Checkout/js/model/url-builder', 'mage/storage', 'Magento_Checkout/js/model/full-screen-loader', 'Magento_Checkout/js/model/quote'], function ($, urlBuilder, storage, fullScreenLoader, quote) {
	'use strict'

	return async function get3dsToken(token, isPaymentSource) {
		fullScreenLoader.startLoader()

		const userAgent = navigator.userAgent
		const browserMap = [
			{keyword: 'Chrome', name: 'Chrome'},
			{keyword: 'Safari', name: 'Safari'},
			{keyword: 'Mozilla', name: 'Mozilla'},
			{keyword: 'Internet', name: 'Internet Explorer'}
		]

		const match = browserMap.find((b) => userAgent.includes(b.keyword))
		const browserName = match ? match.name : userAgent

		const browserDetails = {
			name: browserName,
			java_enabled: 'true',
			language: navigator.language,
			screen_height: String(screen.height),
			screen_width: String(screen.width),
			time_zone: String(new Date().getTimezoneOffset()),
			color_depth: String(screen.colorDepth)
		}

		let serviceUrl = urlBuilder.createUrl('/paydock/3ds/token/:paymentToken/:cartId/pre-auth', {
			paymentToken: token,
			cartId: quote.getQuoteId()
		})

		let cc_save = $('#paydock_cc-save').is(':checked')

		const payload = {
			browser_details: browserDetails,
			cc_save: cc_save,
			is_payment_source: isPaymentSource
		}

		try {
			const queryToken = await storage.post(serviceUrl, JSON.stringify(payload))
			return queryToken
		} catch (error) {
			throw error
		} finally {
			fullScreenLoader.stopLoader()
		}
	}
})
