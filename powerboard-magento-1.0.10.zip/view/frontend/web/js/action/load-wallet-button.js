define(['Paydock_Powerboard/js/action/wallet-button', 'Paydock_Powerboard/js/model/wallet-button-config'], function (walletButton, walletButtonConfig) {
	'use strict'

	return function (wallet) {
		const config = walletButtonConfig.getConfig(wallet)

		if (walletButton.isInitialized(config.buttonSelector)) {
			walletButton.refresh(config.buttonSelector)
			return
		}

		walletButton.initialize(config.buttonSelector, config.payload, {
			tokenSelector: config.tokenSelector,
			placeOrderSelector: config.placeOrderSelector
		})
	}
})
