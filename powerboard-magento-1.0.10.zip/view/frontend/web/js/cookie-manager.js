define(['Magento_Checkout/js/checkout-data', 'Magento_Checkout/js/model/totals'], function (checkoutData, totals) {
	'use strict'

	var inFocus = true
	const cookieKeyCartTotal = 'powerboard_cart_total'
	const cookieKeyPaymentMethod = 'powerboard_payment_method'

	setInterval(checkForUpdates, 1000)

	function checkForUpdates() {
		let cartTotal = parseFloat(totals.getSegment('grand_total') ? totals.getSegment('grand_total').value : 0) || 0.0
		let cookieCartTotal = parseFloat(getCookieValue(cookieKeyCartTotal)) || 0.0
		let paymentMethod = checkoutData.getSelectedPaymentMethod()
		let cookiePaymentMethod = getCookieValue(cookieKeyPaymentMethod)

		if ((cartTotal !== cookieCartTotal || (cookiePaymentMethod && paymentMethod !== cookiePaymentMethod)) && document.hidden) {
			location.reload()
		}
	}

	function getCookieValue(key) {
		const cookies = Object.fromEntries(document.cookie.split('; ').map((c) => c.split('=')))
		return cookies[key] ? decodeURIComponent(cookies[key]) : null
	}
})
