define(['Magento_Checkout/js/view/payment/default', 'jquery', 'ko', 'Paydock_Powerboard/js/action/load-wallet-button', 'Magento_Checkout/js/action/select-payment-method', 'Magento_Checkout/js/checkout-data', 'Paydock_Powerboard/js/model/validators/shipping-validator', 'Magento_Checkout/js/model/totals'], function (
	paymentDefault,
	$,
	ko,
	loadWalletButtonAction,
	selectPaymentMethodAction,
	checkoutData,
	shippingValidator,
	totals
) {
	'use strict'
	return paymentDefault.extend({
		defaults: {
			template: 'Paydock_Powerboard/payment/googlepay-form'
		},
		previousTotalGooglePay: 0,
		widgetLoadedGooglePay: false,
		isValidationPassed: ko.observable(false),

		initialize: function () {
			this._super()
			this.subscribeToTotalsUpdates()
			this.subscribeToShippingUpdates()
			this.loadGooglePayButton()
		},

		subscribeToTotalsUpdates() {
			this.previousTotalGooglePay = totals.getSegment('grand_total') ? totals.getSegment('grand_total').value : 0

			totals.totals.subscribe(() => {
				var grandTotal = totals.getSegment('grand_total') ? totals.getSegment('grand_total').value : 0
				if (this.previousTotalGooglePay != grandTotal) {
					this.loadGooglePayButton()
					this.previousTotalGooglePay = grandTotal
				}
			})
		},

		subscribeToShippingUpdates() {
			this.isValidationPassed(shippingValidator.isShippingValid())

			shippingValidator.isShippingValid.subscribe((newValue) => {
				this.isValidationPassed(newValue)
				if (newValue) this.loadGooglePayButton()
			})
		},

		isSelectedPaymentMethod() {
			return checkoutData.getSelectedPaymentMethod() == this.getCode()
		},

		loadGooglePayButton: function () {
			if (!this.isSelectedPaymentMethod() || !this.isValidationPassed()) return
			loadWalletButtonAction('googlepay')
		},

		isChecked: ko.computed(function () {
			return checkoutData.getSelectedPaymentMethod()
		}),

		getCode: function () {
			return this.item.method
		},

		getLogoSrc: function () {
			return window.checkoutConfig.payment.paydockGooglePay.logoSrc ?? ''
		},

		getData: function () {
			return {
				method: this.getCode(),
				additional_data: {
					response_id: $('input[id="googlepay-response-id"]').val()
				}
			}
		},

		selectPaymentMethod: function () {
			selectPaymentMethodAction(this.getData())

			checkoutData.setSelectedPaymentMethod(this.getCode())

			setTimeout(() => {
				this.loadGooglePayButton()
			}, 1500)

			return true
		}
	})
})
