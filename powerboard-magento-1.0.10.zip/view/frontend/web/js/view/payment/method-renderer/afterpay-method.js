define(['jquery', 'ko', 'Magento_Checkout/js/view/payment/default', 'Paydock_Powerboard/js/action/load-wallet-button', 'Magento_Checkout/js/action/select-payment-method', 'Magento_Checkout/js/checkout-data', 'Magento_Checkout/js/model/totals', 'Paydock_Powerboard/js/model/validators/shipping-validator', 'Magento_Ui/js/model/messageList'], function (
	$,
	ko,
	paymentDefault,
	loadWalletButtonAction,
	selectPaymentMethodAction,
	checkoutData,
	totals,
	shippingValidator
) {
	'use strict'

	return paymentDefault.extend({
		defaults: {
			template: 'Paydock_Powerboard/payment/afterpay-form'
		},
		previousTotalAfterpay: 0,
		isValidationPassed: ko.observable(false),

		initialize: function () {
			this._super()
			this.subscribeToTotalsUpdates()
			this.subscribeToShippingUpdates()
			this.loadAfterpayButton()
		},

		subscribeToTotalsUpdates() {
			this.previousTotalAfterpay = totals.getSegment('grand_total') ? totals.getSegment('grand_total').value : 0

			totals.totals.subscribe(() => {
				var grandTotal = totals.getSegment('grand_total') ? totals.getSegment('grand_total').value : 0
				if (this.previousTotalAfterpay != grandTotal) {
					this.loadAfterpayButton()
					this.previousTotalAfterpay = grandTotal
				}
			})
		},

		subscribeToShippingUpdates() {
			this.isValidationPassed(shippingValidator.isShippingValid())

			shippingValidator.isShippingValid.subscribe((newValue) => {
				this.isValidationPassed(newValue)
				if (newValue) this.loadAfterpayButton()
			})
		},

		isSelectedPaymentMethod() {
			return checkoutData.getSelectedPaymentMethod() == this.getCode()
		},

		loadAfterpayButton: function () {
			if (!this.isSelectedPaymentMethod() || !this.isValidationPassed()) return
			loadWalletButtonAction('afterpay')
		},

		isChecked: ko.computed(function () {
			return checkoutData.getSelectedPaymentMethod()
		}),

		getCode: function () {
			return this.item.method
		},

		getLogoSrc: function () {
			return window.checkoutConfig.payment.paydockAfterPay.logoSrc ?? ''
		},

		getData: function () {
			return {
				method: this.item.method,
				additional_data: {
					response_id: $('input[id="afterpay-response-id"]').val()
				}
			}
		},

		selectPaymentMethod: function () {
			selectPaymentMethodAction(this.getData())
			checkoutData.setSelectedPaymentMethod(this.getCode())

			setTimeout(() => {
				this.loadAfterpayButton()
			}, 1500)

			return true
		}
	})
})
