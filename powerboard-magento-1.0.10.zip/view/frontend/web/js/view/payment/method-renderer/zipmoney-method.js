define(['Magento_Checkout/js/view/payment/default', 'jquery', 'ko', 'Magento_Checkout/js/model/quote', 'Paydock_Powerboard_Widget', 'Magento_Checkout/js/checkout-data', 'Magento_Checkout/js/action/select-payment-method', 'Magento_Checkout/js/model/totals', 'Paydock_Powerboard/js/model/validators/shipping-validator', 'Magento_Checkout/js/model/full-screen-loader'], function (
	paymentDefault,
	$,
	ko,
	quote,
	cba,
	checkoutData,
	selectPaymentMethodAction,
	totals,
	shippingValidator,
	fullScreenLoader
) {
	'use strict'

	return paymentDefault.extend({
		defaults: {
			template: 'Paydock_Powerboard/payment/zipmoney-form'
		},
		previousTotalZipmoney: 0,
		widgetLoadedZipMoney: false,
		redirectedFromZip: false,
		isValidationPassed: ko.observable(false),

		initialize: function () {
			this._super()
		},

		subscribeToTotalsUpdates() {
			this.previousTotalZipmoney = totals.getSegment('grand_total') ? totals.getSegment('grand_total').value : 0

			totals.totals.subscribe(() => {
				var grandTotal = totals.getSegment('grand_total') ? totals.getSegment('grand_total').value : 0
				if (this.previousTotalZipmoney != grandTotal) {
					this.loadZipMoneyButton()
					this.previousTotalZipmoney = grandTotal
				}
			})
		},

		subscribeToShippingUpdates() {
			this.isValidationPassed(shippingValidator.isShippingValid())

			shippingValidator.isShippingValid.subscribe((newValue) => {
				this.isValidationPassed(newValue)
				if (newValue) this.reloadPaymentMethod()
			})
		},

		isSelectedPaymentMethod() {
			return checkoutData.getSelectedPaymentMethod() == this.getCode()
		},

		reloadPaymentMethod() {
			if (this.isSelectedPaymentMethod()) {
				this.widgetLoadedZipMoney = false
				this.loadZipMoneyButton()
			}
		},

		checkQueryParams: function () {
			const urlParams = new URLSearchParams(window.location.search)
			const result = urlParams.get('result')
			const paymentSourceToken = urlParams.get('payment_source_token')
			if (result === 'approved' && paymentSourceToken) {
				fullScreenLoader.startLoader()
				$('input[id="zipmoney-checkout-button-payment-source-token"]').val(paymentSourceToken)
				const storedToken = $('input[id="zipmoney-checkout-button-payment-source-token"]').val()
				this.redirectedFromZip = true
				setTimeout(() => {
					fullScreenLoader.stopLoader(true)
					$('#paydock-zipmoney-place-token-order').click()
				}, 2000)
			} else {
				this.subscribeToTotalsUpdates()
				this.subscribeToShippingUpdates()
				this.loadZipMoneyButton()
			}
		},

		loadZipMoneyButton: function () {
			if (this.redirectedFromZip) {
				return
			}

			if (checkoutData.getSelectedPaymentMethod() !== this.getCode()) {
				return
			}

			if (this.widgetLoadedZipMoney || !this.isValidationPassed()) {
				return
			}

			let gatewayId = window.checkoutConfig.payment.paydockZipMoney.gatewayId,
				widgetAccessToken = window.checkoutConfig.payment.paydockCreditCard.widgetAccessToken

			if (typeof widgetAccessToken === 'undefined' || widgetAccessToken.trim() === '') {
				console.error('Error loading widget - no public key defined')
				return
			}

			var buttonZipMoney = new cba.ZipmoneyCheckoutButton('#zipmoney-checkout-button', widgetAccessToken, gatewayId)

			buttonZipMoney.setEnv(this.getEnvironment())

			let shippingAddress = quote.shippingAddress(),
				billingAddress = quote.billingAddress(),
				currency = window.checkoutConfig.quoteData.base_currency_code

			let meta = {
				first_name: shippingAddress.firstname,
				tokenize: true,
				last_name: shippingAddress.lastname,
				email: quote.guestEmail ?? window.checkoutConfig.quoteData.customer_email,
				gender: '',
				charge: {
					amount: totals.getSegment('grand_total') ? totals.getSegment('grand_total').value : 0,
					currency: currency,
					billing_address: {
						first_name: billingAddress.firstname,
						last_name: billingAddress.lastname,
						line1: billingAddress.street[0] ?? '',
						line2: billingAddress.street[1] ?? '',
						country: billingAddress.countryId,
						postcode: billingAddress.postcode,
						city: billingAddress.city,
						state: billingAddress.region
					},
					items: this.getCartItems()
				},
				statistics: {
					account_created: '',
					sales_total_number: '',
					sales_total_amount: '',
					sales_avg_value: '',
					sales_max_value: '',
					refunds_total_amount: '',
					previous_chargeback: '',
					currency: currency,
					last_login: ''
				}
			}

			if (!quote.isVirtual()) {
				meta['charge']['shipping_type'] = 'delivery'
				meta['charge']['shipping_address'] = {
					first_name: shippingAddress.firstname,
					last_name: shippingAddress.lastname,
					line1: shippingAddress.street[0] ?? '',
					line2: shippingAddress.street[1] ?? '',
					country: shippingAddress.countryId,
					postcode: shippingAddress.postcode,
					city: shippingAddress.city,
					state: shippingAddress.region
				}
			}

			buttonZipMoney.setMeta(meta)
			buttonZipMoney.setRedirectUrl(window.location.href)

			this.widgetLoadedZipMoney = true
			return
		},

		getCartItems: function () {
			let quoteItems = quote.getItems(),
				cartItems = []

			for (let i = 0; i < quoteItems.length; i++) {
				cartItems.push({
					name: quoteItems[i]['name'],
					amount: quoteItems[i]['row_total'],
					quantity: quoteItems[i]['qty'],
					reference: quoteItems[i]['description']
				})
			}

			return cartItems
		},

		getCode: function () {
			return this.item.method
		},

		getEnvironment: function () {
			return window.checkoutConfig.payment.paydockCreditCard.environment ?? 'production_cba'
		},

		getLogoSrc: function () {
			return window.checkoutConfig.payment.paydockZipMoney.logoSrc ?? ''
		},

		selectPaymentMethod: function () {
			selectPaymentMethodAction(this.getData())
			checkoutData.setSelectedPaymentMethod(this.getCode())

			setTimeout(() => {
				this.loadZipMoneyButton()
			}, 1500)

			return true
		},

		getData: function () {
			return {
				method: this.item.method,
				additional_data: {
					payment_token: $('input[id="zipmoney-checkout-button-payment-source-token"]').val()
				}
			}
		}
	})
})
