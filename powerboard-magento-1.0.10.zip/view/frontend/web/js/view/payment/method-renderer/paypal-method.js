define(['jquery', 'ko', 'Magento_Checkout/js/action/select-payment-method', 'Magento_Checkout/js/checkout-data', 'Magento_Checkout/js/view/payment/default', 'Paydock_Powerboard/js/action/load-wallet-button', 'Paydock_Powerboard/js/model/validators/shipping-validator', 'Magento_Checkout/js/model/totals'], function (
	$,
	ko,
	selectPaymentMethodAction,
	checkoutData,
	paymentDefault,
	loadWalletButtonAction,
	shippingValidator,
	totals
) {
	'use strict'

	return paymentDefault.extend({
		defaults: {
			template: 'Paydock_Powerboard/payment/paypal-form'
		},
		previousTotalPayPal: 0,
		isValidationPassed: ko.observable(false),

		initialize: function () {
			this._super()
			this.subscribeToTotalsUpdates()
			this.subscribeToShippingUpdates()
			this.loadPayPalButton()
		},

		subscribeToTotalsUpdates() {
			this.previousTotalPayPal = totals.getSegment('grand_total') ? totals.getSegment('grand_total').value : 0

			totals.totals.subscribe(() => {
				var grandTotal = totals.getSegment('grand_total') ? totals.getSegment('grand_total').value : 0
				if (this.previousTotalPayPal != grandTotal) {
					this.loadPayPalButton()
					this.previousTotalPayPal = grandTotal
				}
			})
		},

		subscribeToShippingUpdates() {
			this.isValidationPassed(shippingValidator.isShippingValid())

			shippingValidator.isShippingValid.subscribe((newValue) => {
				this.isValidationPassed(newValue)
				if (newValue) this.loadPayPalButton()
			})
		},

		isSelectedPaymentMethod() {
			return checkoutData.getSelectedPaymentMethod() == this.getCode()
		},

		loadPayPalButton: function () {
			if (!this.isSelectedPaymentMethod() || !this.isValidationPassed()) return
			loadWalletButtonAction('paypal')
		},

		isChecked: ko.computed(function () {
			return checkoutData.getSelectedPaymentMethod()
		}),

		getCode: function () {
			return this.item.method
		},

		getLogoSrc: function () {
			return window.checkoutConfig.payment.paydockPaypal.logoSrc ?? ''
		},

		getData: function () {
			return {
				method: this.getCode(),
				additional_data: {
					response_id: $('input[id="paypal-response-id"]').val()
				}
			}
		},

		selectPaymentMethod: function () {
			selectPaymentMethodAction(this.getData())

			checkoutData.setSelectedPaymentMethod(this.getCode())
			setTimeout(() => {
				this.loadPayPalButton()
			}, 1500)

			return true
		}
	})
})
