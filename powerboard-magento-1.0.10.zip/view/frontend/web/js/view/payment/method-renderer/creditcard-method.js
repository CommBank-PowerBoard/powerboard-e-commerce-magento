define(['Magento_Checkout/js/view/payment/default', 'jquery', 'ko', 'Paydock_Powerboard/js/model/creditcard', 'Magento_Checkout/js/action/select-payment-method', 'Magento_Checkout/js/checkout-data', 'Magento_Customer/js/model/customer', 'Paydock_Powerboard/js/model/validators/shipping-validator', 'Paydock_Powerboard/js/action/cc-widget', 'Paydock_Powerboard/js/model/widget-state'], function (
	paymentDefault,
	$,
	ko,
	creditCardModel,
	selectPaymentMethodAction,
	checkoutData,
	customer,
	shippingValidator,
	ccWidget,
	widgetState
) {
	'use strict'

	return paymentDefault.extend({
		defaults: {
			template: 'Paydock_Powerboard/payment/creditcard-form'
		},
		isValidationPassed: ko.observable(false),
		widgetLoaded: false,

		/**
		 * {@inheritdoc}
		 */
		initialize: function () {
			this._super()
			this.subscribeToShippingUpdates()
			this.initViewObservers()
		},

		initViewObservers() {
			var self = this

			self.showCanSaveCard = ko.pureComputed(function () {
				return widgetState.showCreditCardWidget() && self.canSaveCard()
			})

			self.show3DSWidget = ko.pureComputed(function () {
				return widgetState.show3DSWidget()
			})

			self.showSavedSources = ko.pureComputed(function () {
				return widgetState.showSavedSources()
			})

			self.showCreditCardWidget = ko.pureComputed(function () {
				return widgetState.showCreditCardWidget()
			})

			self.showCanUseSaveCard = ko.pureComputed(function () {
				return widgetState.hasSavedSources() && widgetState.showCreditCardWidget()
			})
		},

		subscribeToShippingUpdates() {
			this.isValidationPassed(shippingValidator.isShippingValid())

			shippingValidator.isShippingValid.subscribe((newValue) => {
				this.isValidationPassed(newValue)
				if (newValue) this.initWidget()
			})
		},

		isSelectedPaymentMethod() {
			return checkoutData.getSelectedPaymentMethod() == this.getCode()
		},

		initWidget: function () {
			if (!this.isSelectedPaymentMethod() || !this.isValidationPassed() || this.widgetLoaded) return

			ccWidget.initCCWidget()

			this.widgetLoaded = true
		},

		selectPaymentMethod: function () {
			selectPaymentMethodAction(this.getData())
			checkoutData.setSelectedPaymentMethod(this.getCode())

			setTimeout(() => {
				this.initWidget()
			}, 1500)

			return true
		},

		toggleWidget: function () {
			$('#paydock_cc-save').prop('checked', false)
			widgetState.showSavedSources(!widgetState.showSavedSources())
			widgetState.showCreditCardWidget(!widgetState.showCreditCardWidget())
		},

		getCode: function () {
			return creditCardModel.getCode()
		},

		placePaymentSourcesOrder: function () {
			if ($('#paydock_cc-payment_source_id').val() == '') {
				return
			}

			if (this.is3Ds()) {
				var paymentSourceId = $('#paydock_cc-payment_source_id').val()
				ccWidget.init3DSWidget(paymentSourceId, true)
			} else {
				$('#paydock-creditcard-place-token-order').click()
			}
		},

		canSaveCard: function () {
			return customer.isLoggedIn() && creditCardModel.canSaveCard()
		},

		is3Ds: function () {
			return creditCardModel.is3ds()
		},

		/**
		 * Get list of available CC types
		 *
		 * @returns {Array}
		 */
		getCcAvailableTypes: function () {
			return window.checkoutConfig.payment.paydockCreditCard.availableCardTypes ?? []
		},

		/**
		 * Get payment icons
		 * @param {String} type
		 * @returns {Boolean}
		 */
		getIcons: function (type) {
			return window.checkoutConfig.payment.paydockCreditCard.icons.hasOwnProperty(type) ? window.checkoutConfig.payment.paydockCreditCard.icons[type] : false
		},

		/**
		 * @returns {String}
		 */
		getLogoSrc: function () {
			return window.checkoutConfig.payment.paydockCreditCard.logoSrc ?? ''
		},

		/**
		 * @returns {Object}
		 */
		getData: function () {
			return {
				method: this.item.method,
				additional_data: {
					payment_token: $('#paydock_cc-token').val(),
					cc_save: creditCardModel.canSaveCard() && $('#paydock_cc-save').is(':checked'),
					payment_source_id: $('#paydock_cc-payment_source_id').val(),
					charge_3ds_id: $('#paydock_cc-charge_3ds_id').val()
				}
			}
		}
	})
})
