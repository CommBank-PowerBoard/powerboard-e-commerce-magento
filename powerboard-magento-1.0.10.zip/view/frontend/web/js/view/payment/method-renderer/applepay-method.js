define(['jquery', 'ko', 'Magento_Checkout/js/view/payment/default', 'Paydock_Powerboard/js/action/load-wallet-button', 'Magento_Checkout/js/action/select-payment-method', 'Magento_Checkout/js/checkout-data', 'Magento_Checkout/js/model/totals', 'Paydock_Powerboard/js/model/validators/shipping-validator'], function (
	$,
	ko,
	paymentDefault,
	loadWalletButtonAction,
	selectPaymentMethodAction,
	checkoutData,
	totals,
	shippingValidator
) {
	'use strict'

	return paymentDefault.extend({
		defaults: {
			template: 'Paydock_Powerboard/payment/applepay-form'
		},
		previousTotalApplePay: 0,
		isValidationPassed: ko.observable(false),

		initialize: function () {
			this._super()
			this.subscribeToTotalsUpdates()
			this.subscribeToShippingUpdates()
			this.loadApplePayButton()
		},

		subscribeToTotalsUpdates() {
			this.previousTotalApplePay = totals.getSegment('grand_total') ? totals.getSegment('grand_total').value : 0

			totals.totals.subscribe(() => {
				var grandTotal = totals.getSegment('grand_total') ? totals.getSegment('grand_total').value : 0
				if (this.previousTotalApplePay != grandTotal) {
					this.loadApplePayButton()
					this.previousTotalApplePay = grandTotal
				}
			})
		},

		subscribeToShippingUpdates() {
			this.isValidationPassed(shippingValidator.isShippingValid())

			shippingValidator.isShippingValid.subscribe((newValue) => {
				this.isValidationPassed(newValue)
				if (newValue) this.loadApplePayButton()
			})
		},

		isSelectedPaymentMethod() {
			return checkoutData.getSelectedPaymentMethod() == this.getCode()
		},

		loadApplePayButton: function () {
			if (!this.isSelectedPaymentMethod() || !this.isValidationPassed()) return
			loadWalletButtonAction('applepay')
		},

		isChecked: ko.computed(function () {
			return checkoutData.getSelectedPaymentMethod()
		}),

		getCode: function () {
			return this.item.method
		},

		getLogoSrc: function () {
			return window.checkoutConfig.payment.paydockApplePay.logoSrc ?? ''
		},

		getData: function () {
			return {
				method: this.item.method,
				additional_data: {
					response_id: $('input[id="applepay-response-id"]').val()
				}
			}
		},

		selectPaymentMethod: function () {
			selectPaymentMethodAction(this.getData())
			checkoutData.setSelectedPaymentMethod(this.getCode())

			setTimeout(() => {
				this.loadApplePayButton()
			}, 1500)

			return true
		}
	})
})
