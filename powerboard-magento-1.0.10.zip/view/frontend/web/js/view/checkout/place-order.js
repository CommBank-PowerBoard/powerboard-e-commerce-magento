define(['jquery', 'mage/storage', 'Magento_Checkout/js/checkout-data', 'Magento_Checkout/js/model/error-processor', 'Magento_Checkout/js/model/full-screen-loader', 'Magento_Checkout/js/model/payment/method-list', 'Magento_Checkout/js/model/payment/place-order-hooks', 'Magento_Customer/js/customer-data', 'Paydock_Powerboard/js/action/cc-widget'], function (
	$,
	storage,
	checkoutData,
	errorProcessor,
	fullScreenLoader,
	paymentMethodList,
	hooks,
	customerData,
	ccWidget
) {
	'use strict'

	function handleError(response, messageContainer) {
		errorProcessor.process(response, messageContainer)

		var errorMessage = response.responseJSON.message
		var isShippingError = errorMessage === 'The shipping method is missing. Select the shipping method and try again.' || errorMessage === 'The shipping method is missing. You have been refunded. Select the shipping method and try again.'
		var redirectURL = response.getResponseHeader?.('errorRedirectAction') || ''
		var selectedCheckoutPaymentMethod = checkoutData.getSelectedPaymentMethod()

		if (selectedCheckoutPaymentMethod === 'paydock_cc') {
			_.each(paymentMethodList(), function (paymentMethod) {
				if (paymentMethod.method === selectedCheckoutPaymentMethod) {
					redirectURL = null
					ccWidget.initCCWidget()
					$('#paydock_cc-token').val('')
					$('#paydock_cc-charge_3ds_id').val('')
				}
			})
		}

		if (redirectURL && !isShippingError) {
			fullScreenLoader.stopLoader()
			setTimeout(function () {
				errorProcessor.redirectTo(redirectURL)
			}, 3000)
		}
	}

	return function (serviceUrl, payload, messageContainer) {
		var headers = {}

		fullScreenLoader.startLoader()

		_.each(hooks.requestModifiers, function (modifier) {
			modifier(headers, payload)
		})

		return storage
			.post(serviceUrl, JSON.stringify(payload), true, 'application/json', headers)
			.fail(function (response) {
				handleError(response, messageContainer)
			})
			.done(function (response) {
				if (response.responseType === 'error' || response.messages?.error) {
					handleError(response, messageContainer)
					return
				}

				var clearData = {
					selectedShippingAddress: null,
					shippingAddressFromData: null,
					newCustomerShippingAddress: null,
					selectedShippingRate: null,
					selectedPaymentMethod: null,
					selectedBillingAddress: null,
					billingAddressFromData: null,
					newCustomerBillingAddress: null
				}

				customerData.set('checkout-data', clearData)
			})
			.always(function () {
				fullScreenLoader.stopLoader()
				_.each(hooks.afterRequestListeners, function (listener) {
					listener()
				})
			})
	}
})
