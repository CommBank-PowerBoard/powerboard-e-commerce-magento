<?php

namespace Paydock\Powerboard\Helper;

use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\Serialize\SerializerInterface;
use Paydock\Powerboard\Logger\PaydockLogger;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Quote\Model\Quote;

class QuoteHelper {
    /**
     * @var ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var CartRepositoryInterface
     */
    protected $quoteRepository;

    /**
     * @var CheckoutSession
     */
    protected $checkoutSession;

    /**
     * @var SerializerInterface
     */
    protected $serializer;

    /**
     * @var PaydockLogger
     */
    protected $paydockLogger;

    public function __construct(
        ProductRepositoryInterface $productRepository,
        CartRepositoryInterface $quoteRepository,
        CheckoutSession $checkoutSession,
        SerializerInterface $serializer,
        PaydockLogger $paydockLogger
    ) {
        $this->productRepository = $productRepository;
        $this->quoteRepository = $quoteRepository;
        $this->checkoutSession = $checkoutSession;
        $this->serializer = $serializer;
        $this->paydockLogger = $paydockLogger;
    }

    /**
     * Updates the Paydock history in the session.
     *
     * @param array $action
     */
    public function updatePaydockHistory(array $action) {
        $quote = $this->checkoutSession->getQuote();
        $this->paydockLogger->info('Update Paydock history in session.', ['quote_id' => $quote->getId()]);

        // Get existing data from the session
        $existingData = $this->checkoutSession->getPaydockHistory();
        $paydockHistory = [];

        if (!empty($existingData)) {
            try {
                $paydockHistory = $this->serializer->unserialize($existingData);
            } catch (\Exception $e) {
                $this->paydockLogger->error('Failed to unserialize paydock_history from session', ['error' => $e->getMessage()]);
            }
        }

        $paydockHistory[] = $action;

        $serializedData = $this->serializer->serialize($paydockHistory);

        // Set the updated data back into the session
        $this->checkoutSession->setPaydockHistory($serializedData);
        $this->paydockLogger->info('Paydock history saved successfully to session.', ['filtered_data' => $paydockHistory]);
    }

    /**
     * Gets unrefunded wallet charges from the session history.
     *
     * @return array
     */
    function getUnrefundedWalletCharges(): array {
        // Get data from the session
        $paymentHistoryJson = $this->checkoutSession->getPaydockHistory();

        if (!$paymentHistoryJson) {
            return [];
        }

        try {
            $transactions = $this->serializer->unserialize($paymentHistoryJson);
        } catch (\Exception $e) {
            $this->paydockLogger->error('Failed to unserialize paydock_history for refund check', ['error' => $e->getMessage()]);
            return [];
        }

        $charged = [];
        $refunded = [];

        foreach ($transactions as $entry) {
            foreach ($entry as $key => $value) {
                if ($key === 'wallet_direct_charged') {
                    $charged[] = $value;
                } elseif ($key === 'refund') {
                    $refunded[] = $value;
                }
            }
        }

        return array_values(array_diff($charged, $refunded));
    }

    /**
     * Checks if the current payment method is a wallet payment.
     *
     * @return bool
     */
    public function isWalletPayment(): bool {
        $quote = $this->checkoutSession->getQuote();
        $paymentMethod = $quote->getPayment()->getMethod();
        $validPaymentMethods = ["paydock_applepay", "paydock_googlepay", "paydock_paypal", "paydock_afterpay"];
        return in_array($paymentMethod, $validPaymentMethods, true);
    }

    /**
     * Refreshes a wallet token.
     *
     * @param Quote $quote
     */
    public function refreshWalletToken(Quote $quote) {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $paydockLogger = $objectManager->get(\Paydock\Powerboard\Logger\PaydockLogger::class);
        $chargeService = $objectManager->get(\Paydock\Powerboard\Gateway\ChargesService::class);

        $paydockLogger->info("QuoteHelper::refreshWalletToken");

        if (!$this->isWalletPayment()) {
            $paydockLogger->info("QuoteHelper::refreshWalletToken is not wallet payment, not abandoning token");
            return;
        }

        $token = $chargeService->getWalletToken($quote);
        $paydockLogger->info('QuoteHelper::refreshWalletToken token: ' . print_r($token, true));
    }

    /**
     * Clears Paydock wallet data from the session.
     */
    public function clearPaydockWalletData() {
        $this->paydockLogger->info('Clearing Paydock wallet data from session.');
        $this->checkoutSession->unsPaydockWalletData();
        $this->paydockLogger->info('Paydock wallet data cleared successfully from session.');
    }

    /**
     * Saves Paydock wallet data to the session.
     *
     * @param array $walletData
     */
    public function savePaydockWalletData($walletData) {
        $quote = $this->checkoutSession->getQuote();
        $this->paydockLogger->info('Saving Paydock wallet data to session.', ['quote_id' => $quote->getId(), 'wallet_data' => $walletData]);

        $filteredData = [
            'charge_id' => $walletData['charge']['_id'] ?? null,
            'amount' => $walletData['charge']['amount'] ?? null,
            'reference' => $walletData['charge']['reference'] ?? null,
            'company_id' => $walletData['charge']['company_id'] ?? null,
            'gateway_id' => $walletData['charge']['customer']['payment_source']['gateway_id'] ?? null,
            'data' => $walletData
        ];

        $serializedData = $this->serializer->serialize($filteredData);
        $this->checkoutSession->setPaydockWalletData($serializedData);
        $this->paydockLogger->info('Paydock wallet data saved successfully to session.', ['filtered_data' => $filteredData]);
    }

    /**
     * Saves Paydock payment sources to the session.
     *
     * @param array $paymentSources
     */
    public function savePaydockPaymentSources($paymentSources) {
        $quote = $this->checkoutSession->getQuote();
        $this->paydockLogger->info('Saving Paydock payment sources data to session.', ['quote_id' => $quote->getId()]);

        $serializedData = $this->serializer->serialize($paymentSources);
        $this->checkoutSession->setPaydockStoredPaymentSources($serializedData);
        $this->paydockLogger->info('Paydock payment sources data saved successfully to session.');
    }

    /**
     * Gets a vault token from the payment sources stored in the session.
     *
     * @param string $paymentSourceId
     * @return string|null
     */
    public function getVaultFromPaydockPaymentSources(string $paymentSourceId): ?string {
        $paymentSources = $this->getPaydockPaymentSources();
        $vaultToken = $paymentSources[$paymentSourceId] ?? null;

        $this->paydockLogger->info('QuoteHelper::getVaultFromPaydockPaymentSources', ['paymentSourceId' => $paymentSourceId]);
        return $vaultToken;
    }

    /**
     * Gets Paydock payment sources from the session.
     *
     * @return array
     */
    private function getPaydockPaymentSources(): array {
        $paymentSourcesJson = $this->checkoutSession->getPaydockStoredPaymentSources();
        $this->paydockLogger->info('QuoteHelper::getPaydockPaymentSources from session.');

        if (!$paymentSourcesJson) {
            return [];
        }

        try {
            return $this->serializer->unserialize($paymentSourcesJson);
        } catch (\Exception $e) {
            $this->paydockLogger->error('Failed to unserialize paydock_stored_payment_sources from session', ['error' => $e->getMessage()]);
            return [];
        }
    }

    /**
     * Clears Paydock payment sources from the session.
     */
    public function clearPaydockPaymentSources() {
        $this->paydockLogger->info('Clear Paydock Payment Sources data from session.');
        $this->checkoutSession->unsPaydockStoredPaymentSources();
        $this->paydockLogger->info('Cleared Paydock Payment Sources data from session.');
    }

    /**
     * Gets Paydock wallet data from the session.
     *
     * @return mixed
     */
    public function getPaydockWalletData() {
        $walletData = $this->checkoutSession->getPaydockWalletData();
        $this->paydockLogger->info('Get Paydock wallet data from session.', ['wallet_data' => $walletData]);
        return $walletData;
    }

    /**
     * Gets Paydock cart data from the session.
     *
     * @return mixed
     */
    public function getPaydockCartData() {
        $cartData = $this->checkoutSession->getPaydockCartData();
        $this->paydockLogger->info('Get Paydock cart data from session.', ['cart_data' => $cartData]);
        return $cartData;
    }

    /**
     * Saves a snapshot of the current cart data to the session.
     */
    public function savePaydockCartData() {
        $quote = $this->checkoutSession->getQuote();
        $this->paydockLogger->info('Saving Paydock cart data to session.', ['quote_id' => $quote->getId()]);

        $cartData = [
            'items' => [],
            'total_price' => $quote->getGrandTotal(),
            'shipping_method' => $quote->getShippingAddress()->getShippingMethod(),
            'shipping_price' => $quote->getShippingAddress()->getShippingAmount(),
            'payment_method' => $quote->getPayment()->getMethod()
        ];

        foreach ($quote->getAllVisibleItems() as $item) {
            $cartData['items'][] = [
                'sku' => $item->getSku(),
                'price' => $item->getPrice(),
                'qty' => (int) $item->getQty(),
                'total_price' => $item->getRowTotal(),
            ];
        }

        $this->paydockLogger->info('Cart data compiled for session.', ['cart_data' => $cartData]);
        $serializedData = $this->serializer->serialize($cartData);
        $this->checkoutSession->setPaydockCartData($serializedData);
        $this->paydockLogger->info('Paydock cart data saved successfully to session.');
    }

    /**
     * Compares the current cart with the snapshot in the session.
     *
     * @return bool
     */
    public function hasCartDataChanged(): bool {
        $this->paydockLogger->info('Checking for Paydock cart data changes against session.');

        $savedData = $this->checkoutSession->getPaydockCartData();
        if (!$savedData) {
            $this->paydockLogger->info('No saved cart data found in session.');
            return true;
        }

        $quote = $this->checkoutSession->getQuote();
        $currentCartData = [
            'items' => [],
            'total_price' => (float) $quote->getGrandTotal(),
            'shipping_method' => $quote->getShippingAddress()->getShippingMethod(),
            'shipping_price' => (float) $quote->getShippingAddress()->getShippingAmount(),
            'payment_method' => $quote->getPayment()->getMethod()
        ];

        foreach ($quote->getAllVisibleItems() as $item) {
            $currentCartData['items'][] = [
                'sku' => $item->getSku(),
                'price' => (float) $item->getPrice(),
                'qty' => (int) $item->getQty(),
                'total_price' => (float) $item->getRowTotal(),
            ];
        }

        $savedCartData = $this->serializer->unserialize($savedData);
        $savedCartData['total_price'] = (float) ($savedCartData['total_price'] ?? 0);
        $savedCartData['shipping_price'] = (float) ($savedCartData['shipping_price'] ?? 0);
        foreach ($savedCartData['items'] as &$item) {
            $item['price'] = (float) ($item['price'] ?? 0);
            $item['total_price'] = (float) ($item['total_price'] ?? 0);
        }
        unset($item);

        $hasChanged = $currentCartData !== $savedCartData;
        $this->paydockLogger->info('Cart data comparison completed.', [
            'has_changed' => $hasChanged,
            'current_cart_data' => $currentCartData,
            'saved_cart_data' => $savedCartData,
        ]);

        return $hasChanged;
    }

    /**
     * Reverts the live cart to the state stored in the session snapshot.
     */
    public function revertCartData() {
        $quote = $this->checkoutSession->getQuote();
        $this->paydockLogger->info('Reverting Paydock cart data from session.', ['quote_id' => $quote->getId()]);

        $serializedData = $this->checkoutSession->getPaydockCartData();

        if (!$serializedData) {
            $this->paydockLogger->warning('No Paydock cart data found in session to revert.');
            return;
        }

        $cartData = $this->serializer->unserialize($serializedData);

        $currentItems = [];
        foreach ($quote->getAllVisibleItems() as $item) {
            $currentItems[$item->getSku()] = $item;
        }

        foreach ($cartData['items'] as $itemData) {
            $sku = $itemData['sku'];
            $newQty = (int)$itemData['qty'];

            if (isset($currentItems[$sku])) {
                $existingItem = $currentItems[$sku];
                if ((int)$existingItem->getQty() !== $newQty) {
                    $existingItem->setQty($newQty);
                }
                unset($currentItems[$sku]);
            } else {
                try {
                    $product = $this->productRepository->get($sku);
                    $quote->addProduct($product, $newQty);
                } catch (\Exception $e) {
                    $this->paydockLogger->error('Could not add product to cart during revert.', ['sku' => $sku, 'error' => $e->getMessage()]);
                }
            }
        }

        foreach ($currentItems as $unusedItem) {
            $quote->removeItem($unusedItem->getItemId());
        }

        $quote->getShippingAddress()->setShippingMethod($cartData['shipping_method']);
        $quote->setTotalsCollectedFlag(false)->collectTotals();

        $this->quoteRepository->save($quote);
        $this->paydockLogger->info('Paydock cart data reverted successfully.');
    }

    /**
     * Clears all Paydock-related data from the checkout session.
     * This is useful after an order is placed or the cart is abandoned.
     */
    public function clearAllPaydockSessionData() {
        $this->paydockLogger->info('Clearing all Paydock session data.');

        // Unset each piece of custom data from the session
        $this->checkoutSession->unsPaydockHistory();
        $this->checkoutSession->unsPaydockWalletData();
        $this->checkoutSession->unsPaydockStoredPaymentSources();
        $this->checkoutSession->unsPaydockCartData();

        $this->paydockLogger->info('All Paydock session data has been cleared.');
    }
}
