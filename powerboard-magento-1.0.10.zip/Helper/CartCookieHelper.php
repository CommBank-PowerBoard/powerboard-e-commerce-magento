<?php

namespace Paydock\Powerboard\Helper;

use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\Stdlib\Cookie\CookieMetadataFactory;
use Magento\Framework\Stdlib\CookieManagerInterface;
use Paydock\Powerboard\Logger\PaydockLogger;
use Magento\Quote\Model\Quote;


class CartCookieHelper {
    protected $checkoutSession;
    protected $cookieManager;
    protected $cookieMetadataFactory;
    protected $paydockLogger;


    public function __construct(
        CheckoutSession $checkoutSession,
        CookieManagerInterface $cookieManager,
        CookieMetadataFactory $cookieMetadataFactory,
        PaydockLogger $paydockLogger
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->cookieManager = $cookieManager;
        $this->cookieMetadataFactory = $cookieMetadataFactory;
        $this->paydockLogger = $paydockLogger;
    }

    public function updateCartCookie(Quote $quote) {
        $cartTotalCookie = 'powerboard_cart_total';
        $cartTotalCookieValue = $quote->getGrandTotal();

        $shippingMethodCookie = 'powerboard_shipping_method';
        $shippingAddress = $quote->getShippingAddress();
        $shippingMethodCookieValue = $shippingAddress->getShippingMethod();

        $paymentMethodCookie = 'powerboard_payment_method';
        $paymentMethodCookieValue = $quote->getPayment()->getMethod();


        $this->paydockLogger->info('updateCartCookie::beforeSetCookies powerboard_cart_total: ' . $cartTotalCookieValue . ' powerboard_shipping_method: ' . $shippingMethodCookieValue . ' powerboard_payment_method: ' . $paymentMethodCookieValue);

        $existingCookie = $this->cookieManager->getCookie($cartTotalCookie);
        if ($existingCookie) {
            $this->cookieManager->deleteCookie($cartTotalCookie);
        }

        $existingCookie = $this->cookieManager->getCookie($shippingMethodCookie);
        if ($existingCookie) {
            $this->cookieManager->deleteCookie($shippingMethodCookie);
        }

        $existingCookie = $this->cookieManager->getCookie($paymentMethodCookie);
        if ($existingCookie) {
            $this->cookieManager->deleteCookie($paymentMethodCookie);
        }


        $domain = $_SERVER['HTTP_HOST'] ?? '';
        $cookieMetadata = $this->cookieMetadataFactory->createPublicCookieMetadata()
            ->setDuration(3600)
            ->setPath('/')
            ->setDomain($domain);

        if ($this->cookieManager->getCookie($cartTotalCookie) !== $cartTotalCookieValue) {
            $this->cookieManager->setPublicCookie($cartTotalCookie, $cartTotalCookieValue, $cookieMetadata);
        }

        if ($this->cookieManager->getCookie($shippingMethodCookie) !== $shippingMethodCookieValue) {
            $this->cookieManager->setPublicCookie($shippingMethodCookie, $shippingMethodCookieValue, $cookieMetadata);
        }

        if ($this->cookieManager->getCookie($paymentMethodCookie) !== $paymentMethodCookieValue) {
            $this->cookieManager->setPublicCookie($paymentMethodCookie, $paymentMethodCookieValue, $cookieMetadata);
        }

        $this->paydockLogger->info("updateCartCookie::afterSetCookies $cartTotalCookie set/updated with method: $paymentMethodCookieValue value: $cartTotalCookieValue and shipping: $shippingMethodCookieValue");
    }
}
