<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Api;

use Magento\Framework\Exception\LocalizedException;

interface ThreeDSRequestManagementInterface {
    /**
     * @param string $paymentToken
     * @param string $cartId
     * @return string|null
     * @throws LocalizedException
     */
    public function place3dsPreAuthRequest(string $paymentToken, string $cartId): ?string;
}
