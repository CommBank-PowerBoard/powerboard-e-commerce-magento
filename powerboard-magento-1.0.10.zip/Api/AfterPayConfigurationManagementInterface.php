<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Api;

interface AfterPayConfigurationManagementInterface {
    public const DEFAULT_XML_PATH_ACTIVE = 0;
    public const DEFAULT_XML_PATH_TITLE = 'Afterpay';
    public const DEFAULT_XML_PATH_GATEWAY_ID = '';
    public const DEFAULT_XML_PATH_MPID = '';
    public const DEFAULT_XML_PATH_PLACEMENT_ID = '';
    public const DEFAULT_XML_PATH_SORT_ORDER = '10';
    public const XML_PATH_ACTIVE = 'payment/paydock_afterpay/active';
    public const XML_PATH_TITLE = 'payment/paydock_afterpay/title';
    public const XML_PATH_GATEWAY_ID = 'payment/paydock_afterpay/gateway_id';
    public const XML_PATH_MPID = 'payment/paydock_afterpay/mpid';
    public const XML_PATH_PLACEMENT_ID = 'payment/paydock_afterpay/placement_id';

    /**
     * @return bool
     */
    public function isActive(): bool;

    /**
     * @return string
     */
    public function getTitle(): string;

    /**
     * @return string
     */
    public function getGatewayId(): string;

    /**
     * @return string
     */
    public function getMpid(): string;

    /**
     * @return string
     */
    public function getPlacementId(): string;
}
