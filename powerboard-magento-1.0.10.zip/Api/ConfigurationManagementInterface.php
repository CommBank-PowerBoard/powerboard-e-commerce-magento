<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Api;

use Paydock\Powerboard\Model\Config\Source\Environment;

interface ConfigurationManagementInterface {
    public const DEFAULT_XML_PATH_ACTIVE = 0;
    public const DEFAULT_XML_PATH_ENVIRONMENT = 'staging_cba';
    public const DEFAULT_XML_PATH_CSS = '{"background_color": "#ffffff"}';
    public const DEFAULT_XML_PATH_ENABLE_LOGGING = 0;
    public const DEFAULT_XML_PATH_ENABLE_AUTO_REFUND = 0;
    public const XML_PATH_ACTIVE = 'payment/paydock/active';
    public const XML_PATH_ENVIRONMENT = 'payment/paydock/environment';
    public const XML_PATH_API_ACCESS_TOKEN = 'payment/paydock/api_access_token';
    public const XML_PATH_WIDGET_ACCESS_TOKEN = 'payment/paydock/widget_access_token';
    public const XML_PATH_CSS = 'payment/paydock/css';
    public const XML_PATH_ENABLE_LOGGING = 'payment/paydock/enable_logging';
    public const XML_PATH_ENABLE_AUTO_REFUND = 'payment/paydock/enable_auto_refund';

    public const BASE_URL = [
        Environment::STAGING => 'https://api.staging.powerboard.commbank.com.au',
        Environment::PREPRODUCTION => 'https://api.preproduction.powerboard.commbank.com.au',
        Environment::PRODUCTION => 'https://api.powerboard.commbank.com.au'
    ];

    /**
     * @return bool
     */
    public function isActive(): bool;

    /**
     * @return string
     */
    public function getBaseUrl(): string;

    /**
     * @return string
     */
    public function getEnvironment(): string;

    /**
     * @param ?int $storeId
     * @return string
     */
    public function getApiAccessToken(?int $storeId = null): string;

    /**
     * @return string
     */
    public function getWidgetAccessToken(): string;

    /**
     * @return string
     */
    public function getCss(): string;

    /**
     * @param string $paymentMethod
     * @return string|null
     */
    public function getGatewayIdByPayment(string $paymentMethod): ?string;

    public function enableLogging(): bool;

    public function enableAutoRefund(): bool;
}
