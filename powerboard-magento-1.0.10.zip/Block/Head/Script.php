<?php

declare(strict_types=1);

namespace Paydock\Powerboard\Block\Head;

use Paydock\Powerboard\Helper\Paydock as PaydockHelper;
use Magento\Framework\View\Helper\SecureHtmlRenderer;

class Script extends \Magento\Framework\View\Element\AbstractBlock {
    const SDK_TEMPLATE = 'require.config({ map: { \'*\': { Paydock_Powerboard_Widget: \'https://widget.powerboard.commbank.com.au/sdk/v1.121.2/widget.umd.js\' } } });';

    const COOKIE_MANAGER = 'require([\'cookie-manager\']);';
    /**
     * @var PaydockHelper
     */
    protected $paydockHelper;

    private $secureRenderer;

    public function __construct(
        \Magento\Framework\View\Element\Context $context,
        PaydockHelper $paydockHelper,
        SecureHtmlRenderer $secureRenderer,
        array $data = []
    ) {
        $this->paydockHelper = $paydockHelper;
        $this->secureRenderer = $secureRenderer;
        parent::__construct($context, $data);
    }

    /**
     * Produce and return block's html output
     *
     * @return string
     */
    protected function _toHtml() {
        $nonce = $this->paydockHelper->getNonce();

        $sdkScript = $this->renderLinkTemplate($nonce, self::SDK_TEMPLATE);
        $cookieManagerScript = $this->renderLinkTemplate($nonce, self::COOKIE_MANAGER);

        $secureTagSdk = $this->secureRenderer->renderTag('script', ['type' => 'text/javascript', 'nonce' => $nonce], $sdkScript, false);
        $secureTagCookie = $this->secureRenderer->renderTag('script', ['type' => 'text/javascript', 'nonce' => $nonce], $cookieManagerScript, false);

        return $secureTagSdk . $secureTagCookie;
    }

    /**
     * @param string $assetUrl
     * @return string
     */
    protected function renderLinkTemplate($nonce, $template) {
        return str_replace(
            ['{nonce}'],
            [$nonce],
            $template
        );
    }
}
