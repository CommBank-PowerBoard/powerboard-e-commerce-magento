<?php

namespace Paydock\Powerboard\Plugin;

use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Framework\Serialize\SerializerInterface;
use Paydock\Powerboard\Logger\PaydockLogger;

class QuoteRepositoryPlugin {
    private $serializer;
    private $paydockLogger;

    public function __construct(SerializerInterface $serializer, PaydockLogger $paydockLogger) {
        $this->serializer = $serializer;
        $this->paydockLogger = $paydockLogger;
    }

    /**
     * Load custom attributes when retrieving a quote
     */
    public function afterGet(
        CartRepositoryInterface $subject,
        CartInterface $quote
    ) {
        $this->paydockLogger->info('QuoteRepositoryPlugin::afterGet called', ['quote_id' => $quote->getId()]);

        $walletData = $quote->getData('paydock_wallet_data');
        if ($walletData) {
            $this->paydockLogger->info('Deserializing paydock_wallet_data', ['data' => $walletData]);
            $quote->setCustomAttribute('paydock_wallet_data', $this->serializer->unserialize($walletData));
        }

        $cartData = $quote->getData('paydock_cart_data');
        if ($cartData) {
            $this->paydockLogger->info('Deserializing paydock_cart_data', ['data' => $cartData]);
            $quote->setCustomAttribute('paydock_cart_data', $this->serializer->unserialize($cartData));
        }

        return $quote;
    }

    /**
     * Save custom attributes before saving a quote
     */
    public function beforeSave(
        CartRepositoryInterface $subject,
        CartInterface $quote
    ) {
        $this->paydockLogger->info('QuoteRepositoryPlugin::beforeSave called', ['quote_id' => $quote->getId()]);

        $walletData = $quote->getCustomAttribute('paydock_wallet_data');
        if ($walletData) {
            $serializedWalletData = $this->serializer->serialize($walletData);
            $this->paydockLogger->info('Serializing paydock_wallet_data', ['data' => $serializedWalletData]);
            $quote->setData('paydock_wallet_data', $serializedWalletData);
        }

        $cartData = $quote->getCustomAttribute('paydock_cart_data');
        if ($cartData) {
            $serializedCartData = $this->serializer->serialize($cartData);
            $this->paydockLogger->info('Serializing paydock_cart_data', ['data' => $serializedCartData]);
            $quote->setData('paydock_cart_data', $serializedCartData);
        }
    }
}
