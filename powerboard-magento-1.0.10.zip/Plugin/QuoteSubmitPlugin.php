<?php

namespace Paydock\Powerboard\Plugin;

use Exception;
use Magento\Quote\Model\QuoteManagement;
use Magento\Quote\Model\Quote;
use Magento\Framework\Serialize\SerializerInterface;
use Paydock\Powerboard\Logger\PaydockLogger;
use Paydock\Powerboard\Gateway\ChargesService;
use Psr\Log\LoggerInterface;
use Paydock\Powerboard\Helper\QuoteHelper;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Paydock\Powerboard\Model\ConfigurationManagement;

class QuoteSubmitPlugin {
    private $serializer;
    private $paydockLogger;
    protected $quoteHelper;
    private $chargesService;
    private $logger;
    private $scopeConfig;
    private $configurationManagement;

    public function __construct(
        SerializerInterface $serializer,
        PaydockLogger $paydockLogger,
        QuoteHelper $quoteHelper,
        ChargesService $chargesService,
        LoggerInterface $logger,
        ScopeConfigInterface $scopeConfig,
        ConfigurationManagement $configurationManagement
    ) {
        $this->serializer = $serializer;
        $this->paydockLogger = $paydockLogger;
        $this->quoteHelper = $quoteHelper;
        $this->chargesService = $chargesService;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->configurationManagement = $configurationManagement;
    }

    public function aroundSubmit(QuoteManagement $subject, callable $proceed, Quote $quote) {
        try {
            $paymentMethod = $quote->getPayment()->getMethod();

            $this->paydockLogger->info('QuoteSubmitPlugin::aroundSubmit::begin', ['quote_id' => $quote->getId(), 'shippingMethod' => $quote->getShippingAddress()->getShippingMethod(), 'paymentMethod' => $paymentMethod]);

            $isWalletPayment = $this->quoteHelper->isWalletPayment();
            if ($isWalletPayment) {
                $this->validateWalletPayment($quote);
            }

            return $proceed($quote);
        } catch (\Exception $e) {
            $this->paydockLogger->info('QuoteSubmitPlugin::aroundSubmit::exception', ['message' => $e->getMessage()]);

            $paymentMethod = $quote->getPayment()->getMethod();
            $additionalInfo = $quote->getPayment()->getAdditionalInformation();
            $chargeId = $additionalInfo['response_id'] ?? null;
            $storeId = $quote->getStoreId();
            $quoteId = $quote->getId();

            if ($paymentMethod == 'paydock_zipmoney') {
                $chargeIds = $this->quoteHelper->getUnrefundedWalletCharges();
                if (count($chargeIds) > 1) {
                    $this->paydockLogger->info('QuoteSubmitPlugin::aroundSubmit::unrefunded_count_error', ['chargeIds' => $chargeIds]);
                }

                $chargeId = $chargeIds[0] ?? null;
            }

            $this->paydockLogger->info('QuoteSubmitPlugin::aroundSubmit::exception_quote_details', [
                'paymentMethod' => $paymentMethod,
                'quoteId' => $quoteId,
                'storeId' => $storeId,
                'chargeId' => $chargeId
            ]);

            if ($this->configurationManagement->enableAutoRefund()) {
                if ($chargeId) {
                    $this->paydockLogger->info('QuoteSubmitPlugin::aroundSubmit::perform_auto_refund', ['charge_id' => $chargeId, 'storeId' => $storeId]);
                    $this->chargesService->placeRefund($chargeId, 0, true, $storeId);
                    $this->quoteHelper->updatePaydockHistory(['refund' => $chargeId]);
                    throw new LocalizedException(__('The shipping method is missing. You have been refunded. Select the shipping method and try again.'));
                } else {
                    $this->paydockLogger->info('QuoteSubmitPlugin::aroundSubmit::no_chargeid', ['storeId' => $storeId, 'quote' => $quote->getId()]);
                }
            } else {
                $this->paydockLogger->info('QuoteSubmitPlugin::aroundSubmit::auto_refund_not_enabled', ['storeId' => $storeId, 'quote' => $quote->getId()]);
            }

            throw $e;
        }
    }

    private function validateWalletPayment(Quote $quote) {
        try {
            $this->paydockLogger->info('QuoteSubmitPlugin::validateWalletPayment::perform_wallet_validation', ['quoteId' => $quote->getId()]);

            $walletChargeVerified = $this->chargesService->verifyWalletCharge();
            $this->paydockLogger->info('QuoteSubmitPlugin::validateWalletPayment', ['walletChargeVerified' => $walletChargeVerified]);
            if (!$walletChargeVerified) {
                $this->paydockLogger->info('QuoteSubmitPlugin::validateWalletPayment::wallet_validation_failed', ['quoteId' => $quote->getId()]);
                throw new LocalizedException(__('Sorry, there has been an error processing your request. Please try again later.'));
            }
            $cartDataChanged = $this->quoteHelper->hasCartDataChanged();
            if ($cartDataChanged) {
                $this->paydockLogger->info('QuoteSubmitPlugin::validateWalletPayment', ['cartDataChanged' => $cartDataChanged]);
                $this->quoteHelper->revertCartData();
            }
        } catch (\Exception $e) {
            $this->paydockLogger->error('QuoteSubmitPlugin::validateWalletPayment::wallet_validation_exception', ['message' => $e->getMessage()]);
            throw new LocalizedException(__('Sorry, there has been an error processing your request. Please try again later.'));
        }
    }
}
