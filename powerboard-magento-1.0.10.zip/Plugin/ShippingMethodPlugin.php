<?php

namespace Paydock\Powerboard\Plugin;

use Paydock\Powerboard\Helper\CartCookieHelper;
use Magento\Quote\Model\Shipping;
use Paydock\Powerboard\Logger\PaydockLogger;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Quote\Api\CartRepositoryInterface;

class ShippingMethodPlugin {
    protected $cartCookieHelper;
    protected $paydockLogger;
    protected $checkoutSession;
    /**
     * @var
     */
    protected $quoteRepository;
    private static $lastMethod = null;

    public function __construct(
        CartCookieHelper $cartCookieHelper,
        PaydockLogger $paydockLogger,
        CheckoutSession $checkoutSession,
        CartRepositoryInterface $quoteRepository
    ) {
        $this->cartCookieHelper = $cartCookieHelper;
        $this->paydockLogger = $paydockLogger;
        $this->checkoutSession = $checkoutSession;
        $this->quoteRepository = $quoteRepository;
    }

    public function afterSetMethod(Shipping $subject, $result) {
        $this->paydockLogger->info('ShippingMethodPlugin::afterSetMethod');

        $quoteId = $this->checkoutSession->getQuoteId();
        if (!$quoteId) {
            return $result;
        }

        $this->paydockLogger->info('ShippingMethodPlugin::afterSetMethod quoteId: ' . $quoteId);

        $quote = $this->quoteRepository->get($quoteId);
        if ($quote) {
            $this->paydockLogger->info('ShippingMethodPlugin::afterSetMethod quote:' . $quoteId);
            $this->cartCookieHelper->updateCartCookie($quote);
        }

        return $result;
    }
}
