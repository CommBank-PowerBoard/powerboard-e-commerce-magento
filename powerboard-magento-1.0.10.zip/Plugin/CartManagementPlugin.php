<?php

namespace Paydock\Powerboard\Plugin;

use Magento\Checkout\Api\CartManagementInterface;
use Paydock\Powerboard\Helper\CartCookieHelper;
use Paydock\Powerboard\Logger\PaydockLogger;

class CartManagementPlugin {
    protected $cartCookieHelper;
    private $paydockLogger;

    public function __construct(
        CartCookieHelper $cartCookieHelper,
        PaydockLogger $paydockLogger
    ) {
        $this->cartCookieHelper = $cartCookieHelper;
        $this->paydockLogger = $paydockLogger;
    }

    /**
     * After plugin for setPaymentInformation method
     */
    public function afterSetPaymentInformation(
        CartManagementInterface $subject,
        $result,
        $cartId,
        $paymentData
    ) {
        $quote = $subject->getQuote();
        $this->paydockLogger->info('CartManagementPlugin::afterSetPaymentInformation called for cartId: ' . $cartId);
        $this->cartCookieHelper->updateCartCookie($quote);

        return $result;
    }
}
