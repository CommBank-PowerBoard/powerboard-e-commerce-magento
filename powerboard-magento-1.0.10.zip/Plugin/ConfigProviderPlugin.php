<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Plugin;

use Magento\Checkout\Model\DefaultConfigProvider;
use Paydock\Powerboard\Model\CreditCardConfigurationManagement;

class ConfigProviderPlugin {
    /**
     * @var CreditCardConfigurationManagement
     */
    private CreditCardConfigurationManagement $creditCardConfigurationManagement;

    /**
     * @param CreditCardConfigurationManagement $creditCardConfigurationManagement
     */
    public function __construct(
        CreditCardConfigurationManagement $creditCardConfigurationManagement
    ) {
        $this->creditCardConfigurationManagement = $creditCardConfigurationManagement;
    }

    /**
     * @param DefaultConfigProvider $subject
     * @param array $result
     * @return array
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function afterGetConfig(DefaultConfigProvider $subject, array $result): array {
        if (isset($result['quoteData'])) {
            $keysToUnset = [
                'paydock_wallet_data',
                'paydock_cart_data',
                'paydock_stored_payment_sources',
                'paydock_history',
            ];

            foreach ($keysToUnset as $key) {
                unset($result['quoteData'][$key]);
            }
        }


        return $result;
    }
}
