<?php

namespace Paydock\Powerboard\Logger;

use Paydock\Powerboard\Logger\Handler\PaydockHandler;

class PaydockLogger extends \Magento\Framework\Logger\Monolog {
    protected $isLoggingEnabled;

    public function __construct(
        PaydockHandler $handler,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        array $data = []
    ) {
        $this->isLoggingEnabled = $scopeConfig->isSetFlag(
            'payment/paydock/enable_logging',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );

        parent::__construct('paydock', [$handler]);
    }

    public function info($message, array $context = []): void {
        if ($this->isLoggingEnabled) {
            parent::info($message, $context);
        }
    }

    public function error($message, array $context = []): void {
        if ($this->isLoggingEnabled) {
            parent::info($message, $context);
        }
    }

    public function debug($message, array $context = []): void {
        if ($this->isLoggingEnabled) {
            parent::info($message, $context);
        }
    }
}
