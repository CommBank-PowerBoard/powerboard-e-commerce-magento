<?php

namespace Paydock\Powerboard\Logger\Handler;

use Magento\Framework\Logger\Handler\Base;
use Monolog\Logger;

class PaydockHandler extends Base {
    protected $fileName = '/var/log/paydock.log';
    protected $loggerType = Logger::DEBUG;
}
