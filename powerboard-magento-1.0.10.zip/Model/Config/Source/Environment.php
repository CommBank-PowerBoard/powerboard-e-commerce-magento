<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model\Config\Source;

use Magento\Framework\Data\OptionSourceInterface;

class Environment implements OptionSourceInterface {
    public const STAGING = 'staging_cba';
    public const PREPRODUCTION = 'preproduction_cba';
    public const PRODUCTION = 'production_cba';

    /**
     * @return array
     */
    public function toOptionArray(): array {
        return [
            [
                'value' => self::STAGING,
                'label' => __('Staging')
            ],
            [
                'value' => self::PREPRODUCTION,
                'label' => __('Pre-production')
            ],
            [
                'value' => self::PRODUCTION,
                'label' => __('Production')
            ]
        ];
    }
}
