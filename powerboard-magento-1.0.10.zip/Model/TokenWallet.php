<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Quote\Model\MaskedQuoteIdToQuoteIdInterface;
use Magento\Quote\Model\QuoteRepository;
use Paydock\Powerboard\Api\ChargesServiceInterface;
use Paydock\Powerboard\Api\TokenWalletInterface;
use Psr\Log\LoggerInterface;
use Paydock\Powerboard\Helper\QuoteHelper;
use Magento\Quote\Model\Quote;
use Magento\Framework\App\RequestInterface;
use Paydock\Powerboard\Logger\PaydockLogger;

class TokenWallet implements TokenWalletInterface {
    /**
     * @var ChargesServiceInterface
     */
    private ChargesServiceInterface $chargesService;

    /**
     * @var MaskedQuoteIdToQuoteIdInterface
     */
    private MaskedQuoteIdToQuoteIdInterface $maskedQuoteIdToQuoteId;

    /**
     * @var PaydockLogger
     */
    private PaydockLogger $paydockLogger;

    /**
     * @var Json
     */
    private Json $json;

    /**
     * @var QuoteRepository
     */
    private QuoteRepository $quoteRepository;

    /**
     * @var QuoteHelper
     */
    private QuoteHelper $quoteHelper;

    protected RequestInterface $requestInterface;

    /**
     * @var Quote
     */
    private Quote $quote;


    /**
     * @param ChargesServiceInterface $chargesService
     * @param PaydockLogger $logger
     * @param Json $json
     * @param QuoteRepository $quoteRepository
     * @param MaskedQuoteIdToQuoteIdInterface $maskedQuoteIdToQuoteId
     * @param QuoteHelper $maskedQuoteIdToQuoteId
     */
    public function __construct(
        ChargesServiceInterface $chargesService,
        PaydockLogger $paydockLogger,
        Json $json,
        QuoteRepository $quoteRepository,
        MaskedQuoteIdToQuoteIdInterface $maskedQuoteIdToQuoteId,
        QuoteHelper $quoteHelper,
        RequestInterface $requestInterface
    ) {
        $this->chargesService = $chargesService;
        $this->paydockLogger = $paydockLogger;
        $this->json = $json;
        $this->quoteRepository = $quoteRepository;
        $this->maskedQuoteIdToQuoteId = $maskedQuoteIdToQuoteId;
        $this->quoteHelper = $quoteHelper;
        $this->requestInterface = $requestInterface;
    }

    /**
     * @inheritDoc
     */
    public function generateWalletToken(string $cartId, string $force = 'false'): string|bool {
        try {
            $response = ['success' => true, 'token_wallet' => '', 'error' => ''];

            $force = $this->requestInterface->getParam('force') === 'true';
            $this->paydockLogger->info('TokenWallet::generateWalletToken', ['cartId' => $cartId, 'force' => $force]);


            if (!is_numeric($cartId)) {
                $cartId = $this->maskedQuoteIdToQuoteId->execute($cartId);
            }
            if (!is_numeric($cartId)) {
                $response = ['success' => false, 'token_wallet' => '', 'error' => 'Quote id is not valid'];
                return $this->json->serialize($response);
            }

            $this->quote = $this->quoteRepository->get($cartId);


            $shippingAddress = $this->quote->getShippingAddress();
            $shippingAddressValid = $this->quote->getShippingAddress()->validate();
            $shippingMethod = $shippingAddress->getShippingMethod();
            $paymentMethod = $this->quote->getPayment()->getMethod();
            $isVirtual = $this->quote->getIsVirtual();
            $billingAddressValid = $this->quote->getBillingAddress()->validate();
            $quoteActive = $this->quote->getIsActive();

            if (!$quoteActive) {
                $response['success'] = false;
                $response['error'] .= 'Cart is not active';

                return $this->json->serialize($response);
            }

            $this->paydockLogger->info('tokenWallet::generateWalletToken ', ['paymentMethod' => $paymentMethod, 'isVirtual' => $isVirtual, 'billingAddress' => $billingAddressValid, 'shippingAddress' => $shippingAddressValid, 'shippingMethod' => $shippingMethod]);

            if (!$paymentMethod) {
                $response['success'] = false;
                $response['error'] = 'No payment method selected';

                $this->paydockLogger->info('TokenWallet::generateWalletToken', ['No payment method' => json_encode($response)]);

                return $this->json->serialize($response);
            }

            if ($isVirtual) {
                if ($billingAddressValid !== true) {
                    $response['success'] = false;
                    $response['error'] = 'Billing address is required';

                    $this->paydockLogger->info('TokenWallet::generateWalletToken', ['Billing address is required' => json_encode($response)]);

                    return $this->json->serialize($response);
                }
            } else {
                if ($shippingAddressValid != true || !$shippingMethod && !$isVirtual) {

                    $response['success'] = false;
                    $response['error'] = 'No shipping method selected';

                    $this->paydockLogger->info('TokenWallet::generateWalletToken', ['No shipping method' => json_encode($response)]);

                    return $this->json->serialize($response);
                }
            }

            $tokenWallet = $this->chargesService->getWalletToken($this->quote, $force);
            if (isset($tokenWallet['token']) && !empty($tokenWallet['token'])) {
                $response = ['success' => true, 'token_wallet' => $tokenWallet['token'], 'error' => '', 'charge_id' => $tokenWallet['charge']['_id']];
            } else {
                $this->paydockLogger->critical(__("Wallet charge token not returned for %1 %2", $cartId, json_encode($tokenWallet)));
                $response = ['success' => false, 'token_wallet' => '', 'error' => 'Quote not found'];
            }
        } catch (NoSuchEntityException $e) {

            $this->paydockLogger->critical(__("Quote %1 is not found: %2", $cartId, $e->getMessage()));
            $response = ['success' => false, 'token_wallet' => '', 'error' => 'Quote not found'];
        } catch (LocalizedException $e) {
            $this->paydockLogger->critical(__("Quote get wallet token error for %1: %2", $cartId, $e->getMessage()));
            $response = ['success' => false, 'token_wallet' => '', 'error' => $e->getMessage()];
        }

        return $this->json->serialize($response);
    }
}
