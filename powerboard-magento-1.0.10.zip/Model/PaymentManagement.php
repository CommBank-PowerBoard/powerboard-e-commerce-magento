<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model;

use Magento\Quote\Model\Quote;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use Paydock\Powerboard\Api\PaymentManagementInterface;
use Paydock\Powerboard\Logger\PaydockLogger;

class PaymentManagement implements PaymentManagementInterface {
    /**
     * @var CreditCardConfigurationManagement
     */
    private CreditCardConfigurationManagement $creditCardConfigurationManagement;

    /**
     * @var PaydockLogger
     */
    private PaydockLogger $paydockLogger;

    /**
     * @param CreditCardConfigurationManagement $creditCardConfigurationManagement
     */
    public function __construct(
        CreditCardConfigurationManagement $creditCardConfigurationManagement,
        PaydockLogger $paydockLogger
    ) {
        $this->creditCardConfigurationManagement = $creditCardConfigurationManagement;
        $this->paydockLogger = $paydockLogger;
    }

    /**
     * @inheritDoc
     */
    public function canSaveCard(OrderPaymentInterface $payment): bool {

        $this->paydockLogger->info('PaymentManagement::canSaveCard');

        $ccConfigSaveCard = $this->creditCardConfigurationManagement->canSaveCard();
        $saveCard = $payment->getAdditionalInformation('cc_save') ?? false;
        $order = $payment->getOrder();
        $customerId = $order->getCustomerId();

        $this->paydockLogger->info('PaymentManagement::canSaveCard', ['ccConfigSaveCard' => $ccConfigSaveCard, 'saveCard' => $saveCard, 'customerId' => $customerId]);

        return $ccConfigSaveCard && $saveCard && $customerId;
    }

    /**
     * @inheritDoc
     */
    public function isPaymentSources(OrderPaymentInterface $payment): bool {
        $paymentSourceId = $payment->getAdditionalInformation('payment_source_id') ?? false;
        $order = $payment->getOrder();
        $customerId = $order->getCustomerId();

        $this->paydockLogger->info('PaymentManagement::isPaymentSources', ['paymentsourceId' => $paymentSourceId, 'customerId' => $customerId]);

        return $paymentSourceId && $customerId;
    }
}
