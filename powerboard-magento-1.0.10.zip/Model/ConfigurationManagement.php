<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model;

use Paydock\Powerboard\Api\AfterPayConfigurationManagementInterface;
use Paydock\Powerboard\Api\ApplePayConfigurationManagementInterface;
use Paydock\Powerboard\Api\ConfigurationManagementInterface;
use Paydock\Powerboard\Api\CreditCardConfigurationManagementInterface;
use Paydock\Powerboard\Api\Data\PaydockAfterPayInterface;
use Paydock\Powerboard\Api\Data\PaydockApplePayInterface;
use Paydock\Powerboard\Api\Data\PaydockCreditCardInterface;
use Paydock\Powerboard\Api\Data\PaydockGooglePayInterface;
use Paydock\Powerboard\Api\Data\PaydockPaypalInterface;
use Paydock\Powerboard\Api\Data\PaydockZipMoneyInterface;
use Paydock\Powerboard\Api\GooglePayConfigurationManagementInterface;
use Paydock\Powerboard\Api\PaypalConfigurationManagementInterface;
use Paydock\Powerboard\Api\ZipMoneyConfigurationManagementInterface;
use Paydock\Powerboard\Helper\StoreHelper;

class ConfigurationManagement implements ConfigurationManagementInterface {
    /**
     * @var StoreHelper
     */
    private StoreHelper $storeHelper;

    public function __construct(
        StoreHelper $storeHelper
    ) {
        $this->storeHelper = $storeHelper;
    }

    /**
     * @inheritDoc
     */
    public function isActive(): bool {
        return (bool)$this->storeHelper->getStoreViewConfig(self::XML_PATH_ACTIVE)
            && !empty($this->getApiAccessToken())
            && !empty($this->getWidgetAccessToken());
    }

    /**
     * @inheritDoc
     */
    public function getBaseUrl(): string {
        return self::BASE_URL[$this->getEnvironment()];
    }

    /**
     * {@inheritdoc}
     */
    public function getEnvironment(): string {
        return $this->storeHelper->getStoreViewConfig(self::XML_PATH_ENVIRONMENT);
    }

    /**
     * @param ?int $storeId
     * {@inheritdoc}
     */
    public function getApiAccessToken(?int $storeId = null): string {
        return $this->storeHelper->getStoreViewConfig(self::XML_PATH_API_ACCESS_TOKEN, $storeId);
    }

    /**
     * {@inheritdoc}
     */
    public function getWidgetAccessToken(): string {
        return $this->storeHelper->getStoreViewConfig(self::XML_PATH_WIDGET_ACCESS_TOKEN);
    }

    /**
     * {@inheritdoc}
     */
    public function getCss(): string {
        return $this->storeHelper->getStoreViewConfig(self::XML_PATH_CSS);
    }

    public function enableLogging(): bool {
        return (bool)$this->storeHelper->getStoreViewConfig(self::XML_PATH_ENABLE_LOGGING);
    }

    public function enableAutoRefund(): bool {
        return (bool)$this->storeHelper->getStoreViewConfig(self::XML_PATH_ENABLE_AUTO_REFUND);
    }

    /**
     * {@inheritdoc}
     */
    public function getGatewayIdByPayment(string $paymentMethod): ?string {
        $path = null;
        switch ($paymentMethod) {
            case PaydockCreditCardInterface::METHOD_CODE:
                $path = CreditCardConfigurationManagementInterface::XML_PATH_GATEWAY_ID;
                break;
            case PaydockPaypalInterface::METHOD_CODE:
                $path = PaypalConfigurationManagementInterface::XML_PATH_GATEWAY_ID;
                break;
            case PaydockApplePayInterface::METHOD_CODE:
                $path = ApplePayConfigurationManagementInterface::XML_PATH_GATEWAY_ID;
                break;
            case PaydockGooglePayInterface::METHOD_CODE:
                $path = GooglePayConfigurationManagementInterface::XML_PATH_GATEWAY_ID;
                break;
            case PaydockAfterPayInterface::METHOD_CODE:
                $path = AfterPayConfigurationManagementInterface::XML_PATH_GATEWAY_ID;
                break;
            case PaydockZipMoneyInterface::METHOD_CODE:
                $path = ZipMoneyConfigurationManagementInterface::XML_PATH_GATEWAY_ID;
                break;
        }

        return $this->storeHelper->getStoreViewConfig($path);
    }
}
