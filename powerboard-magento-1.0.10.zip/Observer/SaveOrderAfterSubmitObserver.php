<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Paydock\Powerboard\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer as EventObserver;
use Paydock\Powerboard\Logger\PaydockLogger;
use Paydock\Powerboard\Helper\QuoteHelper;

class SaveOrderAfterSubmitObserver implements ObserverInterface {

    protected $paydockLogger;
    protected $quoteHelper;
    /**
     * Constructor
     *
     * @param \Magento\Framework\Registry $coreRegistry
     */
    public function __construct(
        PaydockLogger $paydockLogger,
        QuoteHelper $quoteHelper
    ) {
        $this->paydockLogger = $paydockLogger;
        $this->quoteHelper = $quoteHelper;
    }

    /**
     * Save order into registry to use it in the overloaded controller.
     *
     * @param EventObserver $observer
     * @return $this
     */
    public function execute(EventObserver $observer) {
        /* @var $order \Magento\Sales\Model\Order */


        $this->paydockLogger->info('SaveOrderAfterSubmitObserver::execute');

        $this->quoteHelper->clearPaydockPaymentSources();

        return $this;
    }
}
