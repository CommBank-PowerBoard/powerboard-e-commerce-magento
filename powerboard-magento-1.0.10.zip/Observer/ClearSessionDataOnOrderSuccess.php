<?php

namespace Paydock\Powerboard\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Paydock\Powerboard\Helper\QuoteHelper;

class ClearSessionDataOnOrderSuccess implements ObserverInterface {
    /**
     * @var QuoteHelper
     */
    protected $quoteHelper;

    /**
     * @param QuoteHelper $quoteHelper
     */
    public function __construct(QuoteHelper $quoteHelper) {
        $this->quoteHelper = $quoteHelper;
    }

    /**
     * Execute the observer.
     *
     * This method is called when the 'sales_model_service_quote_submit_success' event is dispatched.
     * It calls the helper method to clear all Paydock-related data from the checkout session.
     *
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer) {
        $this->quoteHelper->clearAllPaydockSessionData();
    }
}
