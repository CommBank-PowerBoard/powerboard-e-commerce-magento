<?php

namespace Paydock\Powerboard\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Checkout\Model\Cart;
use Paydock\Powerboard\Helper\CartCookieHelper;
use Paydock\Powerboard\Logger\PaydockLogger;
use Paydock\Powerboard\Helper\QuoteHelper;

class CartSaveObserver implements ObserverInterface {
    protected $cartCookieHelper;
    private $paydockLogger;
    protected $paydockQuoteHelper;

    public function __construct(
        CartCookieHelper $cartCookieHelper,
        PaydockLogger $paydockLogger,
        QuoteHelper $paydockQuoteHelper
    ) {
        $this->cartCookieHelper = $cartCookieHelper;
        $this->paydockLogger = $paydockLogger;
        $this->paydockQuoteHelper = $paydockQuoteHelper;
    }

    /**
     * Execute the observer when the cart is saved (i.e., after changes to shipping, total, payment, or products)
     */
    public function execute(Observer $observer) {
        /** @var Cart $cart */
        $cart = $observer->getEvent()->getCart();
        $quote = $cart->getQuote();

        $this->paydockLogger->info('CartSaveObserver::execute');

        $this->paydockQuoteHelper->refreshWalletToken($quote);

        $this->cartCookieHelper->updateCartCookie($quote);
    }
}
