<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Helper;

use Exception;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\State;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Backend\Model\Session\Quote as SessionQuote;
use Magento\Framework\App\Area;
use Psr\Log\LoggerInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Store\Model\ScopeInterface;
use \Magento\Store\Api\StoreRepositoryInterface;
use \Magento\Framework\App\Config\ScopeConfigInterface;
use Paydock\Powerboard\Logger\PaydockLogger;

class StoreHelper {
    /**
     * @var StoreManagerInterface
     */
    private StoreManagerInterface $storeManager;

    /**
     * @var CheckoutSession
     */
    private CheckoutSession $checkoutSession;

    /**
     * @var SessionQuote
     */
    private SessionQuote $sessionQuote;

    /**
     * @var StoreRepositoryInterface
     */
    private StoreRepositoryInterface $storeRepository;

    /**
     * @var State
     */
    private State $state;

    /**
     * @var PaydockLogger
     */
    private PaydockLogger $paydockLogger;
    /**
     * @var ScopeConfigInterface
     */
    private ScopeConfigInterface $scopeConfig;

    public function __construct(
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager,
        StoreRepositoryInterface $storeRepository,
        CheckoutSession $checkoutSession,
        SessionQuote $sessionQuote,
        State $state,
        PaydockLogger $paydockLogger
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->storeRepository = $storeRepository;
        $this->checkoutSession = $checkoutSession;
        $this->sessionQuote = $sessionQuote;
        $this->state = $state;
        $this->paydockLogger = $paydockLogger;
    }

    /**
     * getStoreViewConfig
     * @param string $path
     * @param mixed $storeViewId
     * @return mixed
     */
    public function getStoreViewConfig($path, $storeViewId = null): mixed {
        try {
            $areaCode = $this->state->getAreaCode();
        } catch (Exception $e) {
            $areaCode = '';
        }

        if ($areaCode === Area::AREA_ADMINHTML && $storeViewId === null) {
            $storeViewId = $this->sessionQuote->getQuote()->getStoreId();
            $configValue = $this->scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE, $storeViewId);
        } else {
            $storeViewId = $storeViewId ?: $this->storeManager->getStore()->getId();
            $configValue = $this->scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE, $storeViewId);
            $this->paydockLogger->info('StoreHelper::getStoreViewConfig NON ADMIN', ['$path' => $path, '$storeViewId' => $storeViewId, '$configValue' => $configValue]);
        }
        return $configValue;
    }

    /**
     * getStoreCode
     */
    public function getStoreCode(): int|null {
        try {
            $store = $this->storeRepository->get('store_code');
            return $store->getId();
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            return null;
        }
    }

    /**
     * Get WebsiteId for current session / order
     * @param ?int $storeId
     * @return int
     */
    public function getWebsiteId(?int $storeId = null): int {
        try {
            $areaCode = $this->state->getAreaCode();
        } catch (LocalizedException $e) {
            $areaCode = '';
        }

        $quote = $areaCode === Area::AREA_ADMINHTML
            ? $this->sessionQuote->getQuote()
            : $this->checkoutSession->getQuote();

        if (!$storeId) {
            $storeId = $quote->getStoreId();
        }

        $websiteId = $this->storeManager->getStore($storeId)->getId();

        return (int)$websiteId;
    }
}
