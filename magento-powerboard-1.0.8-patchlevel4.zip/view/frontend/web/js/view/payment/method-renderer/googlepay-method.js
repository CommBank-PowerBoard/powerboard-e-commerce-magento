define([
    "Magento_Checkout/js/view/payment/default",
    "jquery",
    'ko',
    "Paydock_Powerboard/js/action/googlepay",
    "Magento_Checkout/js/action/select-payment-method",
    "Magento_Checkout/js/checkout-data",
    "CartObserver",
    'WalletMetaValidator'
], function (
    paymentDefault,
    $,
    ko,
    loadGooglePayButtonAction,
    selectPaymentMethodAction,
    checkoutData,
    cartObserver,
    walletMetaValidator
) {
    "use strict";
    return paymentDefault.extend({
        defaults: {
            template: "Paydock_Powerboard/payment/googlepay-form",
        },
        widgetLoadedGooglePay: false,
        googlePayPreviousTotal: null,
        isValidationPassed: ko.observable(true),

        initialize: function () {
            this._super();

            this.subscribeToFormUpdates();
            this.subscribeToCartUpdates();
            this.loadGooglePayButton();
        },

        subscribeToFormUpdates: function () {
            walletMetaValidator.isValid.subscribe((isValid) => {
                this.isValidationPassed(isValid);
            });
        },

        subscribeToCartUpdates: function () {
            cartObserver.cartTotalChanged.subscribe((newTotal) => {     
                this.loadGooglePayButton();
            });

            cartObserver.shippingChanged.subscribe((newTotal) => {   
                this.loadGooglePayButton();
            });
        },

        loadGooglePayButton: function() {
            if (checkoutData.getSelectedPaymentMethod() !== this.getCode()) {
                return;
            }

            if(this.googlePayPreviousTotal != cartObserver.cartTotal()) {
                $('#paydock_googlepay_widget').empty();
                this.widgetLoadedGooglePay = false;
            }

            if (this.widgetLoadedGooglePay || !this.isValidationPassed) {
                return;
            }

            $('#paydock_googlepay_widget').empty();


            loadGooglePayButtonAction();

            this.widgetLoadedGooglePay = true;
            this.googlePayPreviousTotal = cartObserver.cartTotal();
        },

        isChecked: ko.computed(function() {
            return checkoutData.getSelectedPaymentMethod();
        }),

        getCode: function () {
            return this.item.method;
        },

        getLogoSrc: function () {
            return window.checkoutConfig.payment.paydockGooglePay.logoSrc ?? "";
        },

        getData: function () {
            return {
                method: this.getCode(),
                additional_data: {
                    response_id: $('input[id="googlepay-response-id"]').val(),
                },
            };
        },

        selectPaymentMethod: function() {
            selectPaymentMethodAction(this.getData());
            
            checkoutData.setSelectedPaymentMethod(this.getCode());


            setTimeout(() => {
                this.loadGooglePayButton();
            }, 1500);
        
            return true;
        }
    });
});
