<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Api\Data;

interface PaydockCreditCardInterface
{
    public const METHOD_CODE = 'paydock_cc';
}

