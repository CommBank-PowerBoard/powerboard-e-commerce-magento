<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Api;

use Magento\Quote\Model\Quote;
use Magento\Sales\Api\Data\OrderPaymentInterface;

interface PaymentManagementInterface
{
    /**
     * @param OrderPaymentInterface|Quote $payment
     * @return bool
     */
    public function canSaveCard(OrderPaymentInterface|Quote $payment): bool;

    /**
     * @param OrderPaymentInterface|Quote $payment
     * @return bool
     */
    public function isPaymentSources(OrderPaymentInterface|Quote $payment): bool;
}
