<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Api;

use Paydock\Powerboard\Model\Config\Source\Environment;

interface ConfigurationManagementInterface
{
    public const DEFAULT_XML_PATH_ACTIVE = 0;
    public const DEFAULT_XML_PATH_ENVIRONMENT = 'staging_cba';
    public const DEFAULT_XML_PATH_CSS = '{"background_color": "#ffffff"}';
    public const XML_PATH_ACTIVE = 'payment/paydock/active';
    public const XML_PATH_ENVIRONMENT = 'payment/paydock/environment';
    public const XML_PATH_SECRET_KEY = 'payment/paydock/secret_key';
    public const XML_PATH_PUBLIC_KEY = 'payment/paydock/public_key';
    public const XML_PATH_CSS = 'payment/paydock/css';

    public const BASE_URL = [
        Environment::SANDBOX => 'https://api.staging.powerboard.commbank.com.au',
        Environment::PREPRODUCTION => 'https://api.preproduction.powerboard.commbank.com.au',
        Environment::PRODUCTION => 'https://api.powerboard.commbank.com.au'
    ];

    /**
     * @return bool
     */
    public function isActive(): bool;

    /**
     * @return string
     */
    public function getBaseUrl(): string;

    /**
     * @return string
     */
    public function getEnvironment(): string;

    /**
     * @return string
     */
    public function getSecretKey(): string;

    /**
     * @return string
     */
    public function getPublicKey(): string;

    /**
     * @return string
     */
    public function getCss(): string;

    /**
     * @param string $paymentMethod
     * @return string|null
     */
    public function getGatewayIdByPayment(string $paymentMethod): ?string;
}

