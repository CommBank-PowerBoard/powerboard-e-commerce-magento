<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare (strict_types = 1);

namespace Paydock\Powerboard\Block\Adminhtml\System\Config\Form\Field;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Config\Model\Config\Source\Enabledisable;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Paydock\Powerboard\Api\PaypalConfigurationManagementInterface;

class PaypalActiveActionField extends Field
{
    /**
     * @param AbstractElement $element
     * @return string
     */
    protected function _getElementHtml(AbstractElement $element): string
    {
        $html = parent::_getElementHtml($element);
        $htmlId = $element->getHtmlId();
        $paymentHtmlId = str_replace('_active', '', $htmlId);
        $inheritHtmlId = $htmlId . '_inherit';
        $script = "
            <script>
                require(['jquery'], function ($) {
                    $(document).ready(function () {
                        function updatePaypalActiveAction() {
                            if (parseInt($('#{$htmlId}').val()) === " . Enabledisable::DISABLE_VALUE . ") {
                                " . $this->renderPaypalScripts($paymentHtmlId) . "
                            }
                        }
                        updatePaypalActiveAction();
                        $('#{$htmlId}').on('change', function () {
                            updatePaypalActiveAction();
                            $('#{$inheritHtmlId}').prop('checked', false );
                        });
                    });
                });
            </script>
        ";

        return $html . $script;
    }

    /**
     * Backend admin script on active toggle
     *
     * @param string $paymentHtmlId
     * @return string
     */
    public function renderPaypalScripts(string $paymentHtmlId): string
    {
        $paypalTitle = PaypalConfigurationManagementInterface::DEFAULT_XML_PATH_TITLE;
        $paypalGatewayId = PaypalConfigurationManagementInterface::DEFAULT_XML_PATH_GATEWAY_ID;
        $paypalStyleColor = PaypalConfigurationManagementInterface::DEFAULT_XML_PATH_STYLE_COLOR;
        $paypalStyleTagline = PaypalConfigurationManagementInterface::DEFAULT_XML_PATH_STYLE_TAGLINE;
        $paypalStyleLabel = PaypalConfigurationManagementInterface::DEFAULT_XML_PATH_STYLE_LABEL;
        $paypalSortOrder = PaypalConfigurationManagementInterface::DEFAULT_XML_PATH_SORT_ORDER;
        $scripts = "
            $('#{$paymentHtmlId} input[type=\"text\"]').val('');
            $('#{$paymentHtmlId} input[type=\"checkbox\"]').prop('checked', true );
            $('#{$paymentHtmlId}_gateway_id').val('{$paypalGatewayId}').prop('disabled', true);
            $('#{$paymentHtmlId}_title').val('{$paypalTitle}').prop('disabled', true);
            $('#{$paymentHtmlId}_style_color').val('{$paypalStyleColor}');
            $('#{$paymentHtmlId}_style_tagline').val('{$paypalStyleTagline}');
            $('#{$paymentHtmlId}_style_label').val('{$paypalStyleLabel}');
            $('#{$paymentHtmlId}_sort_order').val('{$paypalSortOrder}');
        ";
        return $scripts;
    }
}
