<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Block\Adminhtml\System\Config\Form\Field;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;

class StyleLayoutField extends Field
{
    /**
     * @inheritdoc
     */
    protected function _getElementHtml(AbstractElement $element): string
    {
        $html = parent::_getElementHtml($element);
        $htmlId = $element->getHtmlId();
        $paymentHtmlId = str_replace('_style_layout', '', $htmlId);
        $script = "
            <script>
                require(['jquery'], function ($) {
                    $(document).ready(function () {
                        function updateStyleTaglineValue() {
                            if ($('#{$htmlId}').val() === 'vertical') {
                                $('#{$paymentHtmlId}_style_tagline').val([]);
                            }
                        }
                        updateStyleTaglineValue();
                        $('#{$htmlId}').on('change', function () {
                            updateStyleTaglineValue();
                        });
                    });
                });
            </script>
        ";
        
        return $html . $script;
    }
}
