<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare (strict_types = 1);

namespace Paydock\Powerboard\Block\Adminhtml\System\Config\Form\Field;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Config\Model\Config\Source\Enabledisable;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Paydock\Powerboard\Api\ApplePayConfigurationManagementInterface;
use Paydock\Powerboard\Api\GooglePayConfigurationManagementInterface;
use Paydock\Powerboard\Api\ZipMoneyConfigurationManagementInterface;

class GeneralActiveActionField extends Field
{
    /**
     * @param AbstractElement $element
     * @return string
     */
    protected function _getElementHtml(AbstractElement $element): string
    {
        $html = parent::_getElementHtml($element);
        $activehtmlId = $element->getHtmlId();
        $htmlId = str_replace('_active', '', $activehtmlId);
        $script = "
            <script>
                require(['jquery'], function ($) {
                    $(document).ready(function () {
                        function updateGeneralActiveAction{$htmlId}() {
                            if (parseInt($('#{$activehtmlId}').val()) === " . Enabledisable::DISABLE_VALUE . ") {
                                " . $this->renderGeneralScripts($htmlId) . "
                            }
                        }
                        updateGeneralActiveAction{$htmlId}();
                        $('#{$htmlId}').on('change', function () {
                            updateGeneralActiveAction{$htmlId}();
                            $('#{$activehtmlId}_inherit').prop('checked', false );
                        });
                    });
                });
            </script>
        ";

        return $html . $script;
    }

    /**
     * Backend admin script on active toggle
     * @param string $htmlId
     *
     * @return string
     */
    public function renderGeneralScripts(string $htmlId): string
    {
        $gatewayId = $title = '';
        if (strpos($htmlId, 'applepay') !== false) {
            $gatewayId = ApplePayConfigurationManagementInterface::DEFAULT_XML_PATH_GATEWAY_ID;
            $title = ApplePayConfigurationManagementInterface::DEFAULT_XML_PATH_TITLE;
            $sortOrder = ApplePayConfigurationManagementInterface::DEFAULT_XML_PATH_SORT_ORDER;
        } elseif (strpos($htmlId, 'googlepay') !== false) {
            $gatewayId = GooglePayConfigurationManagementInterface::DEFAULT_XML_PATH_GATEWAY_ID;
            $title = GooglePayConfigurationManagementInterface::DEFAULT_XML_PATH_TITLE;
            $sortOrder = GooglePayConfigurationManagementInterface::DEFAULT_XML_PATH_SORT_ORDER;
        } elseif (strpos($htmlId, 'zipmoney') !== false) {
            $gatewayId = ZipMoneyConfigurationManagementInterface::DEFAULT_XML_PATH_GATEWAY_ID;
            $title = ZipMoneyConfigurationManagementInterface::DEFAULT_XML_PATH_TITLE;
            $sortOrder = ZipMoneyConfigurationManagementInterface::DEFAULT_XML_PATH_SORT_ORDER;
        }
        $scripts = "
            $('#{$htmlId} input[type=\"text\"]').val('').prop('disabled', true);
            $('#{$htmlId} input[type=\"checkbox\"]').prop('checked', true );
            $('#{$htmlId}_gateway_id').val('{$gatewayId}').prop('disabled', true);
            $('#{$htmlId}_title').val('{$title}').prop('disabled', true);
            $('#{$htmlId}_sort_order').val('{$sortOrder}').prop('disabled', true);
        ";
        return $scripts;
    }
}
