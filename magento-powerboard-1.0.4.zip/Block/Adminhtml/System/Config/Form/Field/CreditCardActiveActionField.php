<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare (strict_types = 1);

namespace Paydock\Powerboard\Block\Adminhtml\System\Config\Form\Field;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Config\Model\Config\Source\Enabledisable;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Paydock\Powerboard\Api\CreditCardConfigurationManagementInterface;

class CreditCardActiveActionField extends Field
{
    /**
     * @param AbstractElement $element
     * @return string
     */
    protected function _getElementHtml(AbstractElement $element): string
    {
        $html = parent::_getElementHtml($element);
        $htmlId = $element->getHtmlId();
        $paymentHtmlId = str_replace('_active', '', $htmlId);
        $inheritHtmlId = $htmlId . '_inherit';
        $script = "
            <script>
                require(['jquery', 'domReady!'], function ($) {
                    $(document).ready(function () {
                        function updateCreditCardActiveAction() {
                            if (parseInt($('#{$htmlId}').val()) === " . Enabledisable::DISABLE_VALUE . ") {
                                ".$this->renderCreditCardScripts($paymentHtmlId)."
                            }
                        }
                        updateCreditCardActiveAction();
                        $('#{$htmlId}').on('change', function () {
                            updateCreditCardActiveAction();
                            $('#{$inheritHtmlId}').prop('checked', false );
                        });
                    });
                });
            </script>
        ";

        return $html . $script;
    }

    /**
     * Backend admin script on active toggle
     * 
     * @param string $paymentHtmlId
     * @return string
     */
    public function renderCreditCardScripts(string $paymentHtmlId): string
    {
        $creditCardTitle = CreditCardConfigurationManagementInterface::DEFAULT_XML_PATH_TITLE;
        $creditCardGatewayId = CreditCardConfigurationManagementInterface::DEFAULT_XML_PATH_GATEWAY_ID;
        $creditCardTypes = CreditCardConfigurationManagementInterface::DEFAULT_XML_PATH_CC_TYPES;
        $creditCardEnabledMagentoBackend = CreditCardConfigurationManagementInterface::DEFAULT_XML_PATH_BACKEND_ORDERS;
        $creditCardSortOrder = CreditCardConfigurationManagementInterface::DEFAULT_XML_PATH_SORT_ORDER;
        $creditCardPaymentAction = CreditCardConfigurationManagementInterface::DEFAULT_XML_PATH_PAYMENT_ACTION;
        $creditCardDirectCharge = CreditCardConfigurationManagementInterface::DEFAULT_XML_PATH_DIRECT_CHARGE;
        $creditCard3ds = CreditCardConfigurationManagementInterface::DEFAULT_XML_PATH_3DS;
        $creditCardAllowSpecific = CreditCardConfigurationManagementInterface::DEFAULT_XML_PATH_ALLOWSPECIFIC;
        $creditCardSaveCard = CreditCardConfigurationManagementInterface::DEFAULT_XML_PATH_SAVE_CARD;
        $creditCardCssSubmitButton = CreditCardConfigurationManagementInterface::DEFAULT_XML_PATH_CSS_SUBMIT;
        $creditCardCssLabel = str_replace("'", "\'", CreditCardConfigurationManagementInterface::DEFAULT_XML_PATH_CSS_LABEL);
        $creditCardCssInput = CreditCardConfigurationManagementInterface::DEFAULT_XML_PATH_CSS_INPUT;
        $scripts = "
            $('#{$paymentHtmlId} input[type=\"text\"]').val('');
            $('#{$paymentHtmlId} input[type=\"checkbox\"]').prop('checked', true );
            $('#{$paymentHtmlId}_gateway_id').val('{$creditCardGatewayId}').prop('disabled', true);
            $('#{$paymentHtmlId}_title').val('{$creditCardTitle}').prop('disabled', true);
            $('#{$paymentHtmlId}_cctypes').val('{$creditCardTypes}');
            $('#{$paymentHtmlId}_enabled_magento_backend').val('{$creditCardEnabledMagentoBackend}');
            $('#{$paymentHtmlId}_sort_order').val('{$creditCardSortOrder}').prop('disabled', true);
            $('#{$paymentHtmlId}_payment_action').val('{$creditCardPaymentAction}');
            $('#{$paymentHtmlId}_direct_charge').val('{$creditCardDirectCharge}');
            $('#{$paymentHtmlId}_3ds').val('{$creditCard3ds}');
            $('#{$paymentHtmlId}_allowspecific').val('{$creditCardAllowSpecific}');
            $('#row_{$paymentHtmlId}_specificcountry').hide();
            $('#{$paymentHtmlId}_specificcountry').val('');
            $('#{$paymentHtmlId}_save_card').val('{$creditCardSaveCard}');
            $('#{$paymentHtmlId}_css_submit_button').val('{$creditCardCssSubmitButton}');
            $('#{$paymentHtmlId}_css_label').val('{$creditCardCssLabel}');
            $('#{$paymentHtmlId}_css_input').val('{$creditCardCssInput}');"
        ;
        return $scripts;
    }
}
