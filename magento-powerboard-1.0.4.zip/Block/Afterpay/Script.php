<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Block\Afterpay;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Paydock\Powerboard\Api\AfterPayConfigurationManagementInterface;
use Paydock\Powerboard\Api\ConfigurationManagementInterface;
use Paydock\Powerboard\Model\Config\Source\Environment;

class Script extends Template
{
    /**
     * @var string
     */
    protected $_template = 'Paydock_Powerboard::afterpay-script.phtml';

    /**
     * @var ConfigurationManagementInterface
     */
    private ConfigurationManagementInterface $configurationManagement;

    /**
     * @var AfterPayConfigurationManagementInterface
     */
    private AfterPayConfigurationManagementInterface $afterPayConfigurationManagement;

    /**
     * @param ConfigurationManagementInterface $configurationManagement
     * @param AfterPayConfigurationManagementInterface $afterPayConfigurationManagement
     * @param Context $context
     * @param array $data
     */
    public function __construct(
        ConfigurationManagementInterface $configurationManagement,
        AfterPayConfigurationManagementInterface $afterPayConfigurationManagement,
        Template\Context $context,
        array $data = []
    ) {
        $this->configurationManagement = $configurationManagement;
        $this->afterPayConfigurationManagement = $afterPayConfigurationManagement;
        parent::__construct($context, $data);
    }

    /**
     * @return bool
     */
    public function isEnabled(): bool
    {
        return $this->afterPayConfigurationManagement->isActive() && 
            $this->afterPayConfigurationManagement->getMpid();
    }

    /**
     * @return bool
     */
    public function isProduction(): bool
    {
        return $this->configurationManagement->getEnvironment() === Environment::PRODUCTION;
    }
}

