<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Observer\CreditCard;

use Magento\Framework\Event\Observer;
use Magento\Payment\Observer\AbstractDataAssignObserver;
use Magento\Quote\Api\Data\PaymentInterface;

class AssignAdditionalData extends AbstractDataAssignObserver
{
    /**
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer): void
    {
        $data = $this->readDataArgument($observer);
        $additionalData = $data->getData(PaymentInterface::KEY_ADDITIONAL_DATA);
        $paymentInfo = $this->readPaymentModelArgument($observer);

        if (array_key_exists('payment_token', $additionalData)) {
            $paymentInfo->setAdditionalInformation('payment_token', $additionalData['payment_token']);
        }

        if (array_key_exists('cc_save', $additionalData)) {
            $paymentInfo->setAdditionalInformation('cc_save', (bool)$additionalData['cc_save']);
        }

        if (array_key_exists('payment_source_id', $additionalData)) {
            $paymentInfo->setAdditionalInformation('payment_source_id', $additionalData['payment_source_id']);
        }

        if (array_key_exists('charge_3ds_id', $additionalData)) {
            $paymentInfo->setAdditionalInformation('charge_3ds_id', $additionalData['charge_3ds_id']);
        }
    }
}

