/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @api
 */
define(
    [
        'mage/storage',
        'Magento_Checkout/js/model/error-processor',
        'Magento_Checkout/js/model/full-screen-loader',
        'Magento_Customer/js/customer-data',
        'Magento_Checkout/js/model/payment/place-order-hooks',
        'jquery',
        'Magento_Checkout/js/model/payment/method-list',
        'Magento_Checkout/js/checkout-data'
    ],
    function (storage, errorProcessor, fullScreenLoader, customerData, hooks, $, paymentMethodList, checkoutData) {
        'use strict';

        return function (serviceUrl, payload, messageContainer) {
            var headers = {}, redirectURL = '';

            fullScreenLoader.startLoader();
            _.each(hooks.requestModifiers, function (modifier) {
                modifier(headers, payload);
            });

            return storage.post(
                serviceUrl, JSON.stringify(payload), true, 'application/json', headers
            ).fail(
                function (response) {             
                    errorProcessor.process(response, messageContainer);

                    redirectURL = response.getResponseHeader('errorRedirectAction');

                    var selectedCheckoutPaymentMethod = checkoutData.getSelectedPaymentMethod()
                   
                    if (selectedCheckoutPaymentMethod === "paydock_cc"){
                        var paymentMethods = paymentMethodList();

                        _.each(paymentMethods, function (paymentMethod) {
                            if (paymentMethod.method === selectedCheckoutPaymentMethod) {
                                redirectURL = null;
                                $('#paydock_cc-payment_source_id').val('')
                                $('#paydock_cc-token').val('');
                                $('#paydock_widget').show();
                                $('#paydock_3ds_widget').empty();
                            }
                        });
                    }
                    
                    if (redirectURL) {
                        console.log("redirecting")
                        setTimeout(function () {
                            errorProcessor.redirectTo(redirectURL);
                        }, 3000);
                    }
                }
            ).done(
                function (response) {
                    var clearData = {
                        'selectedShippingAddress': null,
                        'shippingAddressFromData': null,
                        'newCustomerShippingAddress': null,
                        'selectedShippingRate': null,
                        'selectedPaymentMethod': null,
                        'selectedBillingAddress': null,
                        'billingAddressFromData': null,
                        'newCustomerBillingAddress': null
                    };

                    if (response.responseType !== 'error') {
                        customerData.set('checkout-data', clearData);
                    }
                }
            ).always(
                function () {
                    fullScreenLoader.stopLoader();
                    _.each(hooks.afterRequestListeners, function (listener) {
                        listener();
                    });
                }
            );
        };
    }
);
