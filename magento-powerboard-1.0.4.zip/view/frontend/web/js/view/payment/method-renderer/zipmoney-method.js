define(
    [
        'Magento_Checkout/js/view/payment/default',
        'jquery',
        'Magento_Checkout/js/model/quote',
        'https://widget.powerboard.commbank.com.au/sdk/v1.94.22/widget.umd.js',
        'Magento_Checkout/js/checkout-data',
        'Magento_Checkout/js/action/select-payment-method'
    ],
    function (Component, $, quote, cba, checkoutData, selectPaymentMethodAction) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'Paydock_Powerboard/payment/zipmoney-form'
            },
            button: null,

            /**
             * {@inheritdoc}
             */
            initialize: function() {
                this._super();

                $('body').on('afterGetPaymentInformation',  function() {
                    window.location.reload();
                });
            },

            /**
             * Load the zip button
             */
             loadZipMoneyButton: function() {
                let gatewayId = window.checkoutConfig.payment.paydockZipMoney.gatewayId,
                    publicKey = window.checkoutConfig.payment.paydockCreditCard.publicKey,
                    self = this;

                if (typeof publicKey === 'undefined' || publicKey.trim() === '') {
                    console.error('Error loading widget - no public key defined');
                    return;
                }
                    
                let shippingAddress = quote.shippingAddress(),
                    billingAddress = quote.billingAddress(),
                    currency = window.checkoutConfig.quoteData.base_currency_code;

                    this.button = new cba.ZipmoneyCheckoutButton('#zipmoney-checkout-button', publicKey, gatewayId);
                    this.button.setEnv(this.getEnvironment());
                    this.button.onFinishInsert('input[id="zipmoney-checkout-button-payment-source-token"]', 'payment_source_token');
                    this.button.setMeta({
                        'first_name': shippingAddress.firstname,
                        'tokenize': true,
                        'last_name': shippingAddress.lastname,
                        'email': quote.guestEmail ?? window.checkoutConfig.quoteData.customer_email,
                        'gender': '',
                        'charge': {
                            'amount': quote.totals()['base_grand_total'],
                            'currency': currency,
                            'shipping_type': 'delivery',
                            'shipping_address': {
                                'first_name': shippingAddress.firstname,
                                'last_name': shippingAddress.lastname,
                                'line1': shippingAddress.street[0] ?? '',
                                'line2': shippingAddress.street[1] ?? '',
                                'country': shippingAddress.countryId,
                                'postcode': shippingAddress.postcode,
                                'city': shippingAddress.city,
                                'state': shippingAddress.region
                            },
                            'billing_address': {
                                'first_name': billingAddress.firstname,
                                'last_name': billingAddress.lastname,
                                'line1': billingAddress.street[0] ?? '',
                                'line2': billingAddress.street[1] ?? '',
                                'country': billingAddress.countryId,
                                'postcode': billingAddress.postcode,
                                'city': billingAddress.city,
                                'state': billingAddress.region
                            },
                            'items': self.getCartItems()
                        },
                        'statistics': {
                            'account_created': '',
                            'sales_total_number': '',
                            'sales_total_amount': '',
                            'sales_avg_value': '',
                            'sales_max_value': '',
                            'refunds_total_amount': '',
                            'previous_chargeback': '',
                            'currency': currency,
                            'last_login': ''
                        }
                    });

                    this.button.on('finish', function(data) {
                        self.paydockPlaceOrder();
                    });
                    
                return;
            },

            /**
             * Set meta data
             * @param {*} metaData
             */
            setMeta: function(metaData) {
                this.button.setMeta(metaData);
            },

            /**
             * @returns {*}
             */
            getCartItems: function() {
                let quoteItems = quote.getItems(),
                    cartItems = [];

                for (let i = 0; i < quoteItems.length; i++) {
                    cartItems.push(
                        {
                            'name': quoteItems[i]['name'],
                            'amount': quoteItems[i]['row_total'],
                            'quantity': quoteItems[i]['qty'],
                            'reference': quoteItems[i]['description']
                        }
                    )
                }

                return cartItems;
            },

            /**
             * @returns {String}
             */
            getCode: function() {
                return this.item.method;
            },

            /**
             * @returns {String}
             */
            getEnvironment: function() {
                return window.checkoutConfig.payment.paydockCreditCard.environment ?? 'production_cba';
            },

            /**
             * @returns {String}
             */
            getLogoSrc: function() {
                return window.checkoutConfig.payment.paydockZipMoney.logoSrc ?? '';
            },

            /**
             * @return {Boolean}
             */
            selectPaymentMethod: function () {
                selectPaymentMethodAction(this.getData());
                checkoutData.setSelectedPaymentMethod(this.item.method);

                let totals = quote.getTotals()();

                if (totals) {
                    if (totals['coupon_code']) {
                        this.setMeta(
                            {
                                'charge': {
                                    'amount': quote.totals()['base_grand_total'],
                                    'currency': window.checkoutConfig.quoteData.base_currency_code
                                }
                            }
                        );
                    }
                }

                return true;
            },

            /**
             * Place ZipMoney order
             */
            paydockPlaceOrder: function() {
                $('#paydock-zipmoney-place-token-order').click();
                return;
            },

            /**
             * @returns {Object}
             */
            getData: function() {
                return {
                    'method': this.item.method,
                    'additional_data': {
                        'payment_token': $('input[id="zipmoney-checkout-button-payment-source-token"]').val()
                    }
                };
            }
        });
    }
);

