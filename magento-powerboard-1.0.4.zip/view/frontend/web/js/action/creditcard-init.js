define([
    'jquery',
    'https://widget.powerboard.commbank.com.au/sdk/v1.94.22/widget.umd.js',
    'Paydock_Powerboard/js/model/creditcard',
    'Paydock_Powerboard/js/action/creditcard-placeorder',
    'Paydock_Powerboard/js/action/place-3ds-order',
    'Paydock_Powerboard/js/action/paymentsources',
    'Magento_Customer/js/model/customer',
    'Magento_Customer/js/customer-data',
    'Magento_Checkout/js/model/payment/place-order-hooks',
    'Paydock_Powerboard/js/action/creditcard-widget'
], function ($, paydock, creditCardModel, creditCardPlaceOrder, place3dsOrderAction, loadPaymentSources, customer, customerData, placeOrderHooks, creditCardWidget) {

    var addPlaceOrderHook = function (widget, showCustomerLoggedInPaymentSourceElements) {
        placeOrderHooks.afterRequestListeners.push(function() {
            showCustomerLoggedInPaymentSourceElements(false);
            widget.reload();
        });
    };

    return function (showCustomerLoggedInPaymentSourceElements) {
        let self = this,
            publicKey = creditCardModel.getPublicKey();

        this.customer = customerData.get('customer');
        customerData.reload(['customer']);

        if (typeof publicKey === 'undefined' || publicKey.trim() === '') {
            console.error('Error loading widget - no public key defined');
            return;
        }

        let customerIsLoggedIn = customer.isLoggedIn();
        if (customerIsLoggedIn){
            let paydockCustomerId = self.customer().paydock_customer_id;
            if (typeof customer.customerData.extension_attributes !== 'undefined') {
                paydockCustomerId = customer.customerData.extension_attributes.paydock_customer_id;
            }
            if (paydockCustomerId) {
                loadPaymentSources(publicKey, paydockCustomerId, showCustomerLoggedInPaymentSourceElements);
            }
        }

        let widget = new paydock.HtmlWidget('#paydock_widget', publicKey, "not_configured", "card", "card_payment_source_with_cvv");
        creditCardWidget.initStyles(widget);

        widget.onFinishInsert('#paydock_cc-token', 'payment_source');

        if (creditCardModel.is3ds()) {
            widget.on('finish', function(data) {
                let paymentToken = $('#paydock_cc-token').val();

                $('#paydock_cc-payment_source_id').val('');
                place3dsOrderAction(paymentToken);
            });
        } else {
            widget.on('finish', function(data) {
                $('#paydock_cc-payment_source_id').val('');
                creditCardPlaceOrder();
            });
        }
        widget.setEnv(creditCardModel.getEnvironment());
        widget.load();

        addPlaceOrderHook(widget, showCustomerLoggedInPaymentSourceElements);
    };
});
