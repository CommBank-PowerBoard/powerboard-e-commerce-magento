define(
    [
        'jquery',
        'Paydock_Powerboard/js/model/error-handler',
        'https://widget.powerboard.commbank.com.au/sdk/v1.94.22/widget.umd.js',
        'Magento_Checkout/js/model/full-screen-loader',
        'Magento_Checkout/js/model/url-builder',
        'mage/storage',
        'Paydock_Powerboard/js/model/creditcard',
        'Magento_Checkout/js/model/payment/place-order-hooks',
        'mage/accordion'
    ],
    function ($, errorHandler, paydock, fullScreenLoader, urlBuilder, storage, creditCardModel, placeOrderHooks, accordion) {
        'use strict';

        return function (publicKey, paydockCustomerId, showCustomerLoggedInPaymentSourceElements) {

            var addPlaceOrderHook = function (widget) {
                placeOrderHooks.afterRequestListeners.push(function () {
                    showCustomerLoggedInPaymentSourceElements(false);
                    widget.reload();
                });
            };

            let serviceUrl;
    
            serviceUrl = urlBuilder.createUrl(
                '/paydock/customer/:paydockCustomerId/payment-source',
                {
                    paydockCustomerId: paydockCustomerId
                }
            );

            fullScreenLoader.startLoader();

            return storage.get(
                serviceUrl,
                false
            ).done(
                function (response) {
                    let environment = creditCardModel.getEnvironment(),
                        result = JSON.parse(response),
                        queryToken = result.query_token,
                        paymentSources = result.data[0].payment_sources;
                    if (queryToken && queryToken !== 'null' && queryToken !== 'undefined' && paymentSources.length > 0) {
                        var widget = new paydock.HtmlPaymentSourceWidget('#paydock_payment_source_widget', publicKey, queryToken);
                        widget.onSelectInsert('#paydock_cc-payment_source_id', 'payment_source_id');
                        widget.onSelectInsert('#paydock_cc-token', getVaultTokenById('payment_source_id'), paymentSources);
                        widget.setEnv(environment);
                        widget.filterByTypes(['card']);
                        widget.load();
                        addPlaceOrderHook(widget);
                        widget.on('afterLoad', function (data) {
                            showCustomerLoggedInPaymentSourceElements(true);
                        });
                        widget.on('select', function (data) {
                            $('#paydock_cc-payment_source_id').val(data.payment_source_id);
                            $('#paydock_cc-token').val(getVaultTokenById(data.payment_source_id, paymentSources));
                        });
                        widget.on('unselect', function (data) {
                            $('#paydock_cc-payment_source_id').val('');
                            $('#paydock_cc-token').val('');
                        });
                    } else{
                        if (creditCardModel.canSaveCard()) {
                            $("#paydock_cc-payment-method-content-wrapper").accordion("destroy");
                        }
                        $(".payment-accordian-content").show();
                        showCustomerLoggedInPaymentSourceElements(false);
                    }
                }
            ).fail(
                function (response) {
                    errorHandler.process(response);
                }
            ).always(
                function (response) {
                    fullScreenLoader.stopLoader();
                }
            );

            function getVaultTokenById(payment_source_id, paymentSources) {
                for (const key in paymentSources) {
                    if (paymentSources.hasOwnProperty(key)) {
                        if (paymentSources[key]._id === payment_source_id) {
                            return paymentSources[key].vault_token;
                        }
                    }
                }
                return '';
            }
        };
    });

