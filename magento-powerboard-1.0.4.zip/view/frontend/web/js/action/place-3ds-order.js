/**
 * @api
 */
 define([
    'underscore',
    'uiRegistry',
    'jquery',
    'Paydock_Powerboard/js/model/creditcard',
    'Paydock_Powerboard/js/action/creditcard-widget',
    'Paydock_Powerboard/js/model/error-handler',
    'Magento_Checkout/js/model/url-builder',
    'mage/storage',
    'Magento_Checkout/js/model/full-screen-loader',
    'Magento_Checkout/js/model/payment/place-order-hooks',
    'Magento_Checkout/js/model/quote',
    'Magento_Customer/js/model/customer',
    'https://widget.powerboard.commbank.com.au/sdk/v1.94.22/widget.umd.js',
    'Paydock_Powerboard/js/action/creditcard-placeorder',
    'Paydock_Powerboard/js/action/place-3ds-order'
], function (_, registry, $, creditCardModel, creditCardWidget, errorHandler, urlBuilder, storage, fullScreenLoader, hooks, quote, customer, paydock, creditCardPlaceOrder, place3dsOrderAction) {
    'use strict';

    /**
     * @param {String} token
     * @param {String} environment
     */
    var place3dsOrder = function (token, isExistingPaymentSource) {
        let serviceUrl, payload, browserName, browserDetails, userAgent;

        userAgent = navigator.userAgent;

        /**
         * Paydock doesn't seem to like the entire value return by navigator.userAgent
         * For example it only works with Firefox but not Chrome and Safari
         */
        if (userAgent.includes('Chrome')) {
            browserName = 'Chrome';
        } else if (userAgent.includes('Safari')) {
            browserName = 'Safari';
        } else if (userAgent.includes('Mozilla')) {
            browserName = 'Mozilla';
        } else if (userAgent.includes('Internet')) {
            browserName = 'Internet Explorer';
        } else {
            browserName = userAgent;
        }

        browserDetails = {
            'name': browserName,
            'java_enabled': 'true', // @deprecated String(navigator.javaEnabled())
            'language': navigator.language,
            'screen_height' : String(screen.height),
            'screen_width' : String(screen.width),
            'time_zone' : String(new Date().getTimezoneOffset()),
            'color_depth' : String(screen.colorDepth)
        };

        if (customer.isLoggedIn()) {
            payload = {
                'browser_details': browserDetails,
                'existing_payment_source': isExistingPaymentSource,
                'cc_save': creditCardModel.canSaveCard() && $('#paydock_cc-save').is(':checked')
            }

            serviceUrl = urlBuilder.createUrl(
                '/mine/paydock/3ds/token/:paymentToken/:cartId/pre-auth',
                {
                    paymentToken: token,
                    cartId: quote.getQuoteId()
                }
            );
        } else {
            payload = {
                'browser_details': browserDetails
            }

            serviceUrl = urlBuilder.createUrl(
                '/guest-carts/paydock/3ds/token/:paymentToken/:cartId/pre-auth',
                {
                    paymentToken: token,
                    cartId: quote.getQuoteId()
                }
            );
        }

        fullScreenLoader.startLoader();

        return storage.post(
            serviceUrl, JSON.stringify(payload)
        ).done(
            function (response) {
                let securityToken = response;

                if (typeof securityToken === 'string') {
                    let widget = new paydock.Canvas3ds('#paydock_3ds_widget', securityToken);

                    $('#paydock_widget').hide();
                    $('#paydock_cc_save_field').hide();
                    $(".payment-accordian-content.three-d-s").show();
                    $(".payment-accordian-content.existing-payment-source-form").hide();
                    $(".payment-accordian-content.three-d-s .actions-toolbar").hide();
                    widget.show();

                    widget.setEnv(creditCardModel.getEnvironment());
                    widget.on('chargeAuthSuccess', function (data) {
                        $('#paydock_cc-charge_3ds_id').val(data.charge_3ds_id);
                        $('#paydock-creditcard-place-token-order').click();
                    });
                    widget.on('chargeAuthReject', function (data) {
                        $('#paydock_widget').empty();
                        $('#paydock_3ds_widget').empty();

                        errorHandler.process('Your payment failed, please try again');

                        let publicKey = creditCardModel.getPublicKey(),
                            ccWidget = new paydock.HtmlWidget('#paydock_widget', publicKey, "not_configured", "card", "card_payment_source_with_cvv"),
                            showCustomerLoggedInElements = $("input[name='customer-loggedin-payment-source-elements']").val();

                        creditCardWidget.initStyles(ccWidget);

                        ccWidget.onFinishInsert('#paydock_cc-token', 'payment_source');

                        ccWidget.on('finish', function(data) {
                            let paymentToken = $('#paydock_cc-token').val();

                            $('#paydock_cc-payment_source_id').val('');
                            place3dsOrder(paymentToken);
                        });
                        ccWidget.setEnv(creditCardModel.getEnvironment());
                        ccWidget.load();

                        $('#paydock_widget').show();

                        if (customer.isLoggedIn() && showCustomerLoggedInElements) {
                            $('#paydock_cc_save_field').show();
                        }
                        if (showCustomerLoggedInElements === 'true') {
                            $(".payment-accordian-content.three-d-s .actions-toolbar").show();
                        }
                    });

                    widget.load();
                } else {
                    errorHandler.process('Error processing request, please try again');
                }
            }
        ).fail(
            function (response) {
                let messageContainer = registry.get('checkout.steps.billing-step.payment.payments-list.paydock_cc.checkout.steps.billing-step.payment.payments-list.paydock_cc.messages').messageContainer;
                errorHandler.process(response, messageContainer);
            }
        ).always(
            function (response) {
                fullScreenLoader.stopLoader();
                _.each(hooks.afterRequestListeners, function (listener) {
                    listener();
                });
            }
        );
    };

    return function (token, isExistingPaymentSource = false) {
        place3dsOrder(token, isExistingPaymentSource);
    };
});
