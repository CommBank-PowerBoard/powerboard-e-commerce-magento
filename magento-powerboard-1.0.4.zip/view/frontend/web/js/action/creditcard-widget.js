define([
    'Paydock_Powerboard/js/model/creditcard'
], function(creditCardModel) {
    'use strict';

    return {

        initStyles: function(widget) {
            widget.setFormLabels({card_name: 'Card Holder Name'});
            widget.setFormLabels({card_number: 'Card Holder Number'});
            widget.setFormFields(['card_name*', 'card_number*', 'card_ccv*']);
            widget.setFormPlaceholders({
                card_name: '',
                card_number: ''
            });
    
            widget.setStyles(creditCardModel.getCss());
            widget.setElementStyle('submit_button', creditCardModel.getButtonCss());
            widget.setElementStyle('label', creditCardModel.getLabelCss());
            widget.setElementStyle('input', creditCardModel.getInputCss());
            widget.setTexts({submit_button: 'Place Order'});
            widget.useAutoResize();
        },  

    };
});
