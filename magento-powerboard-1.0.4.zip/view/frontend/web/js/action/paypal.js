define([
    'jquery',
    'Paydock_Powerboard/js/model/error-handler',
    'Magento_Checkout/js/model/url-builder',
    'mage/storage',
    'Magento_Checkout/js/model/full-screen-loader',
    'Magento_Checkout/js/model/quote',
    'https://widget.powerboard.commbank.com.au/sdk/v1.94.22/widget.umd.js'
], function ($, errorHandler, urlBuilder, storage, fullScreenLoader, quote, paydock) {
    'use strict';

    var placeOrder = function (responseId) {
        if (responseId) {
            $('input[id="paypal-response-id"]').val(responseId);
            $('#paydock-paypal-place-token-order').click();
        } else {
            errorHandler.process('Error processing request, please try again');
        }
    }

    return function () {
        let serviceUrl;

        serviceUrl = urlBuilder.createUrl(
            '/paydock/wallet/token/:cartId',
            {cartId:  quote.getQuoteId()}
        );

        fullScreenLoader.startLoader();

        return storage.get(
            serviceUrl,
            false
        ).done(
            function (response) {
                let result = JSON.parse(response),
                    environment = window.checkoutConfig.payment.paydockPaypal.environment ?? 'production_cba';

                if (result.success) {
                    let button = new paydock.WalletButtons('#paydock_paypal_widget', result.token_wallet, {
                        amount_label: 'Payment Amount',
                        country: 'AU',
                        request_shipping: true,
                        pay_later: window.checkoutConfig.payment.paydockPaypal.pay_later ?? false,
                        style: {
                            layout: window.checkoutConfig.payment.paydockPaypal.style_layout ?? 'horizontal',
                            color: window.checkoutConfig.payment.paydockPaypal.style_color ?? 'gold',
                            shape: window.checkoutConfig.payment.paydockPaypal.style_shape ?? 'rect',
                            tagline: window.checkoutConfig.payment.paydockPaypal.style_layout != 'vertical' && window.checkoutConfig.payment.paydockPaypal.style_tagline
                                ? window.checkoutConfig.payment.paydockPaypal.style_tagline
                                : false,
                            label: window.checkoutConfig.payment.paydockPaypal.style_label ?? '',
                        },
                    });

                    button.setEnv(environment);
                    button.onUnavailable(() => console.error('No wallet buttons available'));
                    
                    button.onPaymentSuccessful((response) => {
                        placeOrder(response.data.id);
                    });
                    
                    button.onUpdate((data) => {
                        setTimeout(function () {
                            button.update({ success: true, body: {} });
                        }, 3000);
                    });
                    button.load();
                } else {
                  errorHandler.process(result.error);
                }
            }
        ).fail(
            function (response) {
                errorHandler.process(response);
            }
        ).always(
            function (response) {
                fullScreenLoader.stopLoader();
            }
        );
    };
});

