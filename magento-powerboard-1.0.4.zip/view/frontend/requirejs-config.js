var config = {
    map: {
        '*': {
            'Magento_Checkout/js/action/get-payment-information': 'Paydock_Powerboard/js/action/get-payment-information',
            'Magento_Checkout/js/model/place-order': 'Paydock_Powerboard/js/view/checkout/place-order'
        }
    }
};
