var config = {
    config: {
        mixins: {
            'mage/validation': {
                'Paydock_Powerboard/js/admin-config/validator-rules-mixin': true
            }
        }
    }
};