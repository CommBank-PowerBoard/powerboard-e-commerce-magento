<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Plugin;

use Magento\Customer\CustomerData\Customer;
use Magento\Customer\Helper\Session\CurrentCustomer;

class CustomerDataPlugin
{
    /**
     * @var CurrentCustomer
     */
    private CurrentCustomer $currentCustomer;

    /**
     * @param CurrentCustomer $currentCustomer
     */
    public function __construct(
        CurrentCustomer $currentCustomer
    ) {
        $this->currentCustomer = $currentCustomer;
    }

    /**
     * @param Customer $subject
     * @param array $result
     * @return array
     */
    public function afterGetSectionData(Customer $subject, array $result): array
    {
        if (empty($result)) {
            return $result;
        }

        $currentCustomer = $this->currentCustomer->getCustomer();

        $result['customer_id'] = $currentCustomer->getId();

        $paydockCustomerId = $currentCustomer->getCustomAttribute('paydock_customer_id');
        $paydockCustomerIdValue = $paydockCustomerId ? $paydockCustomerId->getValue() : '';
        $result['paydock_customer_id'] = $paydockCustomerIdValue;

        return $result;
    }
}
