<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model\Config;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Payment\Helper\Data as PaymentHelper;
use Magento\Payment\Model\MethodInterface;
use Paydock\Powerboard\Api\ConfigurationManagementInterface;
use Paydock\Powerboard\Api\Data\PaydockPaypalInterface;
use Paydock\Powerboard\Api\PaypalConfigurationManagementInterface;
use Magento\Framework\View\Asset\Repository;
use Magento\Framework\View\Asset\Source;
use Magento\Payment\Model\CcConfig;

class PaypalConfigProvider implements ConfigProviderInterface
{
    /**
     * @var string
     */
    protected string $methodCode = PaydockPaypalInterface::METHOD_CODE;

    /**
     * @var MethodInterface
     */
    protected MethodInterface $method;

    /**
     * @var ConfigurationManagementInterface
     */
    private ConfigurationManagementInterface $configurationManagement;

    /**
     * @var PaypalConfigurationManagementInterface
     */
    private PaypalConfigurationManagementInterface $paypalConfigurationManagement;

    /**
     * @var Repository
     */
    private Repository $assetRepo;

    /**
     * @var Source
     */
    private Source $assetSource;

    /**
     * @var CcConfig
     */
    private CcConfig $ccConfig;

    /**
     * @param PaymentHelper $paymentHelper
     * @param ConfigurationManagementInterface $configurationManagement
     * @param PaypalConfigurationManagementInterface $paypalConfigurationManagement
     * @param Repository $assetRepo
     * @param Source $assetSource
     * @param CcConfig $ccConfig
     * @throws LocalizedException
     */
    public function __construct(
        PaymentHelper $paymentHelper,
        ConfigurationManagementInterface $configurationManagement,
        PaypalConfigurationManagementInterface $paypalConfigurationManagement,
        Repository $assetRepo,
        Source $assetSource,
        CcConfig $ccConfig
    ) {
        $this->method = $paymentHelper->getMethodInstance($this->methodCode);
        $this->configurationManagement = $configurationManagement;
        $this->paypalConfigurationManagement = $paypalConfigurationManagement;
        $this->assetRepo = $assetRepo;
        $this->assetSource = $assetSource;
        $this->ccConfig = $ccConfig;
    }

    /**
     * @inheritDoc
     */
    public function getConfig(): array
    {
        return [
            'payment' => [
                'paydockPaypal' => [
                    'active' => $this->paypalConfigurationManagement->isActive(),
                    'environment' => $this->configurationManagement->getEnvironment(),
                    'methodCode' => $this->methodCode,
                    'title' => $this->paypalConfigurationManagement->getTitle(),
                    'gateway_id' => $this->paypalConfigurationManagement->getGatewayId(),
                    'pay_later' => $this->paypalConfigurationManagement->isPayLater(),
                    'style_color' => $this->paypalConfigurationManagement->getStyleColor(),
                    'style_layout' => $this->paypalConfigurationManagement->getStyleLayout(),
                    'style_shape' => $this->paypalConfigurationManagement->getStyleShape(),
                    'style_tagline' => $this->paypalConfigurationManagement->isStyleTagline(),
                    'style_label' => $this->paypalConfigurationManagement->getStyleLabel(),
                    'logoSrc' => $this->getLogoSrc()
                ]
            ]
        ];
    }

    /**
     * @return string
     */
    public function getLogoSrc(): string
    {
        $src = '';
        $asset = $this->ccConfig->createAsset('Paydock_Powerboard::images/paypal.png');
        if ($asset) {
            $placeholder = $this->assetSource->findSource($asset);
            if ($placeholder) {
                $src = $asset->getUrl();
            }
        }
        return $src;
    }
}


