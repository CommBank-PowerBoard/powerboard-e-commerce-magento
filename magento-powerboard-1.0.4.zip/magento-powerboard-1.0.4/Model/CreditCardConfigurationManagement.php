<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Paydock\Powerboard\Api\CreditCardConfigurationManagementInterface;
use Paydock\Powerboard\Api\ConfigurationManagementInterface;

class CreditCardConfigurationManagement implements CreditCardConfigurationManagementInterface
{
    /**
     * @var ScopeConfigInterface
     */
    private ScopeConfigInterface $scopeConfig;

    /**
     * @var ConfigurationManagementInterface
     */
    private ConfigurationManagementInterface $configurationManagement;

    /**
     * @param ScopeConfigInterface $scopeConfig
     * @param ConfigurationManagementInterface $configurationManagement
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        ConfigurationManagementInterface $configurationManagement
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->configurationManagement = $configurationManagement;
    }

    /**
     * @inheritDoc
     */
    public function isActive(): bool
    {
        return (bool)($this->scopeConfig->getValue(self::XML_PATH_ACTIVE, ScopeInterface::SCOPE_STORE)
            && $this->configurationManagement->isActive()
            && !empty($this->configurationManagement->getPublicKey())
            && !empty($this->configurationManagement->getSecretKey()));
    }

    /**
     * @inheritDoc
     */
    public function canSaveCard(): bool
    {
        return (bool)$this->scopeConfig->getValue(self::XML_PATH_SAVE_CARD, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @inheritDoc
     */
    public function is3DS(): bool
    {
        return (bool)$this->scopeConfig->getValue(self::XML_PATH_3DS, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @inheritDoc
     */
    public function isBackendOrder(): bool
    {
        return (bool)$this->scopeConfig->getValue(self::XML_PATH_BACKEND_ORDERS, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @inheritDoc
     */
    public function getGatewayId(): string
    {
        return (string)$this->scopeConfig->getValue(self::XML_PATH_GATEWAY_ID, ScopeInterface::SCOPE_STORE) ?? '';
    }

    /**
     * @inheritDoc
     */
    public function getCssInput(): string
    {
        return (string)$this->scopeConfig->getValue(self::XML_PATH_CSS_INPUT, ScopeInterface::SCOPE_STORE) ?? '';
    }

    /**
     * @inheritDoc
     */
    public function getCssLabel(): string
    {
        return (string)$this->scopeConfig->getValue(self::XML_PATH_CSS_LABEL, ScopeInterface::SCOPE_STORE) ?? '';
    }


    /**
     * @inheritDoc
     */
    public function getCssSubmitButton(): string
    {
        return (string)$this->scopeConfig->getValue(self::XML_PATH_CSS_SUBMIT, ScopeInterface::SCOPE_STORE) ?? '';
    }

    /**
     * @inheritDoc
     */
    public function getBackendCssInput(): string
    {
        return (string)$this->scopeConfig->getValue(self::XML_PATH_BACKEND_CSS_INPUT, ScopeInterface::SCOPE_STORE) ?? '';
    }

    /**
     * @inheritDoc
     */
    public function getBackendCssLabel(): string
    {
        return (string)$this->scopeConfig->getValue(self::XML_PATH_BACKEND_CSS_LABEL, ScopeInterface::SCOPE_STORE) ?? '';
    }

    /**
     * @inheritDoc
     */
    public function getAvailableCardTypes(): array
    {
        $ccTypes = $this->scopeConfig->getValue(self::XML_PATH_CC_TYPES, ScopeInterface::SCOPE_STORE);

        return !empty($ccTypes) ? explode(',', $ccTypes) : [];
    }

    /**
     * @inheritDoc
     */
    public function canDirectCharge(): bool
    {
        return (bool)$this->scopeConfig->getValue(self::XML_PATH_DIRECT_CHARGE, ScopeInterface::SCOPE_STORE);
    }
}

