<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use Paydock\Powerboard\Api\CustomersServiceInterface;
use Paydock\Powerboard\Api\Data\PaydockCustomerInterface;
use Paydock\Powerboard\Api\PaydockCustomerManagementInterface;
use Psr\Log\LoggerInterface;

class PaydockCustomerManagement implements PaydockCustomerManagementInterface
{
    /**
     * @var CustomerRepositoryInterface
     */
    private CustomerRepositoryInterface $customerRepository;
    
    /**
     * @var CustomersServiceInterface
     */
    private CustomersServiceInterface $customersService;

    /**
     * @var LoggerInterface
     */
    private LoggerInterface $logger;

    /**
     * @param CustomerRepositoryInterface $customerRepository
     * @param CustomersServiceInterface $customersService
     * @param LoggerInterface $logger
     */
    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        CustomersServiceInterface $customersService,
        LoggerInterface $logger
    ) {
        $this->customerRepository = $customerRepository;
        $this->customersService = $customersService;
        $this->logger = $logger;
    }
    
    /**
     * @inheritDoc
     */
    public function createPaydockCustomer(OrderPaymentInterface $payment, string $vaultToken): ?array
    {
        $order = $payment->getOrder();
        $newCustomer = false;
        try {
            $customerId = $order->getCustomerId();
            $customer = $this->customerRepository->getById($customerId);

            $attributePaydockCustomerId = $customer->getCustomAttribute(PaydockCustomerInterface::CUSTOMER_ID);
            if (!$attributePaydockCustomerId || !$attributePaydockCustomerId->getValue()) {
                $paydockCustomerId = $this->customersService->createCustomer($order, $vaultToken);
                $newCustomer = true;
            } else {
                $paydockCustomerId = $attributePaydockCustomerId->getValue();
            }

            $paydockCustomerId = $this->customersService->getCustomerIdById($paydockCustomerId);
            if (!$paydockCustomerId) {
                $paydockCustomerId = $this->customersService->createCustomer($order, $vaultToken);
                $newCustomer = true;
            }
            
            return [
                'new' => $newCustomer,
                'paydock_customer_id' => $paydockCustomerId
            ];
        } catch (NoSuchEntityException | LocalizedException $e) {
            $this->logger->critical(__("Unable to create Paydock customer: %s", $e->getMessage()));
            return null;
        }
    }
}

