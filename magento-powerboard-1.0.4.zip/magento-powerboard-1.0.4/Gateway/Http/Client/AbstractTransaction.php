<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway\Http\Client;

use Exception;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Event\ManagerInterface as EventManager;
use Magento\Framework\Exception\LocalizedException;
use Magento\Payment\Gateway\Http\ClientException;
use Magento\Payment\Gateway\Http\ClientInterface;
use Magento\Payment\Gateway\Http\TransferInterface;
use Magento\Payment\Model\Method\Logger;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use Paydock\Powerboard\Api\ChargesServiceInterface;
use Paydock\Powerboard\Api\CustomersServiceInterface;
use Paydock\Powerboard\Api\PaydockCustomerManagementInterface;
use Paydock\Powerboard\Api\PaymentManagementInterface;
use Paydock\Powerboard\Api\PaymentSourceServiceInterface;
use Paydock\Powerboard\Model\CreditCardConfigurationManagement;
use Psr\Log\LoggerInterface;

abstract class AbstractTransaction implements ClientInterface
{
    /**
     * @var LoggerInterface
     */
    protected LoggerInterface $logger;

    /**
     * @var Logger
     */
    protected Logger $customLogger;

    /**
     * @var CreditCardConfigurationManagement
     */
    protected CreditCardConfigurationManagement $creditCardConfigurationManagement;

    /**
     * @var ChargesServiceInterface
     */
    protected ChargesServiceInterface $chargesService;

    /**
     * @var CustomersServiceInterface
     */
    protected CustomersServiceInterface $customersService;

    /**
     * @var CustomerRepositoryInterface
     */
    protected CustomerRepositoryInterface $customerRepository;

    /**
     * @var PaymentSourceServiceInterface
     */
    protected PaymentSourceServiceInterface $paymentSourceService;

    /**
     * @var EventManager
     */
    protected EventManager $eventManager;

    /**
     * @var PaymentManagementInterface
     */
    protected PaymentManagementInterface $paymentManagement;

    /**
     * @var PaydockCustomerManagementInterface
     */
    protected PaydockCustomerManagementInterface $paydockCustomerManagement;

    /**
     * @param LoggerInterface $logger
     * @param Logger $customLogger
     * @param CreditCardConfigurationManagement $creditCardConfigurationManagement
     * @param ChargesServiceInterface $chargesService
     * @param CustomersServiceInterface $customersService
     * @param PaymentSourceServiceInterface $paymentSourceService
     * @param CustomerRepositoryInterface $customerRepository
     * @param EventManager $eventManager
     * @param PaymentManagementInterface $paymentManagement
     * @param PaydockCustomerManagementInterface $paydockCustomerManagement
     */
    public function __construct(
        LoggerInterface $logger,
        Logger $customLogger,
        CreditCardConfigurationManagement $creditCardConfigurationManagement,
        ChargesServiceInterface $chargesService,
        CustomersServiceInterface $customersService,
        PaymentSourceServiceInterface $paymentSourceService,
        CustomerRepositoryInterface $customerRepository,
        EventManager $eventManager,
        PaymentManagementInterface $paymentManagement,
        PaydockCustomerManagementInterface $paydockCustomerManagement
    ) {
        $this->logger = $logger;
        $this->customLogger = $customLogger;
        $this->creditCardConfigurationManagement = $creditCardConfigurationManagement;
        $this->chargesService = $chargesService;
        $this->customersService = $customersService;
        $this->paymentSourceService = $paymentSourceService;
        $this->customerRepository = $customerRepository;
        $this->eventManager = $eventManager;
        $this->paymentManagement = $paymentManagement;
        $this->paydockCustomerManagement = $paydockCustomerManagement;
    }

    /**
     * @inheritdoc
     */
    public function placeRequest(TransferInterface $transferObject): array
    {
        $data = $transferObject->getBody();
        $log = [
            'request' => $data,
            'client' => static::class
        ];
        $response['response'] = [];

        try {
            $response['response'] = $this->process($data);
        } catch (Exception $e) {
            $message = __($e->getMessage() ?: 'Sorry, but something went wrong');
            $this->logger->critical($message);
            throw new ClientException($message);
        } finally {
            $log['response'] = $response['response'];
            $this->customLogger->debug($log);
        }

        return $response;
    }

    /**
     * @param OrderPaymentInterface $payment
     * @param string $vaultToken
     * @return void
     * @throws LocalizedException
     */
    protected function savePaymentSource(OrderPaymentInterface $payment, string $vaultToken): void
    {
        $paydockCustomer = $this->paydockCustomerManagement->createPaydockCustomer($payment, $vaultToken);
        if (!$paydockCustomer) {
            throw new LocalizedException(__('Error creating Paydock customer'));
        }

        $paydockCustomerId = $paydockCustomer['paydock_customer_id'];
        $newCustomer = $paydockCustomer['new'];
        if ($paydockCustomerId && !$newCustomer) {
            $this->customersService->saveVaultTokenToCustomerPaymentSource($paydockCustomerId, $vaultToken);
        }
    }

    /**
     * Process http request
     *
     * @param array $data
     */
    abstract protected function process(array $data): array;
}

