<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway;

use Magento\Framework\Exception\LocalizedException;
use Paydock\Powerboard\Api\PaymentSourceServiceInterface;

class PaymentSourceService implements PaymentSourceServiceInterface
{
    /**
     * @var GatewayService
     */
    private GatewayService $gatewayService;

    /**
     * @param GatewayService $gatewayService
     */
    public function __construct(GatewayService $gatewayService)
    {
        $this->gatewayService = $gatewayService;
    }

    /**
     * @inheritDoc
     * @throws LocalizedException
     */
    public function getSessionToken(string $paymentToken): ?string
    {
        $payload = [
            'token' => $paymentToken,
            'vault_type' => 'session'
        ];

        $response = $this->gatewayService->post(self::ENDPOINT_PAYMENT_SOURCES, $payload);
        return $this->getTokenFromResponse($response);
    }

    /**
     * @inheritDoc
     * @throws LocalizedException
     */
    public function getPermanentToken(string $paymentToken): ?string
    {
        $payload = [
            'token' => $paymentToken
        ];

        $response = $this->gatewayService->post(self::ENDPOINT_PAYMENT_SOURCES, $payload);
        return $this->getTokenFromResponse($response);
    }

    /**
     * @param array|null $response
     * @return string
     * @throws LocalizedException
     */
    private function getTokenFromResponse(?array $response): string
    {
        if (!$response || !array_key_exists('data', $response)) {
            throw new LocalizedException(__("Error getting session token from gateway"));
        }

        $responseData = $response['data'];
        if (!array_key_exists('vault_token', $responseData)) {
            throw new LocalizedException(__("No vault token found in response from gateway"));
        }

        return $responseData['vault_token'];
    }
}

