<?php
declare(strict_types=1);

namespace Paydock\Powerboard\Exception;

use Magento\Framework\Exception\LocalizedException;

class GatewayException extends LocalizedException
{
}

