define([
    'jquery'
   ], function ($) {
       'use strict';
       return function (target) {
           $.validator.addMethod(
               'validate-json',
               function (value) {
                    try {
                        JSON.parse(value);
                        return true;
                    } catch (e) {
                        return false;
                    }
               },
               $.mage.__('Please enter in valid json format.')
           );
           return target;
       };
   });