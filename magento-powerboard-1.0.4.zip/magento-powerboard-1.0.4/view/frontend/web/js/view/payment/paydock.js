define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';

        let config = window.checkoutConfig.payment,
            paydockCc = 'paydockCreditCard',
            paypal = 'paydockPaypal',
            googlepay = 'paydockGooglePay',
            applePay = 'paydockApplePay',
            afterPay = 'paydockAfterPay',
            zipMoney = 'paydockZipMoney',
            isSafari = window.safari !== undefined;

        if (config[paydockCc] && config[paydockCc].active && config[paydockCc].publicKey) {
            rendererList.push({
                type: 'paydock_cc',
                component: 'Paydock_Powerboard/js/view/payment/method-renderer/creditcard-method'
            });
        }

        if (config[paypal] && config[paypal].active) {
            rendererList.push({
                type: 'paydock_paypal',
                component: 'Paydock_Powerboard/js/view/payment/method-renderer/paypal-method'
            });
        }

        if (config[googlepay] && config[googlepay].active) {
            rendererList.push({
                type: 'paydock_googlepay',
                component: 'Paydock_Powerboard/js/view/payment/method-renderer/googlepay-method'
            });
        }

        if (config[applePay] && config[applePay].active && isSafari) {
            rendererList.push({
                type: 'paydock_applepay',
                component: 'Paydock_Powerboard/js/view/payment/method-renderer/applepay-method'
            });
        }

        if (config[afterPay] && config[afterPay].active) {
            rendererList.push({
                type: 'paydock_afterpay',
                component: 'Paydock_Powerboard/js/view/payment/method-renderer/afterpay-method'
            });
        }

        if (config[zipMoney] && config[zipMoney].active) {
            rendererList.push({
                type: 'paydock_zipmoney',
                component: 'Paydock_Powerboard/js/view/payment/method-renderer/zipmoney-method'
            });
        }

        return Component.extend({});
    }
);

