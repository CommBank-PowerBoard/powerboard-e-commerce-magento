define(
    [
        'Magento_Checkout/js/view/payment/default',
        'jquery',
        'Paydock_Powerboard/js/action/googlepay',
        'Magento_Checkout/js/action/select-payment-method',
        'Magento_Checkout/js/checkout-data'
    ],
    function (Component, $, loadGooglePayButtonAction, selectPaymentMethodAction, checkoutData) {
        'use strict';

        return Component.extend({
            widgetLoaded: false,

            defaults: {
                template: 'Paydock_Powerboard/payment/googlepay-form'
            },

            /**
             * {@inheritdoc}
             */
             initialize: function() {
                this._super();

                let self = this;

                if (checkoutData.getSelectedPaymentMethod() === self.getCode() && !self.widgetLoaded) {
                    self.initWidget();
                }

                $('body').on('afterGetPaymentInformation',  function() {
                    window.location.reload();
                });
            },

            /**
             * Create Google pay widget
             */
            initWidget: function() {
                loadGooglePayButtonAction();
                this.widgetLoaded = true;
            },

            /**
             * @returns {String}
             */
            getCode: function() {
                return this.item.method;
            },

            /**
             * @returns {String}
             */
            getLogoSrc: function() {
                return window.checkoutConfig.payment.paydockGooglePay.logoSrc ?? '';
            },

            /**
             * @returns {Object}
             */
            getData: function() {
                return {
                    'method': this.item.method,
                    'additional_data': {
                        'response_id': $('input[id="googlepay-response-id"]').val()
                    }
                };
            },

            /**
             * @return {Boolean}
             */
            selectPaymentMethod: function() {
                selectPaymentMethodAction(this.getData());
                checkoutData.setSelectedPaymentMethod(this.item.method);

                if (!this.widgetLoaded) {
                    setTimeout(() => {
                        this.initWidget();
                    }, 1500);
                }

                return true;
            }
        });
    }
);

