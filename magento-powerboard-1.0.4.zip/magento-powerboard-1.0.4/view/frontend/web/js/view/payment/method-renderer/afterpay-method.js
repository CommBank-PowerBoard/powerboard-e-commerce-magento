define([
    'Magento_Checkout/js/view/payment/default',
    'uiRegistry',
    'jquery',
    'Magento_Checkout/js/model/quote',
    'mage/url',
    'Paydock_Powerboard/js/model/error-handler',
    'https://widget.staging.powerboard.commbank.com.au/sdk/v1.94.22/widget.umd.js',
    'Magento_Checkout/js/checkout-data',
    'Magento_Checkout/js/action/select-payment-method'
], function (Component, registry, $, quote, urlBuilder, errorHandler, paydock, checkoutData, selectPaymentMethodAction) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Paydock_Powerboard/payment/afterpay-form'
        },
        button: null,

        /**
         * {@inheritdoc}
         */
        initialize: function() {
            this._super();

            $('body').on('afterGetPaymentInformation',  function() {
                window.location.reload();
            });
        },

        /**
         * Load afterpay button when all elements are loaded
         */
        loadAfterpayButton: function() {
            let gatewayId = window.checkoutConfig.payment.paydockAfterPay.gatewayId,
                publicKey = window.checkoutConfig.payment.paydockCreditCard.publicKey,
                baseUrl = urlBuilder.build(''),
                address = quote.shippingAddress(),
                self = this;

            if (typeof publicKey === 'undefined' || publicKey.trim() === '') {
                console.error('Error loading widget - no public key defined');
                return;
            }

            this.button = new paydock.AfterpayCheckoutButton('#afterpay-checkout-button', publicKey, gatewayId);
            this.button.setEnv(this.getEnvironment());
            this.button.onFinishInsert('input[id="afterpay-checkout-button-payment-source-token"]', 'payment_source_token');
            this.button.showEnhancedTrackingProtectionPopup(true);

            this.setMeta({
                amount: quote.totals()['base_grand_total'],
                currency: window.checkoutConfig.quoteData.base_currency_code,
                reference: quote.getQuoteId(),
                email: quote.guestEmail ?? window.checkoutConfig.quoteData.customer_email,
                first_name: address.firstname,
                last_name: address.lastname,
                address_line: address.street[0] ?? '',
                address_line2: address.street[1] ?? '',
                address_city: address.city,
                address_state: address.region,
                address_postcode: address.postcode,
                address_country: address.countryId,
                phone: address.telephone,
                store_id: window.checkoutConfig.quoteData.store_id,
                store_name: window.checkoutConfig.payment.paydockAfterPay.storeName,
                success_url: baseUrl,
                error_url: baseUrl
                /**
                 * @success_url and @error_url 
                 * This can be anything as its not used - just needs to be a valid url
                 */
            });
            
            this.button.on('finish', function(data) {
                self.paydockPlaceOrder();
            });

            this.button.on('error', function (data) {
                let messageContainer = registry.get('checkout.steps.billing-step.payment.payments-list.paydock_afterpay.messages').messageContainer;
                errorHandler.process(data.error, messageContainer);
            });

        },

        /**
         * Set meta data
         * @param {*} metaData
         */
        setMeta: function(metaData) {
            this.button.setMeta(metaData);
        },

        /**
         * @returns {String}
         */
        getCode: function() {
            return this.item.method;
        },

        /**
         * @returns {String}
         */
        getEnvironment: function() {
            return window.checkoutConfig.payment.paydockCreditCard.environment ?? 'production_cba';
        },

        /**
         * @returns {String}
         */
        getLogoSrc: function() {
            return window.checkoutConfig.payment.paydockAfterPay.logoSrc ?? '';
        },

        /**
         * @return {String}
         */
        getMpid: function() {
            return window.checkoutConfig.payment.paydockAfterPay.mpid ?? '';
        },

        /**
         * @return {String}
         */
        getPlacementId: function() {
            return window.checkoutConfig.payment.paydockAfterPay.placementId ?? '';
        },

        /**
         * @return {String}
         */
        getCurrencyCode: function() {
            return window.checkoutConfig.quoteData.base_currency_code ?? '';
        },

        /**
         * @return {String}
         */
        getLocale: function() {
            return window.checkoutConfig.payment.paydockAfterPay.locale ?? '';
        },

        /**
         * @return {number}
         */
        getQuoteTotal: function() {
            return quote.totals()['base_grand_total'] ?? 0;
        },

        /**
         * @return {Boolean}
         */
        selectPaymentMethod: function () {
            selectPaymentMethodAction(this.getData());
            checkoutData.setSelectedPaymentMethod(this.item.method);

            let totals = quote.getTotals()();

            if (totals) {
                if (totals['coupon_code']) {
                    this.setMeta({amount: quote.totals()['base_grand_total']});
                }
            }

            return true;
        },

        /**
         * Place Afterpay order
         */
        paydockPlaceOrder: function() {
            $('#paydock-afterpay-place-token-order').click();
            return;
        },

        /**
         * @returns {Object}
         */
        getData: function() {
            return {
                'method': this.item.method,
                'additional_data': {
                    'payment_token': $('input[id="afterpay-checkout-button-payment-source-token"]').val()
                }
            };
        }
    });
});

