define([
  'uiRegistry',
  'Magento_Checkout/js/model/error-processor'
], function (registry, errorProcessor) {
  'use strict';

  return {
    process: function (response, messageContainer = undefined) {
      messageContainer = messageContainer || registry.get('checkout.errors').messageContainer;
      if (typeof response === 'string') {
        response = this.buildResponse(response);
      }
      
      errorProcessor.process(response, messageContainer);
    },
    
    buildResponse: function(responseText) {
      return {
        status:  400,
        responseText: '{"message": "'+responseText+'"}'
      }
    }
  };
});

