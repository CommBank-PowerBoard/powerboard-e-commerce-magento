<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Api;

interface PaydockBeforePostDataManagementInterface
{
    /**
     * @param array $postData
     * @param string $endpoint
     * @return array
     */
    public function execute(array $postData, string $endpoint): array;
}
