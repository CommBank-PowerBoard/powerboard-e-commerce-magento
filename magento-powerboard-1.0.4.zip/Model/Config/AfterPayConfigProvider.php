<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model\Config;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Asset\Source;
use Magento\Payment\Helper\Data as PaymentHelper;
use Magento\Payment\Model\CcConfig;
use Magento\Payment\Model\MethodInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Paydock\Powerboard\Api\AfterPayConfigurationManagementInterface;
use Paydock\Powerboard\Api\Data\PaydockAfterPayInterface;

class AfterPayConfigProvider implements ConfigProviderInterface
{
    /**
     * @var string
     */
    protected string $methodCode = PaydockAfterPayInterface::METHOD_CODE;

    /**
     * @var MethodInterface
     */
    protected MethodInterface $method;

    /**
     * @var AfterPayConfigurationManagementInterface
     */
    private AfterPayConfigurationManagementInterface $afterPayConfigurationManagement;

    /**
     * @var StoreManagerInterface
     */
    private StoreManagerInterface $storeManager;

    /**
     * @var Source
     */
    private Source $assetSource;

    /**
     * @var CcConfig
     */
    private CcConfig $ccConfig;

    /**
     * @var ScopeConfigInterface
     */
    private ScopeConfigInterface $scopeConfig;

    /**
     * @param PaymentHelper $paymentHelper
     * @param AfterPayConfigurationManagementInterface $afterPayConfigurationManagement
     * @param StoreManagerInterface $storeManager
     * @param Source $assetSource
     * @param CcConfig $ccConfig
     * @param ScopeConfigInterface $scopeConfig
     * @throws LocalizedException
     */
    public function __construct(
        PaymentHelper $paymentHelper,
        AfterPayConfigurationManagementInterface $afterPayConfigurationManagement,
        StoreManagerInterface $storeManager,
        Source $assetSource,
        CcConfig $ccConfig,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->method = $paymentHelper->getMethodInstance($this->methodCode);
        $this->afterPayConfigurationManagement = $afterPayConfigurationManagement;
        $this->storeManager = $storeManager;
        $this->assetSource = $assetSource;
        $this->ccConfig = $ccConfig;
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * @inheritDoc
     * @throws NoSuchEntityException
     */
    public function getConfig(): array
    {
        return [
            'payment' => [
                'paydockAfterPay' => [
                    'active' => $this->afterPayConfigurationManagement->isActive(),
                    'title' => $this->afterPayConfigurationManagement->getTitle(),
                    'gatewayId' => $this->afterPayConfigurationManagement->getGatewayId(),
                    'logoSrc' => $this->getLogoSrc(),
                    'storeName' => $this->storeManager->getStore()->getName(),
                    'mpid' => $this->afterPayConfigurationManagement->getMpid(),
                    'placementId' => $this->afterPayConfigurationManagement->getPlacementId(),
                    'locale' => $this->scopeConfig->getValue('general/country/default', ScopeInterface::SCOPE_STORE)
                ]
            ]
        ];
    }

    /**
     * @return string
     */
    public function getLogoSrc(): string
    {
        $src = '';
        $asset = $this->ccConfig->createAsset('Paydock_Powerboard::images/afterpay.png');
        if ($asset) {
            $placeholder = $this->assetSource->findSource($asset);
            if ($placeholder) {
                $src = $asset->getUrl();
            }
        }
        return $src;
    }
}

