<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Paydock\Powerboard\Api\ApplePayConfigurationManagementInterface;
use Paydock\Powerboard\Api\ConfigurationManagementInterface;


class ApplePayConfigurationManagement implements ApplePayConfigurationManagementInterface
{
    /**
     * @var ScopeConfigInterface
     */
    private ScopeConfigInterface $scopeConfig;

    /**
     * @var ConfigurationManagementInterface
     */
    private ConfigurationManagementInterface $configurationManagement;

    /**
     * @param ScopeConfigInterface $scopeConfig
     * @param ConfigurationManagementInterface $configurationManagement
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        ConfigurationManagementInterface $configurationManagement
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->configurationManagement = $configurationManagement;
    }

    /**
     * @inheritDoc
     */
    public function isActive(): bool
    {
        return (bool)($this->scopeConfig->getValue(self::XML_PATH_ACTIVE, ScopeInterface::SCOPE_STORE)
            && $this->configurationManagement->isActive()
            && !empty($this->configurationManagement->getPublicKey())
            && !empty($this->configurationManagement->getSecretKey()));
    }

    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return (string)$this->scopeConfig->getValue(self::XML_PATH_TITLE, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @inheritDoc
     */
    public function getGatewayId(): string
    {
        return (string)$this->scopeConfig->getValue(self::XML_PATH_GATEWAY_ID, ScopeInterface::SCOPE_STORE) ?? '';
    }
}

