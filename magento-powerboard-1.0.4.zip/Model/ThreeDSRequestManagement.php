<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Model\QuoteRepository;
use Paydock\Powerboard\Api\ChargesServiceInterface;
use Paydock\Powerboard\Api\PaymentManagementInterface;
use Paydock\Powerboard\Api\PaymentSourceServiceInterface;
use Paydock\Powerboard\Api\ThreeDSRequestManagementInterface;
use Paydock\Powerboard\Api\CustomersServiceInterface;
use Paydock\Powerboard\Model\Command\GatewayCommand;
use Psr\Log\LoggerInterface;

class ThreeDSRequestManagement implements ThreeDSRequestManagementInterface
{
    /**
     * @var PaymentSourceServiceInterface
     */
    private PaymentSourceServiceInterface $paymentSourceService;

    /**
     * @var ChargesServiceInterface
     */
    private ChargesServiceInterface $chargesService;

    /**
     * @var LoggerInterface
     */
    private LoggerInterface $logger;

     /**
     * @var QuoteRepository
     */
    private QuoteRepository $quoteRepository;

    /**
     * @var CustomerRepositoryInterface
     */
    private CustomerRepositoryInterface $customerRepository;

    /**
     * @var PaymentManagementInterface
     */
    private PaymentManagementInterface $paymentManagement;

    /**
     * @var CustomersServiceInterface
     */
    private CustomersServiceInterface $customersService;

    /**
     * @param PaymentSourceServiceInterface $paymentSourceService
     * @param ChargesServiceInterface $chargesService
     * @param LoggerInterface $logger
     * @param QuoteRepository $quoteRepository
     * @param CustomerRepositoryInterface $customerRepository
     * @param PaymentManagementInterface $paymentManagement
     */
    public function __construct(
        PaymentSourceServiceInterface $paymentSourceService,
        ChargesServiceInterface $chargesService,
        LoggerInterface $logger,
        QuoteRepository $quoteRepository,
        CustomerRepositoryInterface $customerRepository,
        PaymentManagementInterface $paymentManagement,
        CustomersServiceInterface $customersService
    ) {
        $this->paymentSourceService = $paymentSourceService;
        $this->chargesService = $chargesService;
        $this->logger = $logger;
        $this->quoteRepository = $quoteRepository;
        $this->customerRepository = $customerRepository;
        $this->paymentManagement = $paymentManagement;
        $this->customersService = $customersService;
    }

    /**
     * @inheritDoc
     */
    public function place3dsPreAuthRequest(string $paymentToken, string $cartId, mixed $browserDetails, $existingPaymentSource = false, bool $ccSave = false): ?string
    {
        try {
            $quote = $this->quoteRepository->get($cartId);
        } catch (NoSuchEntityException $e) {
            $this->logger->critical(__('Unable to find quote for cart ID %1', $cartId));
            throw new LocalizedException(__(GatewayCommand::GENERIC_ERROR));
        }
    
        if ($existingPaymentSource) {
            $vaultToken = $paymentToken;
        } elseif ($quote->getCustomerIsGuest() || !$ccSave) {
            $vaultToken = $this->getSessionToken($paymentToken);
        } else {
            $vaultToken = $this->getPermanentToken($paymentToken);
        }

        if ($vaultToken === null) {
            $this->logger->critical(__("Error generating vault token"));
            throw new LocalizedException(__(GatewayCommand::GENERIC_ERROR));
        }

        try {
            $response = $this->chargesService->place3dsPreAuthRequest($quote, $vaultToken, $browserDetails);
            $token3ds = $response ? $response['data']['_3ds']['token'] : null;
            
            // Store this token as this will be use when placing the order.
            $quote->setData('vault_token', $vaultToken);
            $this->quoteRepository->save($quote);
        } catch (LocalizedException | CouldNotSaveException $e) {
            $this->logger->critical(__("Error generating 3ds token: %1", $e->getMessage()));
            throw new LocalizedException(__(GatewayCommand::GENERIC_ERROR));
        }

        return $token3ds;
    }

    /**
     * @param string $paymentToken
     * @return string|null
     */
    private function getSessionToken(string $paymentToken): ?string
    {
        try {
            return $this->paymentSourceService->getSessionToken($paymentToken);
        } catch (LocalizedException $e) {
            $this->logger->critical(__("Error generating session token: %1", $e->getMessage()));
            return null;
        }
    }

    /**
     * @param string $paymentToken
     * @return string|null
     */
    private function getPermanentToken(string $paymentToken): ?string
    {
        try {
            return $this->paymentSourceService->getPermanentToken($paymentToken);
        } catch (LocalizedException $e) {
            $this->logger->critical(__("Error generating permanent token: %1", $e->getMessage()));
            return null;
        }
    }

    /**
     * @param int $customerId
     * @return string|null
     */
    private function getPaydockCustomerId(int $customerId): ?string
    {
        if (!$customerId) {
            return null;
        }

        try {
            $customer = $this->customerRepository->getById($customerId);;
        } catch (NoSuchEntityException|LocalizedException $e) {
            return null;
        }
        
        $paydockCustomerId = $customer->getCustomAttribute('paydock_customer_id');
        return $paydockCustomerId?->getValue();
    }
}

