<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway\Request;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Payment\Gateway\Request\BuilderInterface;
use Magento\Quote\Model\QuoteRepository;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use Paydock\Powerboard\Api\PaymentManagementInterface;
use Paydock\Powerboard\Api\PaymentSourceServiceInterface;
use Paydock\Powerboard\Gateway\Data\Order\OrderAdapter;
use Paydock\Powerboard\Gateway\Helper\SubjectReader;
use Psr\Log\LoggerInterface;

class ChargeDataBuilder implements BuilderInterface
{
    /**
     * @var SubjectReader
     */
    private SubjectReader $subjectReader;

    /**
     * @var PaymentSourceServiceInterface
     */
    private PaymentSourceServiceInterface $paymentSourceService;

    /**
     * @var QuoteRepository
     */
    private QuoteRepository $quoteRepository;

    /**
     * @var PaymentManagementInterface
     */
    private PaymentManagementInterface $paymentManagement;

    /**
     * @var LoggerInterface
     */
    private LoggerInterface $logger;

    /**
     * Constructor
     *
     * @param SubjectReader $subjectReader
     * @param PaymentSourceServiceInterface $paymentSourceService
     * @param QuoteRepository $quoteRepository
     * @param PaymentManagementInterface $paymentManagement
     * @param LoggerInterface $logger
     */
    public function __construct(
        SubjectReader $subjectReader,
        PaymentSourceServiceInterface $paymentSourceService,
        QuoteRepository $quoteRepository,
        PaymentManagementInterface $paymentManagement,
        LoggerInterface $logger
    ) {
        $this->subjectReader = $subjectReader;
        $this->paymentSourceService = $paymentSourceService;
        $this->quoteRepository = $quoteRepository;
        $this->paymentManagement = $paymentManagement;
        $this->logger = $logger;
    }

    /**
     * @inheritdoc
     * @throws LocalizedException
     */
    public function build(array $buildSubject): array
    {
        $paymentDO = $this->subjectReader->readPayment($buildSubject);

        /** @var OrderPaymentInterface $payment */
        $payment = $paymentDO->getPayment();
        if ($payment->getAdditionalInformation('charge_id')) {
            return $this->captureAuthorisedTransaction($payment);
        }
        
        $data = [
            'payment' => $payment,
            'save_card' => (bool)$payment->getAdditionalInformation('cc_save') ?? false
        ];
        
        /**
         * Override in di.xml, so we can add extra public methods.
         * In this instance, so we can eventually get the quote object.
         * @var OrderAdapter $order
         */
        $order = $paymentDO->getOrder();

        try {
            $quote = $this->quoteRepository->get($order->getQuoteId());
        } catch (NoSuchEntityException $e) {
            throw new LocalizedException(__('Quote not found.'), $e);
        }

        $paymentToken = (string)$payment->getAdditionalInformation('payment_token');
        if ($quote->getData('vault_token')) {
            $vaultToken = $quote->getData('vault_token');
        } elseif ($this->paymentManagement->isPaymentSources($payment)) {
            $vaultToken = $paymentToken;
        } else {
            $vaultToken = $this->paymentManagement->canSaveCard($payment) ?
                $this->getPermanentToken($paymentToken) :
                $this->getSessionToken($paymentToken);
        }
        
        if ($vaultToken) {
            $data['vault_token'] = $vaultToken;
        }

        $charge3dsId = (string)$payment->getAdditionalInformation('charge_3ds_id');
        if ($charge3dsId) {
            $data['charge_3ds_id'] = $charge3dsId;
        }
        
        return $data;
    }

    /**
     * @var OrderPaymentInterface $order
     * @var string $chargeId
     * @return array
     */
    private function captureAuthorisedTransaction(OrderPaymentInterface $payment): array
    {
        return [
            'payment' => $payment,
            'charge_id' => $payment->getAdditionalInformation('charge_id')
        ];
    }

    /**
     * @param string $paymentToken
     * @return string|null
     */
    private function getSessionToken(string $paymentToken): ?string
    {
        try {
            return $this->paymentSourceService->getSessionToken($paymentToken);
        } catch (LocalizedException $e) {
            $this->logger->critical(__("Error generating session token: %1", $e->getMessage()));
            return null;
        }
    }

    /**
     * @param string $paymentToken
     * @return string|null
     */
    private function getPermanentToken(string $paymentToken): ?string
    {
        try {
            return $this->paymentSourceService->getPermanentToken($paymentToken);
        } catch (LocalizedException $e) {
            $this->logger->critical(__("Error generating permanent token: %1", $e->getMessage()));
            return null;
        }
    }
}

