<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway\Request;

use Magento\Framework\Exception\NotFoundException;
use Magento\Payment\Gateway\Request\BuilderInterface;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use Paydock\Powerboard\Gateway\Helper\SubjectReader;

class RefundDataBuilder implements BuilderInterface
{
    /**
     * @var SubjectReader
     */
    private SubjectReader $subjectReader;

    /**
     * @param SubjectReader $subjectReader
     */
    public function __construct(
        SubjectReader $subjectReader
    ) {
        $this->subjectReader = $subjectReader;
    }

    /**
     * @inheritdoc
     * @throws NotFoundException
     */
    public function build(array $buildSubject): array
    {
        $paymentDO = $this->subjectReader->readPayment($buildSubject);
        $paymentAmount = $this->subjectReader->readAmount($buildSubject);

        /** @var OrderPaymentInterface $payment */
        $payment = $paymentDO->getPayment();
        $chargeId = $payment->getAdditionalInformation('charge_id');
        if (!$chargeId) {
            throw new NotFoundException(__("No charge ID found against the payment"));
        }

        return [
            'charge_id' => $chargeId,
            'amount' => $paymentAmount,
            'full' => $this->isFullRefund($payment, $paymentAmount)
        ];
    }

    /**
     * @param OrderPaymentInterface $payment
     * #param float $amount
     * @param float $amount
     * @return bool
     */
    private function isFullRefund(OrderPaymentInterface $payment, float $amount): bool
    {
        return $amount  === (float)$payment->getBaseAmountPaid();
    }
}
