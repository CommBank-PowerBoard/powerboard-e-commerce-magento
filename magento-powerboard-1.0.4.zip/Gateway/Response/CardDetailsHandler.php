<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway\Response;

use Magento\Payment\Gateway\Response\HandlerInterface;
use Paydock\Powerboard\Gateway\Helper\SubjectReader;

class CardDetailsHandler implements HandlerInterface
{
    /**
     * @var SubjectReader
     */
    private SubjectReader $subjectReader;

    /**
     * @param SubjectReader $subjectReader
     */
    public function __construct(
        SubjectReader $subjectReader
    ) {
        $this->subjectReader = $subjectReader;
    }

    /**
     * Handle additional information
     *
     * @param array $handlingSubject
     * @param array $response
     */
    public function handle(array $handlingSubject, array $response)
    {
        $paymentDO = $this->subjectReader->readPayment($handlingSubject);

        $payment = $paymentDO->getPayment();
        $payment->setCcLast4($response['data']['customer']['payment_source']['card_number_last4'] ?? '');
        $payment->setCcExpMonth($response['data']['customer']['payment_source']['expire_month'] ?? '');
        $payment->setCcExpYear($response['data']['customer']['payment_source']['expire_year'] ?? '');
        $payment->setCcType($response['data']['customer']['payment_source']['card_scheme'] ?? '');

        $payment->setAdditionalInformation('vault_token', $response['data']['customer']['payment_source']['vault_token'] ?? '');
        $payment->setAdditionalInformation('gateway_id', $response['data']['customer']['payment_source']['gateway_id'] ?? '');
        $payment->setAdditionalInformation('charge_id', $response['data']['_id'] ?? '');
        $payment->setAdditionalInformation('external_id', $response['data']['external_id'] ?? '');

        $payment->unsAdditionalInformation('payment_token');
    }
}
