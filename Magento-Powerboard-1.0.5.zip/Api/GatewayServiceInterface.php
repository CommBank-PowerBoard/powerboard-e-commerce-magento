<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Api;

interface GatewayServiceInterface
{
    /**
     * @param string $endpoint
     * @param array $headers
     * @return array|null
     */
    public function get(string $endpoint, array $headers = []): ?array;

    /**
     * @param string $endpoint
     * @param array $postData
     * @param array $headers
     * @return array|null
     */
    public function post(string $endpoint, array $postData = [], array $headers = []): ?array;
}

