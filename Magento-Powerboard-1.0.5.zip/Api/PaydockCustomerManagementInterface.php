<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Api;

use Magento\Sales\Api\Data\OrderPaymentInterface;

interface PaydockCustomerManagementInterface
{
    /**
     * @param OrderPaymentInterface $payment
     * @param string $vaultToken
     * @return array|null
     */
    public function createPaydockCustomer(OrderPaymentInterface $payment, string $vaultToken): ?array;
}

