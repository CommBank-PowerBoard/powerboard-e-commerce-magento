<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Api;

interface CreditCardConfigurationManagementInterface
{
    public const DEFAULT_XML_PATH_ACTIVE = 0;
    public const DEFAULT_XML_PATH_TITLE = 'Credit Card';
    public const DEFAULT_XML_PATH_GATEWAY_ID = '';
    public const DEFAULT_XML_PATH_CC_TYPES = 'VI,MC';
    public const DEFAULT_XML_PATH_BACKEND_ORDERS = 0;
    public const DEFAULT_XML_PATH_SORT_ORDER = '30';
    public const DEFAULT_XML_PATH_PAYMENT_ACTION = 'authorize_capture';
    public const DEFAULT_XML_PATH_DIRECT_CHARGE = 0;
    public const DEFAULT_XML_PATH_3DS = 0;
    public const DEFAULT_XML_PATH_ALLOWSPECIFIC = 0;
    public const DEFAULT_XML_PATH_SAVE_CARD = 0;
    public const DEFAULT_XML_PATH_CSS_LABEL = '{"font_weight": "400","font_size": "1.4rem","color": "#333333", "font-family": "\'Open Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif"}';
    public const DEFAULT_XML_PATH_CSS_INPUT = '{"font_size": "1.4rem","height": "3.2rem","border": "1px solid #c2c2c2","border_radius": "1px"}';
    public const DEFAULT_XML_PATH_CSS_SUBMIT = '{"border": "1px solid #1979c3","background_color": "#1979c3","font_weight": "500","line_height": "2.2rem","font_size": "1.8rem","border_radius": "3px", "font-family": "sans-serif"}';
    public const DEFAULT_XML_PATH_BACKEND_CSS_LABEL = '{"font_weight": "600","font_size": "1.4rem","color": "#333333"}';
    public const DEFAULT_XML_PATH_BACKEND_CSS_INPUT = '{"background_color": "#ffffff", "border": "1px solid #adadad", "border_radius": "1px", "color": "#303030", "font_size": "1.4rem", "height": "auto", "line_height": "1.36", "transition": "border-color 0.1s linear"}';
    public const XML_PATH_ACTIVE = 'payment/paydock_cc/active';
    public const XML_PATH_SAVE_CARD = 'payment/paydock_cc/save_card';
    public const XML_PATH_3DS = 'payment/paydock_cc/3ds';
    public const XML_PATH_BACKEND_ORDERS = 'payment/paydock_cc/enabled_magento_backend';
    public const XML_PATH_GATEWAY_ID = 'payment/paydock_cc/gateway_id';
    public const XML_PATH_CSS_LABEL = 'payment/paydock_cc/css_label';
    public const XML_PATH_CSS_INPUT = 'payment/paydock_cc/css_input';
    public const XML_PATH_CSS_SUBMIT = 'payment/paydock_cc/css_submit_button';
    public const XML_PATH_BACKEND_CSS_LABEL = 'payment/paydock_cc/backend_css_label';
    public const XML_PATH_BACKEND_CSS_INPUT = 'payment/paydock_cc/backend_css_input';
    public const XML_PATH_CC_TYPES = 'payment/paydock_cc/cctypes';
    public const XML_PATH_DIRECT_CHARGE = 'payment/paydock_cc/direct_charge';

    /**
     * @return bool
     */
    public function isActive(): bool;

    /**
     * @return bool
     */
    public function canSaveCard(): bool;

    /**
     * @return bool
     */
    public function is3DS(): bool;

    /**
     * @return bool
     */
    public function isBackendOrder(): bool;

    /**
     * @return string
     */
    public function getGatewayId(): string;

    /**
     * @return string
     */
    public function getCssInput(): string;


    /**
     * @return string
     */
    public function getCssLabel(): string;


    /**
     * @return string
     */
    public function getCssSubmitButton(): string;

    /**
     * @return string
     */
    public function getBackendCssInput(): string;


    /**
     * @return string
     */
    public function getBackendCssLabel(): string;

    /**
     * @return array
     */
    public function getAvailableCardTypes(): array;

    /**
     * @return bool
     */
    public function canDirectCharge(): bool;
}

