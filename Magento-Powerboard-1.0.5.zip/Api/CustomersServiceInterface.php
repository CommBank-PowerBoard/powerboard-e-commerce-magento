<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Api;

use Magento\Quote\Api\Data\CartInterface;
use Magento\Sales\Api\Data\OrderInterface;

interface CustomersServiceInterface
{
    public const ENDPOINT_CUSTOMERS = '/v1/customers';
    public const ENDPOINT_CUSTOMERS_POST = '/v1/customers/%s';
    public const ENDPOINT_CUSTOMERS_GET = '/v1/customers?id=%s';

    /**
     * @param string $paydockCustomerId
     * @return array|null
     */
    public function getCustomerById(string $paydockCustomerId): ?array;

    /**
     * @param string $paydockCustomerId
     * @return string|null
     */
    public function getCustomerIdById(string $paydockCustomerId): ?string;

    /**
     * @param string $paydockCustomerId
     * @return string|null
     */
    public function getPaymentSourcesById(string $paydockCustomerId): ?string;

    /**
     * @param string $paydockCustomerId
     * @return string|null
     */
    public function getVaultTokenById(string $paydockCustomerId): ?string;

    /**
     * @param string $paydockCustomerId
     * @return string|null
     */
    public function getQueryTokenById(string $paydockCustomerId): ?string;

    /**
     * @param CartInterface|OrderInterface $order
     * @param string $vaultToken
     * @return string
     */
    public function createCustomer(CartInterface | OrderInterface $order, string $vaultToken): string;

    /**
     * @param string $paydockCustomerId
     * @param array $paymentSourcedetail
     * @param string|null $defaultPaymentSourceId
     *
     * @return array|null
     */
    public function addPaymentSource(string $paydockCustomerId, array $paymentSourcedetail, ?string $defaultPaymentSourceId = null): ?array;

    /**
     * @param string $paydockCustomerId
     * @param string $vaultToken
     *
     * @return array|null
     */
    public function addVaultTokenPaymentSource(string $paydockCustomerId, string $vaultToken): ?array;

    /**
     * @param string $paydockCustomerId
     * @return string|null
     */
    public function getCustomerPaymentSourceById(string $paydockCustomerId): ?string;

    /**
     * @param string $paydockCustomerId
     * @param string $vaultToken
     * @return string|null
     */
    public function saveVaultTokenToCustomerPaymentSource(string $paydockCustomerId,  string $vaultToken): ?string;

}


