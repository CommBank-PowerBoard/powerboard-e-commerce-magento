<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Block\CreditCard;

use Magento\Framework\Serialize\Serializer\Json;
use Magento\Framework\View\Element\Template\Context;
use Magento\Payment\Block\Form as PaymentForm;
use Paydock\Powerboard\Model\Config\CreditCardConfigProvider;

class Form extends PaymentForm
{
    /**
     * @var CreditCardConfigProvider
     */
    private CreditCardConfigProvider $configProvider;

    /**
     * @var Json
     */
    private Json $json;

    /**
     * @param CreditCardConfigProvider $configProvider
     * @param Json $json
     * @param Context $context
     * @param array $data
     */
    public function __construct(
        CreditCardConfigProvider $configProvider,
        Json $json,
        Context $context,
        array $data = []
    ) {
        $this->configProvider = $configProvider;
        $this->json = $json;
        parent::__construct($context, $data);
    }

    /**
     * @return string
     */
    public function getCreditCardConfiguration(): string
    {
        return $this->json->serialize($this->configProvider->getConfig());
    }
}

