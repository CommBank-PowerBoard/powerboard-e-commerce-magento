<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare (strict_types = 1);

namespace Paydock\Powerboard\Block\Adminhtml\System\Config\Form\Field;

use Magento\Backend\Block\Template\Context;
use Magento\Config\Block\System\Config\Form\Field;
use Magento\Config\Model\Config\Source\Enabledisable;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Paydock\Powerboard\Api\ConfigurationManagementInterface;
use Paydock\Powerboard\Block\Adminhtml\System\Config\Form\Field\AfterpayActiveActionField;
use Paydock\Powerboard\Block\Adminhtml\System\Config\Form\Field\CreditCardActiveActionField;
use Paydock\Powerboard\Block\Adminhtml\System\Config\Form\Field\GeneralActiveActionField;
use Paydock\Powerboard\Block\Adminhtml\System\Config\Form\Field\PaypalActiveActionField;

class PaydockActiveActionField extends Field
{

    /**
     * @var AfterpayActiveActionField
     */
    protected AfterpayActiveActionField $afterpayActiveActionField;

    /**
     * @var CreditCardActiveActionField
     */
    protected CreditCardActiveActionField $creditCardActiveActionField;

    /**
     * @var PaypalActiveActionField
     */
    protected PaypalActiveActionField $paypalActiveActionField;

    /**
     * @var GeneralActiveActionField
     */
    protected GeneralActiveActionField $generalActiveActionField;

    /**
     * @param Context $context
     * @param AfterpayActiveActionField $afterpayActiveActionField
     * @param CreditCardActiveActionField $creditCardActiveActionField
     * @param PaypalActiveActionField $paypalActiveActionField
     * @param GeneralActiveActionField $generalActiveActionField
     * @param array $data
     */
    public function __construct(
        Context $context,
        AfterpayActiveActionField $afterpayActiveActionField,
        CreditCardActiveActionField $creditCardActiveActionField,
        PaypalActiveActionField $paypalActiveActionField,
        GeneralActiveActionField $generalActiveActionField,
        array $data = []
    ) {
        $this->afterpayActiveActionField = $afterpayActiveActionField;
        $this->creditCardActiveActionField = $creditCardActiveActionField;
        $this->paypalActiveActionField = $paypalActiveActionField;
        $this->generalActiveActionField = $generalActiveActionField;
        parent::__construct($context, $data);
    }

    /**
     * @param AbstractElement $element
     * @return string
     */
    protected function _getElementHtml(AbstractElement $element): string
    {
        $html = parent::_getElementHtml($element);
        $htmlId = $element->getHtmlId();
        $paymentHtmlId = str_replace('_active', '', $htmlId);
        $paydockCss = ConfigurationManagementInterface::DEFAULT_XML_PATH_CSS;
        $script = "
            <script>
                require(['jquery', 'domReady!'], function ($) {
                    $(document).ready(function () {
                        function updateActiveAction() {
                            if (parseInt($('#{$htmlId}').val()) === " . Enabledisable::DISABLE_VALUE . ") {
                                $('#{$paymentHtmlId}_public_key').val('');
                                $('#{$paymentHtmlId}_secret_key').val('');
                                $('#{$paymentHtmlId}_css').val('{$paydockCss}');
                                $('#{$paymentHtmlId}_cc_active').val(" . Enabledisable::DISABLE_VALUE . ").prop('disabled', true);
                                $('#row_{$paymentHtmlId}_cc tbody > tr:not(#row_{$paymentHtmlId}_cc_active):not(#row_{$paymentHtmlId}_cc_title)').hide();
                                " . $this->creditCardActiveActionField->renderCreditCardScripts($paymentHtmlId.'_cc') . "
                                $('#{$paymentHtmlId}_paypal_active').val(" . Enabledisable::DISABLE_VALUE . ").prop('disabled', true);
                                $('#row_{$paymentHtmlId}_paypal tbody > tr:not(#row_{$paymentHtmlId}_paypal_active):not(#row_{$paymentHtmlId}_paypal_title)').hide();
                                " . $this->paypalActiveActionField->renderPaypalScripts($paymentHtmlId.'_paypal') . "
                                $('#{$paymentHtmlId}_googlepay_active').val(" . Enabledisable::DISABLE_VALUE . ").prop('disabled', true);
                                $('#row_{$paymentHtmlId}_googlepay tbody > tr:not(#row_{$paymentHtmlId}_googlepay_active):not(#row_{$paymentHtmlId}_googlepay_title)').hide();
                                " . $this->generalActiveActionField->renderGeneralScripts($paymentHtmlId.'_googlepay') . "
                                $('#{$paymentHtmlId}_applepay_active').val(" . Enabledisable::DISABLE_VALUE . ").prop('disabled', true);
                                $('#row_{$paymentHtmlId}_applepay tbody > tr:not(#row_{$paymentHtmlId}_applepay_active):not(#row_{$paymentHtmlId}_applepay_title)').hide();
                                " . $this->generalActiveActionField->renderGeneralScripts($paymentHtmlId.'_applepay') . "
                                $('#{$paymentHtmlId}_afterpay_active').val(" . Enabledisable::DISABLE_VALUE . ").prop('disabled', true);
                                $('#row_{$paymentHtmlId}_afterpay tbody > tr:not(#row_{$paymentHtmlId}_afterpay_active):not(#row_{$paymentHtmlId}_afterpay_title)').hide();
                                " . $this->afterpayActiveActionField->renderAfterpayScripts($paymentHtmlId.'_afterpay') . "
                                $('#{$paymentHtmlId}_zipmoney_active').val(" . Enabledisable::DISABLE_VALUE . ").prop('disabled', true);
                                 $('#row_{$paymentHtmlId}_zipmoney tbody > tr:not(#row_{$paymentHtmlId}_zipmoney_active):not(#row_{$paymentHtmlId}_zipmoney_title)').hide();
                                " . $this->generalActiveActionField->renderGeneralScripts($paymentHtmlId.'_zipmoney') . "
                            }
                        }
                        updateActiveAction();
                        $('#{$htmlId}').on('change', function () {
                            updateActiveAction();
                        });
                    });
                });
            </script>
        ";

        return $html . $script;
    }
}
