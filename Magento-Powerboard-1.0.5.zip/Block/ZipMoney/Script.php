<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Block\ZipMoney;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Paydock\Powerboard\Api\ZipMoneyConfigurationManagementInterface;

class Script extends Template
{
    /**
     * @var string
     */
    protected $_template = 'Paydock_Powerboard::zipmoney-script.phtml';

    /**
     * @var ZipMoneyConfigurationManagementInterface
     */
    private ZipMoneyConfigurationManagementInterface $zipMoneyConfigurationManagement;

    /**
     * @param ZipMoneyConfigurationManagementInterface $zipMoneyConfigurationManagement
     * @param Context $context
     * @param array $data
     */
    public function __construct(
        ZipMoneyConfigurationManagementInterface $zipMoneyConfigurationManagement,
        Context $context,
        array $data = []
    ) {
        $this->zipMoneyConfigurationManagement = $zipMoneyConfigurationManagement;
        parent::__construct($context, $data);
    }

    /**
     * @return bool
     */
    public function isEnabled(): bool
    {
        return $this->zipMoneyConfigurationManagement->isActive();
    }
}

