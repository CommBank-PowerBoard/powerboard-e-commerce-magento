<?php

declare(strict_types=1);

namespace Paydock\Powerboard\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\ObjectManagerInterface;

class Paydock extends AbstractHelper
{
    /**
     * @var ObjectManagerInterface
     */
    private $objectManager;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param ObjectManagerInterface $objectManager
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        ObjectManagerInterface $objectManager
    ) {
        parent::__construct($context);
        $this->objectManager = $objectManager;
    }

    /**
     * retrieve a random generated nonce
     * @return string
     */
    public function getNonce()
    {
        $nonce = bin2hex(random_bytes(16));

        if (class_exists(\Magento\Csp\Helper\CspNonceProvider::class)) {
            $cspNonceProvider = $this->objectManager->create(\Magento\Csp\Helper\CspNonceProvider::class);
            $nonce = $cspNonceProvider->generateNonce();
        }

        return $nonce;
    }
}