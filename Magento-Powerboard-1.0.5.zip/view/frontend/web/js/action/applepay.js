/**
 * @api
 */
define([
    'jquery',
    'Paydock_Powerboard/js/model/error-handler',
    'Magento_Checkout/js/model/url-builder',
    'mage/storage',
    'Magento_Checkout/js/model/full-screen-loader',
    'Magento_Checkout/js/model/quote',
    'Paydock_Powerboard_Widget'
], function ($, errorHandler, urlBuilder, storage, fullScreenLoader, quote, paydock) {
    'use strict';

    var placeOrder = function (chargeId) {
        if (chargeId) {
            $('input[id="applepay-response-id"]').val(chargeId);
            $('#paydock-applepay-place-order').click();
        } else {
            errorHandler.process('Error processing request, please try again');
        }
    }

    return function () {
        let serviceUrl;

        serviceUrl = urlBuilder.createUrl(
            '/paydock/wallet/token/:cartId',
            {
                cartId:  quote.getQuoteId()
            }
        );

        fullScreenLoader.startLoader();

        return storage.get(
            serviceUrl,
            false
        ).done(
            function (response) {
                let result = JSON.parse(response),
                    environment = window.checkoutConfig.payment.paydockCreditCard.environment ?? 'production_cba';
                
                if (result.success) {
                    $('#paydock_applepay_widget').empty();
                    let button = new paydock.WalletButtons("#paydock_applepay_widget", result.token_wallet, {
                        amount_label: 'Total',
                        country: 'AU',
                        wallets: ['apple'],
                        request_shipping: false,
                        style: {
                            button_type: 'buy',
                        },
                    });
                
                    button.setEnv(environment);
                    button.onUnavailable(() => console.error('No wallet buttons available'));
                    button.onPaymentSuccessful((data) => {
                        placeOrder(result.charge_id);
                    });
                    
                    button.onUpdate(function (data) {
                        setTimeout(function () {
                          button.update({
                            success: true,
                            body: {}
                          });
                        }, 3000);
                    });
                    button.load();
                } else {
                    errorHandler.process(result.error);
                }

            }
        ).fail(
            function (response) {
                errorHandler.process(response);
            }
        ).always(
            function (response) {
                fullScreenLoader.stopLoader();
            }
        );
    };
});
