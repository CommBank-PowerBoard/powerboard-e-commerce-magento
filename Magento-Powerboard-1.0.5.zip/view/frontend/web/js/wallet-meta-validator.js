define([
    'ko',
    'Magento_Checkout/js/checkout-data',
    'Magento_Checkout/js/model/quote'
], function (
    ko,
    checkoutData,
    quote
) {
    var WalletMetaValidator = (function() {
        var instance;

        function init() {
            var walletMetaObservable = ko.observable(false);  
            var callback = null;  
            var subscription = null;

            function validateWalletMeta() {
                const inputFieldEmail = window.checkoutConfig.quoteData.customer_email || checkoutData.getInputFieldEmailValue() || "";
                if (!inputFieldEmail) {
                    walletMetaObservable(false);
                    return false;
                }

                const validatedEmailValue = window.checkoutConfig.quoteData.customer_email || checkoutData.getInputFieldEmailValue() || "";
                if (!validatedEmailValue) {
                    walletMetaObservable(false);
                    return false;
                }
                
                const address = quote.shippingAddress() || checkoutData.getShippingAddressFromData();
                if (!address) {
                    walletMetaObservable(false);
                    return false;
                }
                
                if (address.street.length === 0 || !address.street[0]) {
                    walletMetaObservable(false);
                    return false;
                }

                var selectedShippingMethod = quote.shippingMethod();

                if (!selectedShippingMethod) {

                    walletMetaObservable(false);
                    return false;
                }
                


                console.log(JSON.stringify({
                    firstName: address.firstname?.trim(),
                    lastName: address.lastname?.trim(),
                    street: address.street[0]?.trim(),
                    city: address.city?.trim(),
                    region: address.regionId?.trim() || address.region_id?.trim(),
                    postcode: address.postcode?.trim(),
                    countryId: address.countryId?.trim() || address.country_id?.trim(),
                    telephone: address.telephone?.trim(),
                    storeId: window.checkoutConfig.quoteData.store_id,
                    storeName: window.checkoutConfig.payment.paydockAfterPay.storeName,
                    currencyCode: window.checkoutConfig.quoteData.base_currency_code?.trim(),
                    inputEmail: inputFieldEmail?.trim(),
                    validatedEmail: validatedEmailValue?.trim(),
                    shippingMethod: selectedShippingMethod["method_code"]?.trim()
                }, null, 2));
                
                

                
                const hasAllRequiredValues = [
                    address.firstname?.trim(),
                    address.lastname?.trim(),
                    address.street[0]?.trim(),
                    address.city?.trim(),
                    address.regionId?.trim() || address.region_id?.trim(),
                    address.postcode?.trim(),
                    address.countryId?.trim() || address.country_id?.trim(),
                    address.telephone?.trim(),
                    window.checkoutConfig.quoteData.store_id,
                    window.checkoutConfig.payment.paydockAfterPay.storeName,
                    window.checkoutConfig.quoteData.base_currency_code?.trim(),
                    inputFieldEmail?.trim(),
                    validatedEmailValue?.trim(),
                    selectedShippingMethod["method_code"]?.trim()
                ].every(Boolean);


                
                if (hasAllRequiredValues) {
                    const isValid = [
                        address.firstname.trim(), 
                        address.lastname.trim(),
                        address.street[0]?.trim(), 
                        address.city.trim(),
                        address.regionId.trim() || address.region_id.trim(), 
                        address.postcode.trim(),
                        address.countryId.trim() || address.country_id.trim(), 
                        address.telephone.trim(),
                        inputFieldEmail.trim() === validatedEmailValue.trim(),
                        selectedShippingMethod["method_code"]?.trim()
                    ].every(value => value !== "" && value !== false); 

                    walletMetaObservable(isValid);
                    if (callback) {
                        callback(isValid);  
                    }
                    
                } else {
                    walletMetaObservable(false);
                    if (callback) {
                        callback(false);
                    }
                }
            }

            function subscribe() {
                subscription = walletMetaValidator.subscribe(function(newValue) {
                    if (callback) {
                        callback(newValue);
                    }
                });
            }

            function setCallback(newCallback) {
                callback = newCallback;
            }

            function dispose() {
                if (subscription) {
                    subscription.dispose();
                }
            }

            var walletMetaValidator = ko.computed(function() {
                return validateWalletMeta();
            });

            subscribe();

            return {
                setCallback: setCallback,
                dispose: dispose,
                walletMetaValidator: walletMetaValidator,  
                isValid: walletMetaObservable 
            };
        }

        return {
            getInstance: function() {
                if (!instance) {
                    instance = init();
                }
                return instance;
            }
        };
    })();

    return WalletMetaValidator;
});