define([
    'Magento_Customer/js/model/customer'
], function (customer) {
    'use strict';

    return {
        /**
         * @returns {String}
         */
        getCode: function() {
            return window.checkoutConfig.payment.paydockCreditCard.methodCode;
        },

        /**
         * @returns {String}
         */
        getEnvironment: function() {
            return window.checkoutConfig.payment.paydockCreditCard.environment ?? 'production_cba';
        },

        /**
         * @returns {Boolean}
         */
        isActive: function() {
            return window.checkoutConfig.payment.paydockCreditCard.isActive ?? true;
        },

        /**
         * @returns {Boolean}
         */
        canSaveCard: function() {
            return (customer && customer.isLoggedIn()) && (window.checkoutConfig.payment.paydockCreditCard.saveCard ?? false);
        },

        /**
         * @returns {Boolean}
         */
        is3ds: function() {
            return window.checkoutConfig.payment.paydockCreditCard.is3ds ?? false;
        },

        /**
         * @returns {*}
         */
        getInputCss: function() {
            return JSON.parse(window.checkoutConfig.payment.paydockCreditCard.cssInput || '{}');
        },

        /**
         * @returns {*}
         */
        getLabelCss: function() {
            return JSON.parse(window.checkoutConfig.payment.paydockCreditCard.cssLabel || '{}');
        },

        /**
         * @returns {*}
         */
        getButtonCss: function() {
            return JSON.parse(window.checkoutConfig.payment.paydockCreditCard.cssSubmit || '{}');
        },

        /**
         * @returns {*}
         */
        getCss: function() {
            return JSON.parse(window.checkoutConfig.payment.paydockCreditCard.css || '{}');
        },

        /**
         * @returns {String}
         */
        getPublicKey: function() {
            return window.checkoutConfig.payment.paydockCreditCard.publicKey;
        },

        /**
         * @returns {String}
         */
        getGatewayId: function () {
            return window.checkoutConfig.payment.paydockCreditCard.gatewayId;
        },
    };
});
