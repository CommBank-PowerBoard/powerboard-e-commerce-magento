define([
    "CartObserver",
    'jquery',
    'ko',
    'Magento_Checkout/js/action/select-payment-method',
    'Magento_Checkout/js/checkout-data',
    "Magento_Checkout/js/model/quote",
    'Magento_Checkout/js/view/payment/default',
    'Paydock_Powerboard/js/action/paypal',
    'WalletMetaValidator'
], function (cartObserver, $, ko, selectPaymentMethodAction, checkoutData, quote, paymentDefault, loadPaypalButtonAction, walletMetaValidator) {
    'use strict';

    return paymentDefault.extend({
        defaults: {
            template: 'Paydock_Powerboard/payment/paypal-form'
        },
      
        cartTotalPayPal: null,
        cartObserverInstancePayPal: null,
        isWalletMetaValidPayPal: null,
        widgetLoadedPayPal: false,
        walletMetaValidatorInstancePayPal: null,
        selectedPaymentMethodPayPal: null,
        /**
         * {@inheritdoc}
         */
        initialize: function() {
            this._super();
            
            var self = this;
            
            // Ensure each variable is specific to PayPal
            this.walletMetaValidatorInstancePayPal = walletMetaValidator.getInstance();
            this.isWalletMetaValidPayPal = this.walletMetaValidatorInstancePayPal.isValid; 
        
            this.cartObserverInstancePayPal = cartObserver.getInstance();

            // Observe changes in the selected payment method
            this.selectedPaymentMethodPayPal = ko.computed(function() {

                return checkoutData.getSelectedPaymentMethod(); 
            });

            this.selectedPaymentMethodPayPal.subscribe(function(newMethod) {

                if (newMethod === self.getCode()) {
                    self.cartObserverInstancePayPal.setCallback(self.cartObserverCallbackPayPal.bind(self));
                    self.walletMetaValidatorInstancePayPal.setCallback(self.walletMetaCallbackPayPal.bind(self));
                } 
            });

            // If this payment method is already selected, initialize observer immediately
            if (this.selectedPaymentMethodPayPal() === this.getCode()) {

                this.cartObserverInstancePayPal.setCallback(this.cartObserverCallbackPayPal.bind(this));
                this.walletMetaValidatorInstancePayPal.setCallback(this.walletMetaCallbackPayPal.bind(this));
            }
            
            if (checkoutData.getSelectedPaymentMethod() === this.getCode() && !this.widgetLoadedPayPal) {
                this.loadPayPalButton();
            }
        },

        walletMetaCallbackPayPal: function(isValid) {
            if (isValid && !this.widgetLoadedPayPal) {
                this.loadPayPalButton();
            }
        },

        cartObserverCallbackPayPal: function(newTotal) {
            this.cartTotalPayPal = newTotal;
            this.widgetLoadedPayPal = false;
            loadPaypalButtonAction(this.loadPayPalButtonCallback.bind(this));
        },

        loadPayPalButtonCallback: function(isLoaded) {
            this.widgetLoadedPayPal = isLoaded;

        },

        loadPayPalButton: function() {
            if (this.widgetLoadedPayPal || !this.isWalletMetaValidPayPal()) {

                return;
            }

            loadPaypalButtonAction(this.loadPayPalButtonCallback.bind(this));

        },

        /**
         * @returns {String}
         */
        getCode: function() {
            return this.item.method;
        },

        /**
         * @returns {String}
         */
        getLogoSrc: function() {
            return window.checkoutConfig.payment.paydockPaypal.logoSrc ?? '';
        },

        /**
         * @returns {Object}
         */
        getData: function() {
            return {
                'method': this.getCode(),
                'additional_data': {
                    'response_id': $('input[id="paypal-response-id"]').val()
                }
            };
        },

        isChecked: ko.computed(function() {
            return quote.paymentMethod() ? quote.paymentMethod().method : null;
        }),

        /**
         * @return {Boolean}
         */
        selectPaymentMethod: function() {

            selectPaymentMethodAction(this.getData());
            checkoutData.setSelectedPaymentMethod(this.getCode());

            
            if (!this.widgetLoadedPayPal) {
                setTimeout(() => {
                    this.loadPayPalButton();
                }, 1500);
            }
            return true;
        }
    });
});
