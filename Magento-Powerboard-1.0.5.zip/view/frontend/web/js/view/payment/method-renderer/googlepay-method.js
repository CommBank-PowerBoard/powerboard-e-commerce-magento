define([
    "Magento_Checkout/js/view/payment/default",
    "jquery",
    'ko',
    "Paydock_Powerboard/js/action/googlepay",
    "Magento_Checkout/js/action/select-payment-method",
    "Magento_Checkout/js/checkout-data",
    "Magento_Checkout/js/model/quote",
    "CartObserver",
    'WalletMetaValidator'
], function (
    paymentDefault,
    $,
    ko,
    loadGooglePayButtonAction,
    selectPaymentMethodAction,
    checkoutData,
    quote,  
    cartObserver,
    walletMetaValidator
) {
    "use strict";

    return paymentDefault.extend({
        defaults: {
            template: "Paydock_Powerboard/payment/googlepay-form",
        },

        cartTotalGooglePay: null,
        cartObserverInstanceGooglePay: null,
        selectedPaymentMethodGooglePay: null,
        isWalletMetaValidGooglePay: null,
        widgetLoadedGooglePay: false,
        walletMetaValidatorInstanceGooglePay: null,

        /**
         * {@inheritdoc}
         */
        initialize: function () {
            this._super();
            var self = this;

            this.walletMetaValidatorInstanceGooglePay = walletMetaValidator.getInstance();
            this.isWalletMetaValidGooglePay = this.walletMetaValidatorInstanceGooglePay.isValid; 
            
            this.cartObserverInstanceGooglePay = cartObserver.getInstance();

            // Observe changes in the selected payment method
            this.selectedPaymentMethodGooglePay = ko.computed(function() {

                return checkoutData.getSelectedPaymentMethod();
            });

            this.selectedPaymentMethodGooglePay.subscribe(function(newMethod) {

                if (newMethod === self.getCode()) {
                    self.cartObserverInstanceGooglePay.setCallback(self.cartObserverCallbackGooglePay.bind(self));
                    self.walletMetaValidatorInstanceGooglePay.setCallback(self.walletMetaCallbackGooglePay.bind(self));
                } 
            });

            // If this payment method is already selected, initialize observer immediately
            if (this.selectedPaymentMethodGooglePay() === this.getCode()) {

                this.cartObserverInstanceGooglePay.setCallback(this.cartObserverCallbackGooglePay.bind(this));
                this.walletMetaValidatorInstanceGooglePay.setCallback(this.walletMetaCallbackGooglePay.bind(this));
            }
            
            if (checkoutData.getSelectedPaymentMethod() === this.getCode() && !this.widgetLoadedGooglePay) {
                this.loadGooglePayButton();
            }
        },

        walletMetaCallbackGooglePay: function(isValid) {
            if (isValid && !this.widgetLoadedGooglePay) {
                this.loadGooglePayButton();
            }
        },

        cartObserverCallbackGooglePay: function(newTotal) {
            this.cartTotalGooglePay = newTotal;
            this.widgetLoadedGooglePay = false;
            this.loadGooglePayButton();
        },

        /**
         * Create Google pay widget
         */
        loadGooglePayButton: function () {
            if (this.widgetLoadedGooglePay || !this.isWalletMetaValidGooglePay()) {
                return;
            }

            loadGooglePayButtonAction();
            this.widgetLoadedGooglePay = true;
        },

        isChecked: ko.computed(function() {
            return quote.paymentMethod() ? quote.paymentMethod().method : null;
        }),

        /**
         * @returns {String}
         */
        getCode: function () {
            return this.item.method;
        },

        /**
         * @returns {String}
         */
        getLogoSrc: function () {
            return window.checkoutConfig.payment.paydockGooglePay.logoSrc ?? "";
        },

        /**
         * @returns {Object}
         */
        getData: function () {
            return {
                method: this.getCode(),
                additional_data: {
                    response_id: $('input[id="googlepay-response-id"]').val(),
                },
            };
        },

        /**
         * @return {Boolean}
         */
        selectPaymentMethod: function () {

            selectPaymentMethodAction(this.getData());
            checkoutData.setSelectedPaymentMethod(this.getCode());


            if (!this.widgetLoadedGooglePay) {
                setTimeout(() => {
                    this.loadGooglePayButton();
                }, 1500);
            }

            return true;
        },
    });
});
