define([
    "Magento_Checkout/js/view/payment/default",
    "jquery",
    "ko",
    "Magento_Checkout/js/model/quote",
    "Paydock_Powerboard_Widget",
    "Magento_Checkout/js/checkout-data",
    "Magento_Checkout/js/action/select-payment-method",
    "Magento_Checkout/js/model/totals",
    "CartObserver",
    'WalletMetaValidator'
], function (
    Component,
    $,
    ko,
    quote,
    cba,
    checkoutData,
    selectPaymentMethodAction,
    totals,
    cartObserver,
    walletMetaValidator
) {
    "use strict";

    return Component.extend({
        defaults: {
            template: "Paydock_Powerboard/payment/zipmoney-form",
        },
        buttonZipMoney: null,

        cartTotalZipMoney: null,
        cartObserverInstanceZipMoney: null,
        widgetLoadedZipMoney: false,
        isWalletMetaValidZipMoney: false,
        selectedPaymentMethodZipMoney: null,
        walletMetaValidatorInstance: null,
        
        /**
         * {@inheritdoc}
         */
        initialize: function () {
            this._super();
            var self = this;
            
            this.cartTotalZipMoney = totals.getSegment("grand_total") ? totals.getSegment("grand_total").value : 0;

            this.selectedPaymentMethodZipMoney = ko.computed(function () {
                return quote.paymentMethod() ? quote.paymentMethod().method : null;
            }, this);

            this.cartObserverInstanceZipMoney = cartObserver.getInstance();
            
            this.walletMetaValidatorInstanceZipMoney = walletMetaValidator.getInstance();
            this.isWalletMetaValidZipMoney = this.walletMetaValidatorInstanceZipMoney.isValid; 
            
            if (this.selectedPaymentMethodZipMoney() === this.getCode()) {
                this.cartObserverInstanceZipMoney.setCallback(this.cartObserverCallbackZipMoney.bind(this));
                this.walletMetaValidatorInstanceZipMoney.setCallback(this.walletMetaCallbackZipMoney.bind(this));
            }
            
            this.selectedPaymentMethodZipMoney.subscribe(function (newMethod) {
                if (newMethod === self.getCode()) {
                    self.cartObserverInstanceZipMoney.setCallback(self.cartObserverCallbackZipMoney.bind(self));
                    self.walletMetaValidatorInstanceZipMoney.setCallback(self.walletMetaCallbackZipMoney.bind(self));
                } 
            });
        },

        walletMetaCallbackZipMoney: function (isValid) {
            if(isValid) {
                this.setMeta();
            }
        },

        cartObserverCallbackZipMoney: function (newTotal) {

            this.cartTotalZipMoney = newTotal;
            this.setMeta();
        },

        /**
         * Load the zip button
         */
        loadZipMoneyButton: function () { 
            if (this.widgetLoadedZipMoney || !this.isWalletMetaValidZipMoney()) {

                return;
            }

            let gatewayId = window.checkoutConfig.payment.paydockZipMoney.gatewayId,
                publicKey = window.checkoutConfig.payment.paydockCreditCard.publicKey

            if (typeof publicKey === "undefined" || publicKey.trim() === "") {
                console.error("Error loading widget - no public key defined");
                return;
            }

            this.buttonZipMoney = new cba.ZipmoneyCheckoutButton(
                "#zipmoney-checkout-button",
                publicKey,
                gatewayId
            );
            this.buttonZipMoney.setEnv(this.getEnvironment());
            this.buttonZipMoney.onFinishInsert(
                'input[id="zipmoney-checkout-button-payment-source-token"]',
                "payment_source_token"
            );
            
            this.setMeta();

            this.buttonZipMoney.on("finish", (data) => {
                this.paydockPlaceOrder();
            });

            this.widgetLoadedZipMoney = true;
            return;
        },
        
        setMeta: function() {
            if(!this.buttonZipMoney) { return }
            

            
            let shippingAddress = quote.shippingAddress(),
                billingAddress = quote.billingAddress(),
                currency = window.checkoutConfig.quoteData.base_currency_code;
                
            this.buttonZipMoney.setMeta({
                first_name: shippingAddress.firstname,
                tokenize: true,
                last_name: shippingAddress.lastname,
                email:
                    quote.guestEmail ??
                    window.checkoutConfig.quoteData.customer_email,
                gender: "",
                charge: {
                    amount: this.cartTotalZipMoney,
                    currency: currency,
                    shipping_type: "delivery",
                    shipping_address: {
                        first_name: shippingAddress.firstname,
                        last_name: shippingAddress.lastname,
                        line1: shippingAddress.street[0] ?? "",
                        line2: shippingAddress.street[1] ?? "",
                        country: shippingAddress.countryId,
                        postcode: shippingAddress.postcode,
                        city: shippingAddress.city,
                        state: shippingAddress.region,
                    },
                    billing_address: {
                        first_name: billingAddress.firstname,
                        last_name: billingAddress.lastname,
                        line1: billingAddress.street[0] ?? "",
                        line2: billingAddress.street[1] ?? "",
                        country: billingAddress.countryId,
                        postcode: billingAddress.postcode,
                        city: billingAddress.city,
                        state: billingAddress.region,
                    },
                    items: this.getCartItems(),
                },
                statistics: {
                    account_created: "",
                    sales_total_number: "",
                    sales_total_amount: "",
                    sales_avg_value: "",
                    sales_max_value: "",
                    refunds_total_amount: "",
                    previous_chargeback: "",
                    currency: currency,
                    last_login: "",
                },
            });
        },
        
        /**
         * @returns {*}
         */
        getCartItems: function () {
            let quoteItems = quote.getItems(),
                cartItems = [];

            for (let i = 0; i < quoteItems.length; i++) {
                cartItems.push({
                    name: quoteItems[i]["name"],
                    amount: quoteItems[i]["row_total"],
                    quantity: quoteItems[i]["qty"],
                    reference: quoteItems[i]["description"],
                });
            }

            return cartItems;
        },

        /**
         * @returns {String}
         */
        getCode: function () {
            return this.item.method;
        },

        /**
         * @returns {String}
         */
        getEnvironment: function () {
            return (
                window.checkoutConfig.payment.paydockCreditCard.environment ??
                "production_cba"
            );
        },

        /**
         * @returns {String}
         */
        getLogoSrc: function () {
            return window.checkoutConfig.payment.paydockZipMoney.logoSrc ?? "";
        },

        /**
         * @return {Boolean}
         */
        selectPaymentMethod: function () {

            selectPaymentMethodAction(this.getData());
            checkoutData.setSelectedPaymentMethod(this.item.method);
            
            if (!this.widgetLoadedZipMoney && this.isWalletMetaValidZipMoney()) {
                this.loadZipMoneyButton();
            }
            
            return true;
        },

        /**
         * Place ZipMoney order
         */
        paydockPlaceOrder: function () {
            var currentTotal = totals.getSegment("grand_total") ? totals.getSegment("grand_total").value : 0;
            var quoteTotal = this.getQuoteTotal();


            
            $("#paydock-zipmoney-place-token-order").click();
            return;
        },

        /**
         * @returns {Object}
         */
        getData: function () {
            return {
                method: this.item.method,
                additional_data: {
                    payment_token: $(
                        'input[id="zipmoney-checkout-button-payment-source-token"]'
                    ).val(),
                },
            };
        },
    });
});
