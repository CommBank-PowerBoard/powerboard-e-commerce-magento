<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Observer\Adminhtml;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Paydock\Powerboard\Api\Data\PaydockCreditCardInterface;
use Paydock\Powerboard\Api\CreditCardConfigurationManagementInterface;

class DisablePaymentMethodInAdmin implements ObserverInterface
{
    /**
     * @var CreditCardConfigurationManagementInterface
     */
    private CreditCardConfigurationManagementInterface $creditCardConfigurationManagement;

    /**
     * @param CreditCardConfigurationManagementInterface $creditCardConfigurationManagement
     */
    public function __construct(
        CreditCardConfigurationManagementInterface $creditCardConfigurationManagement
    ) {
        $this->creditCardConfigurationManagement = $creditCardConfigurationManagement;
    }

    /**
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer): void
    {
        $resultObject = $observer->getResult();

        if (!$resultObject->getData('is_available')) {
            return;
        }

        if ($this->creditCardConfigurationManagement->isBackendOrder()) {
            return;
        }

        $methodInstance = $observer->getMethodInstance();
        if ($methodInstance?->getCode() === PaydockCreditCardInterface::METHOD_CODE) {
            $resultObject->setData('is_available', false);
        }
    }
}
