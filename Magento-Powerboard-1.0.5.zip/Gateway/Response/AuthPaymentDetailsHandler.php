<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway\Response;

use Magento\Payment\Gateway\Response\HandlerInterface;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use Paydock\Powerboard\Gateway\Helper\SubjectReader;

class AuthPaymentDetailsHandler implements HandlerInterface
{
    /**
     * @var SubjectReader
     */
    private SubjectReader $subjectReader;

    /**
     * @param SubjectReader $subjectReader
     */
    public function __construct(
        SubjectReader $subjectReader
    ) {
        $this->subjectReader = $subjectReader;
    }

    /**
     * @inheritdoc
     */
    public function handle(array $handlingSubject, array $response)
    {
        $paymentDO = $this->subjectReader->readPayment($handlingSubject);

        /** @var OrderPaymentInterface $payment */
        $payment = $paymentDO->getPayment();

        $payment->setCcTransId($response['data']['_id']);
        $payment->setLastTransId($response['data']['_id']);
    }
}
