<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway\Http\Client;

use Magento\Framework\Exception\LocalizedException;

class DirectCaptureTransactionSale extends AbstractTransaction
{
    /**
     * @inheritdoc
     * @throws LocalizedException
     */
    protected function process(array $data): array
    {
        $payment = $data['payment'] ?? '';
        $token = $data['token'] ?? '';

        if ($token === null) {
            throw new LocalizedException(__('Unable to proceed. Token is empty.'));
        }

        if ($payment === null) {
            throw new LocalizedException(__('Unable to proceed. Payment is empty.'));
        }

        return $this->chargesService->directCapture($payment->getOrder(), $token);
    }
}
