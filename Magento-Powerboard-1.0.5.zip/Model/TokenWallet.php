<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Quote\Model\MaskedQuoteIdToQuoteIdInterface;
use Magento\Quote\Model\QuoteRepository;
use Paydock\Powerboard\Api\ChargesServiceInterface;
use Paydock\Powerboard\Api\TokenWalletInterface;
use Psr\Log\LoggerInterface;

class TokenWallet implements TokenWalletInterface
{
    /**
     * @var ChargesServiceInterface
     */
    private ChargesServiceInterface $chargesService;

    /**
     * @var MaskedQuoteIdToQuoteIdInterface
     */
    private MaskedQuoteIdToQuoteIdInterface $maskedQuoteIdToQuoteId;

    /**
     * @var LoggerInterface
     */
    private LoggerInterface $logger;

    /**
     * @var Json
     */
    private Json $json;

     /**
     * @var QuoteRepository
     */
    private QuoteRepository $quoteRepository;

    /**
     * @param ChargesServiceInterface $chargesService
     * @param LoggerInterface $logger
     * @param Json $json
     * @param QuoteRepository $quoteRepository
     * @param MaskedQuoteIdToQuoteIdInterface $maskedQuoteIdToQuoteId
     */
    public function __construct(
        ChargesServiceInterface $chargesService,
        LoggerInterface $logger,
        Json $json,
        QuoteRepository $quoteRepository,
        MaskedQuoteIdToQuoteIdInterface $maskedQuoteIdToQuoteId
    ) {
        $this->chargesService = $chargesService;
        $this->logger = $logger;
        $this->json = $json;
        $this->quoteRepository = $quoteRepository;
        $this->maskedQuoteIdToQuoteId = $maskedQuoteIdToQuoteId;
    }

    /**
     * @inheritDoc
     */
    public function generateWalletToken(string $cartId): string|bool
    {
        try {
            if (!is_numeric($cartId)) {
                $cartId = $this->maskedQuoteIdToQuoteId->execute($cartId);
            }
            if (!is_numeric($cartId)) {
                $response = ['success' => false, 'token_wallet' => '', 'error' => 'Quote id is not valid'];
                return $this->json->serialize($response);
            }
            $quote = $this->quoteRepository->get($cartId);
            $response = ['success' => true, 'token_wallet' => '', 'error' => ''];
            // TODO: validate if the cart is valid
            // Check if cart still active and with payment method selected
            if (!$quote->getPayment() || !$quote->getPayment()->getMethod()) {
                $response['success'] = false;
                $response['error'] = 'No payment method selected';
            }

            if (!$quote->getIsActive()) {
                $response['success'] = false;
                $response['error'] .= 'Cart is not active';
            }

            if ($response['success']) {
                $tokenWallet = $this->chargesService->getWalletToken($quote);
                if (isset($tokenWallet['token']) && !empty($tokenWallet['token'])) {
                    $response = ['success' => true, 'token_wallet' => $tokenWallet['token'], 'error' => '', 'charge_id' => $tokenWallet['charge']['_id']];
                } else {
                    $this->logger->critical(__("Wallet charge token not returned for %1 %2", $cartId, json_encode($tokenWallet)));
                    $response = ['success' => false, 'token_wallet' => '', 'error' => 'Quote not found'];
                }
            }
        } catch(NoSuchEntityException $e) {
            $this->logger->critical(__("Quote %1 is not found: %2", $cartId, $e->getMessage()));
            $response = ['success' => false, 'token_wallet' => '', 'error' => 'Quote not found'];
        } catch (LocalizedException $e) {
            $this->logger->critical(__("Quote get wallet token error for %1: %2", $cartId, $e->getMessage()));
            $response = ['success' => false, 'token_wallet' => '', 'error' => $e->getMessage()];
        }
        
        return $this->json->serialize($response);
    }
}

