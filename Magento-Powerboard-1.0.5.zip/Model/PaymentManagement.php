<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model;

use Magento\Quote\Model\Quote;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use Paydock\Powerboard\Api\PaymentManagementInterface;

class PaymentManagement implements PaymentManagementInterface
{
    /**
     * @var CreditCardConfigurationManagement
     */
    private CreditCardConfigurationManagement $creditCardConfigurationManagement;

    /**
     * @param CreditCardConfigurationManagement $creditCardConfigurationManagement
     */
    public function __construct(
        CreditCardConfigurationManagement $creditCardConfigurationManagement
    ) {
        $this->creditCardConfigurationManagement = $creditCardConfigurationManagement;
    }

    /**
     * @inheritDoc
     */
    public function canSaveCard(OrderPaymentInterface|Quote $payment): bool
    {
        if (!$this->creditCardConfigurationManagement->canSaveCard()) {
            return false;
        }

        if ($payment instanceof OrderPaymentInterface) {
            $saveCard = $payment->getAdditionalInformation('cc_save') ?? false;
            if (!$saveCard) {
                return false;
            }

            $order = $payment->getOrder();
            if (!$order || !$order->getCustomerId()) {
                return false;
            }
        }

        if ($payment instanceof Quote) {
            if (!$payment->getCustomerId()) {
                return false;
            }
        }

        return true;
    }

    /**
     * @inheritDoc
     */
    public function isPaymentSources(OrderPaymentInterface|Quote $payment): bool
    {
        if ($payment instanceof OrderPaymentInterface) {
            $paymentSourceId = $payment->getAdditionalInformation('payment_source_id') ?? false;
            if (!$paymentSourceId) {
                return false;
            }

            $order = $payment->getOrder();
            if (!$order || !$order->getCustomerId()) {
                return false;
            }
        }

        if ($payment instanceof Quote) {
            if (!$payment->getCustomerId()) {
                return false;
            }
        }

        return true;
    }
}

