<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model\Config;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Payment\Helper\Data as PaymentHelper;
use Magento\Payment\Model\MethodInterface;
use Paydock\Powerboard\Api\ApplePayConfigurationManagementInterface;
use Paydock\Powerboard\Api\Data\PaydockApplePayInterface;
use Magento\Framework\View\Asset\Repository;
use Magento\Framework\View\Asset\Source;
use Magento\Payment\Model\CcConfig;

class ApplePayConfigProvider implements ConfigProviderInterface
{
    /**
     * @var string
     */
    protected string $methodCode = PaydockApplePayInterface::METHOD_CODE;

    /**
     * @var MethodInterface
     */
    protected MethodInterface $method;

    /**
     * @var ApplePayConfigurationManagementInterface
     */
    private ApplePayConfigurationManagementInterface $applePayConfigurationManagement;

    /**
     * @var Repository
     */
    private Repository $assetRepo;

    /**
     * @var Source
     */
    private Source $assetSource;

    /**
     * @var CcConfig
     */
    private CcConfig $ccConfig;

    /**
     * @param PaymentHelper $paymentHelper
     * @param ApplePayConfigurationManagementInterface $applePayConfigurationManagement
     * @param Repository $assetRepo
     * @param Source $assetSource
     * @param CcConfig $ccConfig
     * @throws LocalizedException
     */
    public function __construct(
        PaymentHelper $paymentHelper,
        ApplePayConfigurationManagementInterface $applePayConfigurationManagement,
        Repository $assetRepo,
        Source $assetSource,
        CcConfig $ccConfig
    ) {
        $this->method = $paymentHelper->getMethodInstance($this->methodCode);
        $this->applePayConfigurationManagement = $applePayConfigurationManagement;
        $this->assetRepo = $assetRepo;
        $this->assetSource = $assetSource;
        $this->ccConfig = $ccConfig;
    }

    /**
     * @inheritDoc
     */
    public function getConfig(): array
    {
        return [
            'payment' => [
                'paydockApplePay' => [
                    'active' => $this->applePayConfigurationManagement->isActive(),
                    'title' => $this->applePayConfigurationManagement->getTitle(),
                    'logoSrc' => $this->getLogoSrc()
                ]
            ]
        ];
    }

     /**
     * @return string
     */
    public function getLogoSrc(): string
    {
        $src = '';
        $asset = $this->ccConfig->createAsset('Paydock_Powerboard::images/applepay.svg');
        if ($asset) {
            $placeholder = $this->assetSource->findSource($asset);
            if ($placeholder) {
                $src = $asset->getUrl();
            }
        }
        return $src;
    }
}

