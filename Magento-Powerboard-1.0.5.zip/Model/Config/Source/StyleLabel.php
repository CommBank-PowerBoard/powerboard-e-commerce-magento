<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model\Config\Source;

class StyleLabel implements \Magento\Framework\Data\OptionSourceInterface
{
    private const PAYPAL = 'paypal';
    private const CHECKOUT = 'checkout';
    private const BUYNOW = 'buynow';
    private const PAY = 'pay';

    /**
     * @return array
     */
    public function toOptionArray(): array
    {
        return [
            [
                'value' => self::PAYPAL,
                'label' => __('PayPal')
            ],
            [
                'value' => self::CHECKOUT,
                'label' => __('Checkout')
            ],
            [
                'value' => self::BUYNOW,
                'label' => __('Buy Now')
            ],
            [
                'value' => self::PAY,
                'label' => __('Pay with')
            ]
        ];
    }
}
