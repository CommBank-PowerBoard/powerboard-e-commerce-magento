<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model\Config\Source;

class StyleLayout implements \Magento\Framework\Data\OptionSourceInterface
{
    private const HORIZONTAL = 'horizontal';
    private const VERTICAL = 'vertical';

    /**
     * @return array
     */
    public function toOptionArray(): array
    {
        return [
            [
                'value' => self::VERTICAL,
                'label' => __('Vertical')
            ],
            [
                'value' => self::HORIZONTAL,
                'label' => __('Horizontal')
            ]
        ];
    }
}
