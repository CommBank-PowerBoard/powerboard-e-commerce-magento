<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model\Config\Source;

class StyleColor implements \Magento\Framework\Data\OptionSourceInterface
{
    private const GOLD = 'gold';
    private const BLUE = 'blue';
    private const SILVER = 'silver';
    private const BLACK = 'black';
    private const WHITE = 'white';

    /**
     * @return array
     */
    public function toOptionArray(): array
    {
        return [
            [
                'value' => self::GOLD,
                'label' => __('Gold')
            ],
            [
                'value' => self::BLUE,
                'label' => __('Blue')
            ],
            [
                'value' => self::SILVER,
                'label' => __('Silver')
            ],
            [
                'value' => self::BLACK,
                'label' => __('Black')
            ],
            [
                'value' => self::WHITE,
                'label' => __('White')
            ]
        ];
    }
}
