<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model\Config;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\View\Asset\Source;
use Magento\Payment\Helper\Data as PaymentHelper;
use Magento\Payment\Model\CcConfig;
use Magento\Payment\Model\MethodInterface;
use Paydock\Powerboard\Api\ConfigurationManagementInterface;
use Paydock\Powerboard\Api\CreditCardConfigurationManagementInterface;
use Paydock\Powerboard\Api\Data\PaydockCreditCardInterface;
use Magento\Framework\View\Asset\Repository;

class CreditCardConfigProvider implements ConfigProviderInterface
{
    /**
     * @var string
     */
    protected string $methodCode = PaydockCreditCardInterface::METHOD_CODE;

    /**
     * @var MethodInterface
     */
    protected MethodInterface $method;

    /**
     * @var ConfigurationManagementInterface
     */
    private ConfigurationManagementInterface $configurationManagement;

    /**
     * @var CreditCardConfigurationManagementInterface
     */
    private CreditCardConfigurationManagementInterface $creditCardConfigurationManagement;

    /**
     * @var CcConfig
     */
    private CcConfig $ccConfig;

    /**
     * @var Source
     */
    private Source $assetSource;

    /**
     * @var Repository
     */
    private Repository $assetRepo;

    /**
     * @var array
     */
    private array $icons = [];

    /**
     * @param PaymentHelper $paymentHelper
     * @param ConfigurationManagementInterface $configurationManagement
     * @param CreditCardConfigurationManagementInterface $creditCardConfigurationManagement
     * @param CcConfig $ccConfig
     * @param Source $assetSource
     * @param Repository $assetRepo
     * @throws LocalizedException
     */
    public function __construct(
        PaymentHelper $paymentHelper,
        ConfigurationManagementInterface $configurationManagement,
        CreditCardConfigurationManagementInterface $creditCardConfigurationManagement,
        CcConfig $ccConfig,
        Source $assetSource,
        Repository $assetRepo
    ) {
        $this->method = $paymentHelper->getMethodInstance($this->methodCode);
        $this->configurationManagement = $configurationManagement;
        $this->creditCardConfigurationManagement = $creditCardConfigurationManagement;
        $this->ccConfig = $ccConfig;
        $this->assetSource = $assetSource;
        $this->assetRepo = $assetRepo;
        $this->ccConfig = $ccConfig;
    }

    /**
     * @inheritDoc
     */
    public function getConfig(): array
    {
        return [
            'payment' => [
                'paydockCreditCard' => [
                    'active' => $this->creditCardConfigurationManagement->isActive(),
                    'methodCode' => $this->methodCode,
                    'environment' => $this->configurationManagement->getEnvironment(),
                    'css' => $this->configurationManagement->getCss(),
                    'cssInput' => $this->creditCardConfigurationManagement->getCssInput(),
                    'cssLabel' => $this->creditCardConfigurationManagement->getCssLabel(),
                    'cssSubmit' => $this->creditCardConfigurationManagement->getCssSubmitButton(),
                    'cssBackendInput' => $this->creditCardConfigurationManagement->getBackendCssInput(),
                    'cssBackendLabel' => $this->creditCardConfigurationManagement->getBackendCssLabel(),
                    'saveCard' => $this->creditCardConfigurationManagement->canSaveCard(),
                    'is3ds' => $this->creditCardConfigurationManagement->is3DS(),
                    'publicKey' => $this->configurationManagement->getPublicKey(),
                    'gatewayId' => $this->creditCardConfigurationManagement->getGatewayId(),
                    'availableCardTypes' => $this->creditCardConfigurationManagement->getAvailableCardTypes(),
                    'icons' => $this->getIcons(),
                    'logoSrc' => $this->getLogoSrc()
                ]
            ]
        ];
    }

    /**
     * Get icons for available payment methods
     *
     * @return array
     */
    public function getIcons(): array
    {
        if (!empty($this->icons)) {
            return $this->icons;
        }

        $types = $this->ccConfig->getCcAvailableTypes();
        $types['NONE'] = '';

        foreach (array_keys($types) as $code) {
            if (!array_key_exists($code, $this->icons)) {
                $asset = $this->ccConfig->createAsset('Paydock_Powerboard::images/cc/' . strtoupper($code) . '.png');

                if ($asset) {
                    $placeholder = $this->assetSource->findSource($asset);
                    if ($placeholder) {
                        list($width, $height) = getimagesizefromstring($asset->getSourceFile());
                        $this->icons[$code] = [
                            'url' => $asset->getUrl(),
                            'width' => $width,
                            'height' => $height
                        ];
                    }
                }
            }
        }

        return $this->icons;
    }

    /**
     * @return string
     */
    public function getLogoSrc(): string
    {
        $src = '';
        $asset = $this->ccConfig->createAsset('Paydock_Powerboard::images/cc.svg');
        if ($asset) {
            $placeholder = $this->assetSource->findSource($asset);
            if ($placeholder) {
                $src = $asset->getUrl();
            }
        }
        return $src;
    }
}

