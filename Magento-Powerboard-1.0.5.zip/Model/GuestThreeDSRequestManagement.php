<?php
/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model;

use Magento\Framework\Exception\LocalizedException;
use Magento\Quote\Model\QuoteIdMaskFactory;
use Magento\Quote\Model\ResourceModel\Quote\QuoteIdMask as QuoteIdMaskResourceModel;
use Paydock\Powerboard\Api\GuestThreeDSRequestManagementInterface;
use Paydock\Powerboard\Api\ThreeDSRequestManagementInterface;

class GuestThreeDSRequestManagement implements GuestThreeDSRequestManagementInterface
{
    /**
     * @var ThreeDSRequestManagementInterface
     */
    private ThreeDSRequestManagementInterface $threeDSRequestManagement;

    /**
     * @var QuoteIdMaskFactory
     */
    private QuoteIdMaskFactory $quoteIdMaskFactory;

    /**
     * @var QuoteIdMaskResourceModel
     */
    private QuoteIdMaskResourceModel $quoteIdMaskResourceModel;

    /**
     * @param QuoteIdMaskFactory $quoteIdMaskFactory
     * @param QuoteIdMaskResourceModel $quoteIdMaskResourceModel
     * @param ThreeDSRequestManagementInterface $threeDSRequestManagement
     */
    public function __construct(
        QuoteIdMaskFactory $quoteIdMaskFactory,
        QuoteIdMaskResourceModel $quoteIdMaskResourceModel,
        ThreeDSRequestManagementInterface $threeDSRequestManagement
    ) {
        $this->quoteIdMaskFactory = $quoteIdMaskFactory;
        $this->quoteIdMaskResourceModel = $quoteIdMaskResourceModel;
        $this->threeDSRequestManagement = $threeDSRequestManagement;
    }

    /**
     * @inheritDoc
     * @throws LocalizedException
     */
    public function place3dsPreAuthRequest(string $paymentToken, string $cartId, mixed $browserDetails): ?string
    {
        $quoteIdMask = $this->quoteIdMaskFactory->create();
        $this->quoteIdMaskResourceModel->load($quoteIdMask, $cartId, 'masked_id');
        
        return $this->threeDSRequestManagement->place3dsPreAuthRequest(
            $paymentToken,
            $quoteIdMask->getData('quote_id'),
            $browserDetails
        );
    }
}

