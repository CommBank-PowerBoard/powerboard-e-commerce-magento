<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Model;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Model\QuoteRepository;
use Paydock\Powerboard\Api\ChargesServiceInterface;
use Paydock\Powerboard\Api\PaymentManagementInterface;
use Paydock\Powerboard\Api\PaymentSourceServiceInterface;
use Paydock\Powerboard\Api\ThreeDSRequestManagementInterface;
use Paydock\Powerboard\Api\CustomersServiceInterface;
use Paydock\Powerboard\Model\Command\GatewayCommand;
use Psr\Log\LoggerInterface;
use Magento\Framework\Webapi\Rest\Request;
use Paydock\Powerboard\Helper\QuoteHelper;
use Paydock\Powerboard\Logger\PaydockLogger;
use Magento\Quote\Model\QuoteIdMaskFactory;
use Magento\Quote\Model\ResourceModel\Quote\QuoteIdMask as QuoteIdMaskResourceModel;

class ThreeDSRequestManagement implements ThreeDSRequestManagementInterface {
    /**
     * @var Request
     */
    private Request $request;

    /**
     * @var PaymentSourceServiceInterface
     */
    private PaymentSourceServiceInterface $paymentSourceService;

    /**
     * @var ChargesServiceInterface
     */
    private ChargesServiceInterface $chargesService;

    /**
     * @var LoggerInterface
     */
    private LoggerInterface $logger;

    /**
     * @var QuoteRepository
     */
    private QuoteRepository $quoteRepository;

    /**
     * @var CustomerRepositoryInterface
     */
    private CustomerRepositoryInterface $customerRepository;

    /**
     * @var PaymentManagementInterface
     */
    private PaymentManagementInterface $paymentManagement;

    /**
     * @var CustomersServiceInterface
     */
    private CustomersServiceInterface $customersService;

    /**
     * @var QuoteHelper
     */
    private QuoteHelper $quoteHelper;

    protected PaydockLogger $paydockLogger;

    /**
     * @var QuoteIdMaskFactory
     */
    private QuoteIdMaskFactory $quoteIdMaskFactory;

    /**
     * @var QuoteIdMaskResourceModel
     */
    private QuoteIdMaskResourceModel $quoteIdMaskResourceModel;

    /**
     * @param Request $request
     * @param PaymentSourceServiceInterface $paymentSourceService
     * @param ChargesServiceInterface $chargesService
     * @param LoggerInterface $logger
     * @param QuoteRepository $quoteRepository
     * @param CustomerRepositoryInterface $customerRepository
     * @param PaymentManagementInterface $paymentManagement
     * @param QuoteHelper $quoteHelper
     * @param PaydockLogger $paydockLogger
     * @param QuoteIdMaskFactory $quoteIdMaskFactory,
     *  @param QuoteIdMaskResourceModel $quoteIdMaskResourceModel,
     */
    public function __construct(
        Request $request,
        PaymentSourceServiceInterface $paymentSourceService,
        ChargesServiceInterface $chargesService,
        LoggerInterface $logger,
        QuoteRepository $quoteRepository,
        CustomerRepositoryInterface $customerRepository,
        PaymentManagementInterface $paymentManagement,
        CustomersServiceInterface $customersService,
        QuoteHelper $quoteHelper,
        PaydockLogger $paydockLogger,
        QuoteIdMaskFactory $quoteIdMaskFactory,
        QuoteIdMaskResourceModel $quoteIdMaskResourceModel
    ) {
        $this->request = $request;
        $this->paymentSourceService = $paymentSourceService;
        $this->chargesService = $chargesService;
        $this->logger = $logger;
        $this->quoteRepository = $quoteRepository;
        $this->customerRepository = $customerRepository;
        $this->paymentManagement = $paymentManagement;
        $this->customersService = $customersService;
        $this->quoteHelper = $quoteHelper;
        $this->paydockLogger = $paydockLogger;
        $this->quoteIdMaskFactory = $quoteIdMaskFactory;
        $this->quoteIdMaskResourceModel = $quoteIdMaskResourceModel;
    }

    /**
     * @inheritDoc
     */
    public function place3dsPreAuthRequest(string $paymentToken, string $cartId): ?string {
        $this->paydockLogger->info('ThreeDSRequestManagement::place3dsPreAuthRequest', ['cartId' => $cartId]);

        try {
            // Try to treat as customer cart first
            $quote = $this->quoteRepository->get($cartId);
        } catch (NoSuchEntityException $e) {
            // Try to treat as guest cart
            try {
                $quoteIdMask = $this->quoteIdMaskFactory->create()->load($cartId, 'masked_id');
                $quote = $this->quoteRepository->get($quoteIdMask->getQuoteId());
            } catch (NoSuchEntityException $e) {
                $this->logger->critical(__('Unable to find quote for cart ID %1', $cartId));
                throw new LocalizedException(__(GatewayCommand::GENERIC_ERROR));
            }
        }

        $payload = $this->request->getBodyParams();
        $ccSave = $payload['cc_save'] ?? null;
        $browserDetails = $payload['browser_details'] ?? null;
        $isPaymentSource = $payload['is_payment_source'] ?? null;

        $guestCustomer = (bool)$quote->getCustomerIsGuest();
        $loggedInCustomer = !$guestCustomer;

        $payment = $quote->getPayment();

        $this->paydockLogger->info('ThreeDSRequestManagement::place3dsPreAuthRequest', [
            'payload' => $payload,
            'ccSave' => $ccSave,
            'ccSave' => $ccSave,
            'browserDetails' => $browserDetails,
            'isPaymentSource' => $isPaymentSource,
            'guestCustomer' => $guestCustomer,
            'loggedInCustomer' => $loggedInCustomer,
            'paymentToken' => $paymentToken,
        ]);

        if ($isPaymentSource && $loggedInCustomer) {
            $vaultToken = $this->quoteHelper->getVaultFromPaydockPaymentSources($paymentToken);
            $payment->setAdditionalInformation('vault_token', $vaultToken);
        }

        if ($loggedInCustomer && !$isPaymentSource) {
            $vaultToken = $ccSave ? $this->getPermanentToken($paymentToken) : $this->getSessionToken($paymentToken);

            $payment->setAdditionalInformation('vault_token', $vaultToken);
        }


        if ($guestCustomer) {
            $vaultToken = $this->getSessionToken($paymentToken);
        }



        if ($vaultToken === null) {
            $this->logger->critical(__("Error generating vault token"));
            throw new LocalizedException(__(GatewayCommand::GENERIC_ERROR));
        }

        try {
            $response = $this->chargesService->place3dsPreAuthRequest($quote, $vaultToken, $browserDetails);
            $token3ds = $response ? $response['data']['_3ds']['token'] : null;
            $chargeId3ds = $response ? $response['data']['_3ds']['id'] : null;
            $this->quoteHelper->updatePaydockHistory(['3ds_token_generated_id' => $chargeId3ds]);
            $this->quoteRepository->save($quote);
        } catch (LocalizedException | CouldNotSaveException $e) {
            $this->logger->critical(__("Error generating 3ds token: %1", $e->getMessage()));
            throw new LocalizedException(__(GatewayCommand::GENERIC_ERROR));
        }

        return $token3ds;
    }

    /**
     * @param string $paymentToken
     * @return string|null
     */
    private function getSessionToken(string $paymentToken): ?string {
        try {
            return $this->paymentSourceService->getSessionToken($paymentToken);
        } catch (LocalizedException $e) {
            $this->logger->critical(__("Error generating session token: %1", $e->getMessage()));
            return null;
        }
    }

    /**
     * @param string $paymentToken
     * @return string|null
     */
    private function getPermanentToken(string $paymentToken): ?string {
        try {
            return $this->paymentSourceService->getPermanentToken($paymentToken);
        } catch (LocalizedException $e) {
            $this->logger->critical(__("Error generating permanent token: %1", $e->getMessage()));
            return null;
        }
    }
}
