<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway\Request;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Payment\Gateway\Request\BuilderInterface;
use Magento\Payment\Gateway\Data\OrderAdapterInterface as OrderOA;
use Magento\Quote\Model\QuoteRepository;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use Paydock\Powerboard\Api\PaymentManagementInterface;
use Paydock\Powerboard\Api\PaymentSourceServiceInterface;
use Paydock\Powerboard\Gateway\Data\Order\OrderAdapter;
use Paydock\Powerboard\Gateway\Helper\SubjectReader;
use Psr\Log\LoggerInterface;
use Paydock\Powerboard\Logger\PaydockLogger;
use Paydock\Powerboard\Helper\QuoteHelper;

class ChargeDataBuilder implements BuilderInterface {
    /**
     * @var SubjectReader
     */
    private SubjectReader $subjectReader;

    /**
     * @var PaymentSourceServiceInterface
     */
    private PaymentSourceServiceInterface $paymentSourceService;

    /**
     * @var QuoteRepository
     */
    private QuoteRepository $quoteRepository;

    /**
     * @var PaymentManagementInterface
     */
    private PaymentManagementInterface $paymentManagement;

    /**
     * @var LoggerInterface
     */
    private LoggerInterface $logger;

    /**
     * @var PaydockLogger
     */
    private PaydockLogger $paydockLogger;

    /**
     * @var QuoteHelper
     */
    private QuoteHelper $quoteHelper;

    /**
     * Constructor
     *
     * @param SubjectReader $subjectReader
     * @param PaymentSourceServiceInterface $paymentSourceService
     * @param QuoteRepository $quoteRepository
     * @param PaymentManagementInterface $paymentManagement
     * @param LoggerInterface $logger
     * @param PaydockLogger $paydockLogger;
     * @param QuoteHelper $quoteHelper
     */
    public function __construct(SubjectReader $subjectReader, PaymentSourceServiceInterface $paymentSourceService, QuoteRepository $quoteRepository, PaymentManagementInterface $paymentManagement, LoggerInterface $logger, PaydockLogger $paydockLogger, QuoteHelper $quoteHelper) {
        $this->subjectReader = $subjectReader;
        $this->paymentSourceService = $paymentSourceService;
        $this->quoteRepository = $quoteRepository;
        $this->paymentManagement = $paymentManagement;
        $this->logger = $logger;
        $this->paydockLogger = $paydockLogger;
        $this->quoteHelper = $quoteHelper;
    }

    /**
     * @inheritdoc
     * @throws LocalizedException
     */
    public function build(array $buildSubject): array {
        $orderPayment = $this->subjectReader->readPayment($buildSubject);
        $payment = $orderPayment->getPayment();
        $order = $orderPayment->getOrder();

        $data = [
            'payment' => $payment,
            'save_card' => (bool)$payment->getAdditionalInformation('cc_save') ?? false
        ];

        $quote = $this->getQuote($order);

        $additionalInfo = $payment->getAdditionalInformation();
        $this->paydockLogger->info('ChargeDataBuilder::build ' . json_encode([
            'additionalInfo' => $additionalInfo ?? null
        ]));

        $paymentSourceId = $additionalInfo['payment_source_id'] ?? null;
        $paymentToken = $additionalInfo['payment_token'] ?? null;
        $charge3dsId = $additionalInfo['charge_3ds_id'] ?? null;
        $vaultToken = $additionalInfo['vault_token'] ?? null;

        if ($this->isMissingRequiredData($paymentSourceId, $paymentToken, $charge3dsId, $vaultToken)) {
            $this->paydockLogger->info('ChargeDataBuilder::build payment_source_id, payment_token, charge_3ds_id, vaultToken are empty');
            throw new LocalizedException(__('Something went wrong with your request, please try again.'));
        }

        if ($charge3dsId) {
            return $this->handleCharge3ds($data, $vaultToken, $charge3dsId);
        }

        $vaultToken = $this->resolveVaultToken($paymentSourceId, $paymentToken, $payment);

        if (!$vaultToken) {
            throw new LocalizedException(__('Something went wrong with your request, please try again.'));
        }

        $data['vault_token'] = $vaultToken;
        return $data;
    }

    private function getQuote(OrderAdapter $order) {
        try {
            return $this->quoteRepository->get($order->getQuoteId());
        } catch (NoSuchEntityException $e) {
            throw new LocalizedException(__('Quote not found.'), $e);
        }
    }

    private function isMissingRequiredData($paymentSourceId, $paymentToken, $charge3dsId, $vaultToken): bool {
        return $paymentSourceId === null && $paymentToken === null && $charge3dsId === null && $vaultToken === null;
    }

    private function handleCharge3ds(array $data, $vaultToken, $charge3dsId): array {
        $data['charge_3ds_id'] = $charge3dsId;
        $data['vault_token'] = $vaultToken;
        $this->paydockLogger->info('ChargeDataBuilder::build $charge3dsId', [
            '$data[charge_3ds_id]' => $data['charge_3ds_id']
        ]);
        return $data;
    }

    private function resolveVaultToken($paymentSourceId, $paymentToken, $payment) {
        if ($paymentSourceId) {
            return $this->quoteHelper->getVaultFromPaydockPaymentSources($paymentSourceId);
        }

        if ($paymentToken) {
            return $this->paymentManagement->canSaveCard($payment)
                ? $this->getPermanentToken($paymentToken)
                : $this->getSessionToken($paymentToken);
        }

        return null;
    }

    /**
     * @param string $paymentToken
     * @return string|null
     */
    private function getSessionToken(string $paymentToken): ?string {
        try {
            return $this->paymentSourceService->getSessionToken($paymentToken);
        } catch (LocalizedException $e) {
            $this->logger->critical(__("Error generating session token: %1", $e->getMessage()));
            return null;
        }
    }

    /**
     * @param string $paymentToken
     * @return string|null
     */
    private function getPermanentToken(string $paymentToken): ?string {
        try {
            return $this->paymentSourceService->getPermanentToken($paymentToken);
        } catch (LocalizedException $e) {
            $this->logger->critical(__("Error generating permanent token: %1", $e->getMessage()));
            return null;
        }
    }
}
