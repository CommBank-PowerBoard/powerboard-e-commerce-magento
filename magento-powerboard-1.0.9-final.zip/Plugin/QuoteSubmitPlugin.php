<?php

namespace Paydock\Powerboard\Plugin;

use Exception;
use Magento\Quote\Model\QuoteManagement;
use Magento\Quote\Model\Quote;
use Magento\Framework\Serialize\SerializerInterface;
use Paydock\Powerboard\Logger\PaydockLogger;
use Paydock\Powerboard\Gateway\ChargesService;
use Psr\Log\LoggerInterface;
use Paydock\Powerboard\Helper\QuoteHelper;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Paydock\Powerboard\Model\ConfigurationManagement;

class QuoteSubmitPlugin {
    private $serializer;
    private $paydockLogger;
    protected $quoteHelper;
    private $chargesService;
    private $logger;
    private $scopeConfig;
    private $configurationManagement;

    public function __construct(
        SerializerInterface $serializer,
        PaydockLogger $paydockLogger,
        QuoteHelper $quoteHelper,
        ChargesService $chargesService,
        LoggerInterface $logger,
        ScopeConfigInterface $scopeConfig,
        ConfigurationManagement $configurationManagement
    ) {
        $this->serializer = $serializer;
        $this->paydockLogger = $paydockLogger;
        $this->quoteHelper = $quoteHelper;
        $this->chargesService = $chargesService;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->configurationManagement = $configurationManagement;
    }

    public function aroundSubmit(QuoteManagement $subject, callable $proceed, Quote $quote) {
        try {
            $paymentMethod = $quote->getPayment()->getMethod();

            $this->paydockLogger->info('QuoteSubmitPlugin::aroundSubmit BEGIN', ['quote_id' => $quote->getId(), 'shippingMethod' => $quote->getShippingAddress()->getShippingMethod(), 'paymentMethod' => $paymentMethod]);

            $isWalletPayment = $this->quoteHelper->isWalletPayment();
            if ($isWalletPayment) {
                $this->validateWalletPayment($quote);
            }



            return $proceed($quote);
        } catch (\Exception $e) {

            $this->paydockLogger->info('QuoteSubmitPlugin::aroundSubmit exception', ['message' => $e->getMessage()]);

            if ($this->configurationManagement->enableAutoRefund() && $this->quoteHelper->isWalletPayment()) {
                $additionalInfo = $quote->getPayment()->getAdditionalInformation();

                $chargeId = $additionalInfo['response_id'];
                $storeId = $quote->getStoreId();
                if ($chargeId) {
                    $this->paydockLogger->info('QuoteSubmitPlugin::aroundSubmit performing auto refund', ['charge_id' => $chargeId, 'storeId' => $storeId]);
                    $this->chargesService->placeRefund($chargeId, 0, true, $storeId);
                    $this->quoteHelper->updatePaydockHistory(['refund' => $chargeId]);
                    throw new LocalizedException(__('The shipping method is missing. You have been refunded. Select the shipping method and try again.'));
                }
            }

            throw $e;
        }
    }

    private function validateWalletPayment(Quote $quote) {
        try {
            $this->paydockLogger->info('QuoteSubmitPlugin::aroundSubmit Performing Quote wallet validation for quote ID: ' . $quote->getId());

            $walletChargeVerified = $this->chargesService->verifyWalletCharge();
            $this->paydockLogger->info('QuoteSubmitPlugin::aroundSubmit walletChargeVerified: ' . $walletChargeVerified);
            if (!$walletChargeVerified) {
                $this->paydockLogger->info('QuoteSubmitPlugin::aroundSubmit Quote wallet validation failed for quote ID: ' . $quote->getId());
                throw new LocalizedException(__('Sorry, there has been an error processing your request. Please try again later.'));
            }
            $cartDataChanged = $this->quoteHelper->hasCartDataChanged();
            if ($cartDataChanged) {
                $this->paydockLogger->info('cart data changed ' .  $cartDataChanged);
                $this->quoteHelper->revertCartData();
            }
        } catch (\Exception $e) {
            $this->paydockLogger->error('QuoteSubmitPlugin::aroundSubmit Error during quote wallet validation: ' . $e->getMessage());
            throw new LocalizedException(__('Sorry, there has been an error processing your request. Please try again later.'));
        }
    }
}
