<?php

namespace Paydock\Powerboard\Helper;

use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Checkout\Model\Session;
use Magento\Framework\Serialize\SerializerInterface;
use Paydock\Powerboard\Logger\PaydockLogger;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Quote\Model\Quote;

class QuoteHelper {
    protected $productRepository;
    protected $quoteRepository;
    protected $checkoutSession;
    protected $serializer;
    protected $paydockLogger;

    public function __construct(
        ProductRepositoryInterface $productRepository,
        CartRepositoryInterface $quoteRepository,
        Session $checkoutSession,
        SerializerInterface $serializer,
        PaydockLogger $paydockLogger
    ) {
        $this->productRepository = $productRepository;
        $this->quoteRepository = $quoteRepository;
        $this->checkoutSession = $checkoutSession;
        $this->serializer = $serializer;
        $this->paydockLogger = $paydockLogger;
    }

    public function updatePaydockHistory(array $action) {
        $quote = $this->checkoutSession->getQuote();
        $this->paydockLogger->info('Update Paydock history.', ['quote_id' => $quote->getId()]);

        $existingData = $quote->getData('paydock_history');
        $paydockHistory = [];

        if (!empty($existingData)) {
            try {
                $paydockHistory = $this->serializer->unserialize($existingData);
            } catch (\Exception $e) {
                $this->paydockLogger->error('Failed to unserialize paydock_history', ['error' => $e->getMessage()]);
            }
        }

        array_push($paydockHistory, $action);

        $serializedData = $this->serializer->serialize($paydockHistory);
        $quote->setData('paydock_history', $serializedData);
        $quote->setCustomAttribute('paydock_history', $serializedData);

        $this->quoteRepository->save($quote);
        $this->paydockLogger->info('Paydock history saved successfully.', ['filtered_data' => $paydockHistory]);
    }


    public function isWalletPayment(): bool {
        $quote = $this->checkoutSession->getQuote();
        $paymentMethod = $quote->getPayment()->getMethod();
        $validPaymentMethods = ["paydock_applepay", "paydock_googlepay", "paydock_paypal", "paydock_afterpay"];
        return in_array($paymentMethod, $validPaymentMethods);
    }

    public function refreshWalletToken(Quote $quote) {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $paydockLogger = $objectManager->get(\Paydock\Powerboard\Logger\PaydockLogger::class);
        $chargeService = $objectManager->get(\Paydock\Powerboard\Gateway\ChargesService::class);

        $paydockLogger->info("QuoteHelper::refreshWalletToken");


        if (!$this->isWalletPayment()) {
            $paydockLogger->info("QuoteHelper::refreshWalletToken is not wallet payment, not abandoning token");
            return;
        }

        $token = $chargeService->getWalletToken($quote);

        $paydockLogger->info('QuoteHelper::refreshWalletToken token: ' . print_r($token, true));
    }


    public function clearPaydockWalletData() {
        $quote = $this->checkoutSession->getQuote();
        $this->paydockLogger->info('Clearing Paydock wallet data.', ['quote_id' => $quote->getId()]);

        $quote->setData('paydock_wallet_data', null);
        $quote->setCustomAttribute('paydock_wallet_data', null);

        $this->quoteRepository->save($quote);
        $this->paydockLogger->info('Paydock wallet data cleared successfully.');
    }

    public function savePaydockWalletData($walletData) {
        $quote = $this->checkoutSession->getQuote();
        $this->paydockLogger->info('Saving Paydock wallet data.', ['quote_id' => $quote->getId(), 'wallet_data' => $walletData]);

        // Extract only the required fields
        $filteredData = [
            'charge_id' => $walletData['charge']['_id'] ?? null,
            'amount' => $walletData['charge']['amount'] ?? null,
            'reference' => $walletData['charge']['reference'] ?? null,
            'company_id' => $walletData['charge']['company_id'] ?? null,
            'gateway_id' => $walletData['charge']['customer']['payment_source']['gateway_id'] ?? null,
            'data' => $walletData
        ];

        $serializedData = $this->serializer->serialize($filteredData);
        $quote->setData('paydock_wallet_data', $serializedData);
        $quote->setCustomAttribute('paydock_wallet_data', $serializedData);

        $this->quoteRepository->save($quote);
        $this->paydockLogger->info('Paydock wallet data saved successfully.', ['filtered_data' => $filteredData]);
    }

    public function savePaydockPaymentSources($paymentSources) {
        $quote = $this->checkoutSession->getQuote();
        $this->paydockLogger->info('Saving Paydock payment sources data.', ['quote_id' => $quote->getId()]);

        $serializedData = $this->serializer->serialize($paymentSources);
        $quote->setData('paydock_stored_payment_sources', $serializedData);
        $quote->setCustomAttribute('paydock_stored_payment_sources', $serializedData);

        $this->quoteRepository->save($quote);
        $this->paydockLogger->info('Paydock payment sources data saved successfully.');
    }

    public function getVaultFromPaydockPaymentSources(string $paymentSourceId): ?string {
        $paymentSources = $this->getPaydockPaymentSources();

        $vaultToken = $paymentSources[$paymentSourceId] ?? null;

        $this->paydockLogger->info('QuoteHelper::getVaultFromPaydockPaymentSources', [
            'paymentSourceId' => $paymentSourceId
        ]);

        return $vaultToken;
    }

    private function getPaydockPaymentSources(): array {
        $quote = $this->checkoutSession->getQuote();
        $paymentSourcesJson = $quote->getData('paydock_stored_payment_sources');

        $this->paydockLogger->info('QuoteHelper::getPaydockPaymentSources', [
            'quote_id' => $quote->getId()
        ]);

        return json_decode($paymentSourcesJson, true) ?? [];
    }

    public function clearPaydockPaymentSources() {
        $this->paydockLogger->info('Clear Paydock Payment Sources data.');

        $quote = $this->checkoutSession->getQuote();
        $quote->setData('paydock_stored_payment_sources', NULL);
        $quote->setCustomAttribute('paydock_stored_payment_sources', NULL);
        $this->quoteRepository->save($quote);

        $this->paydockLogger->info('Cleared Paydock Payment Sources data.');
    }

    public function getPaydockWalletData() {
        $quote = $this->checkoutSession->getQuote();
        $walletData = $quote->getData('paydock_wallet_data');
        $this->paydockLogger->info('Get Paydock wallet data.', ['quote_id' => $quote->getId(), 'wallet_data' => $walletData]);

        return $walletData;
    }

    public function getPaydockCartData() {
        $quote = $this->checkoutSession->getQuote();

        $cartData = $quote->getData('paydock_cart_data');
        $this->paydockLogger->info('Get Paydock cart data.', ['quote_id' => $quote->getId(), 'cart_data' => $cartData]);

        return $cartData;
    }

    public function savePaydockCartData() {
        $quote = $this->checkoutSession->getQuote();
        $this->paydockLogger->info('Saving Paydock cart data.', ['quote_id' => $quote->getId()]);

        $cartData = [
            'items' => [],
            'total_price' => $quote->getGrandTotal(),
            'shipping_method' => $quote->getShippingAddress()->getShippingMethod(),
            'shipping_price' => $quote->getShippingAddress()->getShippingAmount(),
            'payment_method' => $quote->getPayment()->getMethod()
        ];

        foreach ($quote->getAllVisibleItems() as $item) {
            $cartData['items'][] = [
                'sku' => $item->getSku(),
                'price' => $item->getPrice(),
                'qty' => (int) $item->getQty(),
                'total_price' => $item->getRowTotal(),
            ];
        }

        $this->paydockLogger->info('Cart data compiled.', ['cart_data' => $cartData]);

        $serializedData = $this->serializer->serialize($cartData);
        $quote->setData('paydock_cart_data', $serializedData);
        $quote->setCustomAttribute('paydock_cart_data', $serializedData);

        $this->quoteRepository->save($quote);
        $this->paydockLogger->info('Paydock cart data saved successfully.');
    }

    public function hasCartDataChanged() {
        $quote = $this->checkoutSession->getQuote();
        $this->paydockLogger->info('Checking for Paydock cart data changes.', ['quote_id' => $quote->getId()]);

        $savedData = $quote->getData('paydock_cart_data');
        if (!$savedData) {
            $this->paydockLogger->info('No saved cart data found.');
            return true;
        }

        $currentCartData = [
            'items' => [],
            'total_price' => (float) $quote->getGrandTotal(),
            'shipping_method' => $quote->getShippingAddress()->getShippingMethod(),
            'shipping_price' => (float) $quote->getShippingAddress()->getShippingAmount(),
            'payment_method' => $quote->getPayment()->getMethod()
        ];
        $this->paydockLogger->info('Current cart data initialized.', ['current_cart_data' => $currentCartData]);

        foreach ($quote->getAllVisibleItems() as $item) {
            $itemData = [
                'sku' => $item->getSku(),
                'price' => (float) $item->getPrice(),
                'qty' => (int) $item->getQty(),
                'total_price' => (float) $item->getRowTotal(),
            ];
            $currentCartData['items'][] = $itemData;
            $this->paydockLogger->info('Added item to current cart data.', ['item_data' => $itemData]);
        }

        $savedCartData = $this->serializer->unserialize($savedData);
        $savedCartData['total_price'] = (float) $savedCartData['total_price'];
        $savedCartData['shipping_price'] = (float) $savedCartData['shipping_price'];

        foreach ($savedCartData['items'] as &$item) {
            $item['price'] = (float) $item['price'];
            $item['total_price'] = (float) $item['total_price'];
        }

        $this->paydockLogger->info('Saved cart data processed for comparison.', ['saved_cart_data' => $savedCartData]);

        $hasChanged = $currentCartData !== $savedCartData;
        $this->paydockLogger->info('Cart data comparison completed.', [
            'has_changed' => $hasChanged,
            'current_cart_data' => $currentCartData,
            'saved_cart_data' => $savedCartData,
        ]);

        return $hasChanged;
    }




    public function revertCartData() {
        $quote = $this->checkoutSession->getQuote();
        $this->paydockLogger->info('Reverting Paydock cart data.', ['quote_id' => $quote->getId()]);

        $serializedData = $quote->getData('paydock_cart_data');

        if (!$serializedData) {
            $this->paydockLogger->warning('No Paydock cart data found to revert.');
            return;
        }

        $cartData = $this->serializer->unserialize($serializedData);

        // Get current cart items
        $currentItems = [];
        foreach ($quote->getAllVisibleItems() as $item) {
            $currentItems[$item->getSku()] = $item;
        }

        // Restore or update items
        foreach ($cartData['items'] as $itemData) {
            $sku = $itemData['sku'];
            $newQty = (int)$itemData['qty'];

            if (isset($currentItems[$sku])) {
                // Item exists in cart, update quantity if different
                $existingItem = $currentItems[$sku];
                if ((int)$existingItem->getQty() !== $newQty) {
                    $existingItem->setQty($newQty);
                }
                unset($currentItems[$sku]); // Mark as processed
            } else {
                // Item is missing, add it
                $product = $this->productRepository->get($sku);
                $quoteItem = $quote->addProduct($product, $newQty);
                if ($quoteItem) {
                    $quoteItem->setCustomPrice($itemData['price']);
                    $quoteItem->setOriginalCustomPrice($itemData['price']);
                    $quoteItem->getProduct()->setIsSuperMode(true);
                }
            }
        }

        // Remove items that were not in the saved cart data
        foreach ($currentItems as $unusedItem) {
            $quote->removeItem($unusedItem->getItemId());
        }

        // Restore totals
        $quote->getShippingAddress()->setShippingMethod($cartData['shipping_method']);
        $quote->getShippingAddress()->setShippingAmount($cartData['shipping_price']);
        $quote->setTotalsCollectedFlag(false)->collectTotals();

        $this->quoteRepository->save($quote);
        $this->paydockLogger->info('Paydock cart data reverted successfully.');
    }
}
