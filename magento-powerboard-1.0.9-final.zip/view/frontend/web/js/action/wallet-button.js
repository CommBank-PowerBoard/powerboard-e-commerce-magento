define(['jquery', 'Paydock_Powerboard/js/model/error-handler', 'Magento_Checkout/js/model/full-screen-loader', 'Paydock_Powerboard_Widget', 'Paydock_Powerboard/js/action/get-wallet-token'], function ($, errorHandler, fullScreenLoader, cba, getWalletToken) {
	'use strict'

	var buttonInstances = {}
	var environment = window.checkoutConfig.payment.paydockCreditCard.environment ?? 'staging_cba'

	var initializeWalletButton = function (selector, payload, config, force = false) {
		if (buttonInstances[selector] && buttonInstances[selector].button) {
			buttonInstances[selector].button = null
			$(selector).empty()
		}

		buttonInstances[selector] = {selector, payload, config}

		fullScreenLoader.startLoader()

		getWalletToken(force)
			.then((result) => {
				if (result.success) {
					if (buttonInstances[selector].button !== undefined) return

					let button = new cba.WalletButtons(selector, result.token_wallet, payload)

					button.setEnv(environment)

					button.onUnavailable((() => console.error(`No wallet buttons available for ${selector}`)).bind(this))

					button.onPaymentSuccessful(
						((response) => {
							fullScreenLoader.startLoader()
							if (response.data?.id) {
								$(config.tokenSelector).val(response.data?.id)
								$(config.placeOrderSelector).click()
							}
						}).bind(this)
					)

					button.onPaymentError(
						((response) => {
							if (response?.data?.error === 'Access forbidden' || response?.data?.message === 'Access forbidden') {
								refreshWalletToken(selector, true)
							}
						}).bind(this)
					)

					button.onUpdate(
						((data) => {
							setTimeout(function () {
								button.update({success: true, body: {}})
							}, 3000)
						}).bind(this)
					)
					buttonInstances[selector].button = button
					buttonInstances[selector].button.load()
				} else {
					throw result.error
				}
			})
			.catch((error) => {
				errorHandler.process(error)
			})
			.finally(() => {
				fullScreenLoader.stopLoader()
			})
	}

	var refreshWalletToken = function (selector, force = false) {
		if (!buttonInstances[selector]) {
			console.error(`No wallet button initialized for ${selector}`)
			return
		}

		initializeWalletButton(buttonInstances[selector].selector, buttonInstances[selector].payload, buttonInstances[selector].config, force)
	}

	var isInitialized = function (selector) {
		return buttonInstances[selector] && buttonInstances[selector].button
	}

	return {
		initialize: initializeWalletButton,
		refresh: refreshWalletToken,
		isInitialized: isInitialized
	}
})
