define(['Magento_Checkout/js/model/url-builder', 'mage/storage', 'Magento_Checkout/js/model/full-screen-loader'], function (urlBuilder, storage, fullScreenLoader) {
	'use strict'

	return async function getPaymentSources(paydockCustomerId) {
		fullScreenLoader.startLoader()

		let serviceUrl = urlBuilder.createUrl('/paydock/customer/:paydockCustomerId/payment-source', {
			paydockCustomerId: paydockCustomerId
		})

		try {
			const response = await storage.get(serviceUrl, false)
			const result = JSON.parse(response)
			return result
		} catch (error) {
			throw new Error(error)
		} finally {
			fullScreenLoader.stopLoader()
		}
	}
})
