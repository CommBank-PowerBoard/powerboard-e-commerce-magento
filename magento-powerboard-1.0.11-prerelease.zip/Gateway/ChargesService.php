<?php

/**
 * @author Paydock
 * @copyright Copyright (c) 2023-present Paydock (https://paydock.com/)
 * @package Powerboard for Magento 2
 */

declare(strict_types=1);

namespace Paydock\Powerboard\Gateway;

use Magento\Framework\App\Area;
use Magento\Framework\App\State;
use Magento\Backend\Model\Session\Quote as SessionQuote;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Model\Quote;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Checkout\Model\Session as CheckoutSession;
use Paydock\Powerboard\Api\ChargesServiceInterface;
use Paydock\Powerboard\Api\ConfigurationManagementInterface;
use Paydock\Powerboard\Api\CreditCardConfigurationManagementInterface;
use Paydock\Powerboard\Api\Data\PaydockCustomerInterface;
use Paydock\Powerboard\Api\GatewayServiceInterface;
use Paydock\Powerboard\Api\PaymentManagementInterface;
use Paydock\Powerboard\Helper\QuoteHelper;
use Psr\Log\LoggerInterface;
use Paydock\Powerboard\Helper\StoreHelper;
use Paydock\Powerboard\Logger\PaydockLogger;
use Magento\Framework\Serialize\SerializerInterface;

class ChargesService implements ChargesServiceInterface {
    /**
     * @var SerializerInterface
     */
    private $serializer;

    /**
     * @var GatewayServiceInterface
     */
    private GatewayServiceInterface $gatewayService;

    /**
     * @var ConfigurationManagementInterface
     */
    private ConfigurationManagementInterface $configurationManagement;

    /**
     * @var StoreManagerInterface
     */
    private StoreManagerInterface $storeManager;

    /**
     * @var CreditCardConfigurationManagementInterface
     */
    private CreditCardConfigurationManagementInterface $creditCardConfigurationManagement;

    /**
     * @var CustomerRepositoryInterface
     */
    private CustomerRepositoryInterface $customerRepository;

    /**
     * @var CheckoutSession
     */
    protected $checkoutSession;

    /**
     * @var SessionQuote
     */
    protected $sessionQuote;

    /**
     * @var PaymentManagementInterface
     */
    private PaymentManagementInterface $paymentManagement;

    /**
     * @var State
     */
    private State $state;

    /**
     * @var LoggerInterface
     */
    private LoggerInterface $logger;

    /**
     * @var PaydockLogger
     */
    private PaydockLogger $paydockLogger;

    /**
     * @var QuoteHelper
     */
    private QuoteHelper $quoteHelper;

    /**
     * @param GatewayServiceInterface $gatewayService
     * @param ConfigurationManagementInterface $configurationManagement
     * @param StoreManagerInterface $storeManager
     * @param CreditCardConfigurationManagementInterface $creditCardConfigurationManagement
     * @param CustomerRepositoryInterface $customerRepository
     * @param PaymentManagementInterface $paymentManagement
     */
    public function __construct(
        State $state,
        GatewayServiceInterface $gatewayService,
        ConfigurationManagementInterface $configurationManagement,
        StoreManagerInterface $storeManager,
        CheckoutSession $checkoutSession,
        SessionQuote $sessionQuote,
        CreditCardConfigurationManagementInterface $creditCardConfigurationManagement,
        CustomerRepositoryInterface $customerRepository,
        PaymentManagementInterface $paymentManagement,
        LoggerInterface $logger,
        PaydockLogger $paydockLogger,
        QuoteHelper $quoteHelper,
        SerializerInterface $serializer
    ) {
        $this->state = $state;
        $this->gatewayService = $gatewayService;
        $this->configurationManagement = $configurationManagement;
        $this->storeManager = $storeManager;
        $this->checkoutSession = $checkoutSession;
        $this->creditCardConfigurationManagement = $creditCardConfigurationManagement;
        $this->customerRepository = $customerRepository;
        $this->paymentManagement = $paymentManagement;
        $this->logger = $logger;
        $this->paydockLogger = $paydockLogger;
        $this->sessionQuote = $sessionQuote;
        $this->quoteHelper = $quoteHelper;
        $this->serializer = $serializer;
    }

    /**
     * @param array $chargePayload
     * @return string
     * @throws LocalizedException
     */
    private function preAuthorise(array $chargePayload): string {
        $endpoint = self::ENDPOINT_PREAUTH;
        $response = $this->gatewayService->post($endpoint, $chargePayload);

        if ($response === null) {
            throw new LocalizedException(__("Error placing pre-authorisation request"));
        }

        $chargeId = $response['data']['_id'] ?? '';
        if (trim($chargeId) === '') {
            throw new LocalizedException(__("Error placing pre-authorisation request - no charge ID found in response"));
        }

        return $chargeId;
    }

    /**
     * @inheritDoc
     * @throws LocalizedException
     */
    public function preAuthoriseWithVaultToken(OrderInterface $order, string $vaultToken): string {
        $chargePayload = $this->buildChargePayload($order, $vaultToken);
        return $this->preAuthorise($chargePayload);
    }

    /**
     * @inheritDoc
     * @throws LocalizedException
     */
    public function preAuthoriseWith3dsChargeId(OrderInterface $order, string $charge3dsId): string {
        $payload = $this->buildChargePayload3ds($order, $charge3dsId);
        return $this->preAuthorise($payload);
    }

    /**
     * @inheritDoc
     * @throws LocalizedException
     */
    public function capture(string $chargeId): array {
        $endpoint = sprintf(self::ENDPOINT_CAPTURE, $chargeId);
        $response = $this->gatewayService->post($endpoint);

        if ($response === null) {
            throw new LocalizedException(__("Error placing capture request"));
        }

        return $response;
    }

    /**
     * @inheritDoc
     * @throws LocalizedException
     */
    public function directCapture(OrderInterface $order, string $token): array {
        $endpoint = sprintf(self::ENDPOINT_DIRECT_CAPTURE, $token);
        $directCapturePayload = $this->buildDirectCapturePayload($order, $token);
        $response = $this->gatewayService->post($endpoint, $directCapturePayload);

        if ($response === null) {
            throw new LocalizedException(__("Error placing direct capture request"));
        }

        return $response;
    }

    /**
     * @param OrderInterface $order
     * @param string $token
     * @return array
     */
    private function buildDirectCapturePayload(OrderInterface $order, string $token): array {
        return [
            'amount' => $order->getBaseGrandTotal(),
            'currency' => $order->getBaseCurrencyCode(),
            'token' => $token,
            'reference' => $this->getReservedOrderId()
        ];
    }

    /**
     * @inheritDoc
     * @throws LocalizedException
     */
    public function place3dsPreAuthRequest(Quote $quote, string $vaultToken, array $browserDetails): array {
        $endpoint = self::ENDPOINT_CHARGES_3DS;
        $charge3dsPayload = $this->build3dsChargePayload($quote, $vaultToken, $browserDetails);
        $response = $this->gatewayService->post($endpoint, $charge3dsPayload);

        if ($response === null) {
            throw new LocalizedException(__('Error getting 3ds token'));
        }

        if (!isset($response['data'])) {
            throw new LocalizedException(__('Error placing 3ds charge. Response returns empty data'));
        }

        if (!isset($response['data']['_3ds']['token'])) {
            throw new LocalizedException(__('No 3ds token found'));
        }

        return $response;
    }

    /**
     * @param Quote $quote
     * @param string $vaultToken
     * @param array $browserDetails
     * @return array
     */
    private function build3dsChargePayload(Quote $quote, string $vaultToken, array $browserDetails): array {
        return [
            'amount' => $quote->getGrandTotal(),
            'currency' => $quote->getBaseCurrencyCode(),
            'reference' => $this->getReservedOrderId(),
            "customer" => [
                'payment_source' => [
                    'vault_token' => $vaultToken,
                    'gateway_id' => $this->creditCardConfigurationManagement->getGatewayId()
                ]
            ],
            '_3ds' => [
                'browser_details' => [
                    'name' => $browserDetails['name'] ?? '',
                    'java_enabled' => $browserDetails['java_enabled'] ?? '',
                    'language' => $browserDetails['language'] ?? '',
                    'screen_height' => $browserDetails['screen_height'] ?? '',
                    'screen_width' => $browserDetails['screen_width'] ?? '',
                    'time_zone' => $browserDetails['time_zone'] ?? '',
                    'color_depth' => $browserDetails['color_depth'] ?? ''
                ]
            ]
        ];
    }

    /**
     * @inheritDoc
     * @throws LocalizedException
     */
    public function getWalletToken(Quote $quote, bool $force = false): array {
        $this->paydockLogger->info('ChargeService::getWalletToken', ['force' => $force]);

        $previousPaydockWalletDataSerialized = $this->quoteHelper->getPaydockWalletData();
        if ($previousPaydockWalletDataSerialized) {
            $previousPaydockWalletData = $this->serializer->unserialize($previousPaydockWalletDataSerialized);
            if ($previousPaydockWalletData['charge_id'] != null) {
                $cartDataChanged = $this->quoteHelper->hasCartDataChanged();
                $this->paydockLogger->info('ChargeService::getWalletToken:', ['cartDataChanged' => $cartDataChanged]);
                if ($cartDataChanged) {
                    $this->paydockLogger->info('ChargeService::getWalletToken::cartDataChanged', ['previousPaydockWalletData' => $previousPaydockWalletData['charge_id']]);
                    $this->paydockLogger->info('ChargeService::getWalletToken::cartDataChanged calling abandon wallet');
                    $walletAbandoned = $this->abandonWallet();
                    $this->paydockLogger->info('ChargeService::getWalletToken', ['walletAbandoned' => $walletAbandoned]);
                } else {
                    $this->paydockLogger->info('ChargeService::getWalletToken returning old wallet token');
                    if (!$force) {
                        return $previousPaydockWalletData['data'];
                    } else {
                        $this->paydockLogger->info('ChargeService::getWalletToken forcing new token');
                        $this->paydockLogger->info('ChargeService::getWalletToken calling abandon wallet');
                        $walletAbandoned = $this->abandonWallet();
                        $this->paydockLogger->info('ChargeService::getWalletToken', ['walletAbandoned' => $walletAbandoned]);
                    }
                }
            }
        }

        $endpoint = self::ENDPOINT_CHARGES_WALLET;
        $chargeWalletPayload = $this->buildWalletChargePayload($quote);

        if (!empty($chargeWalletPayload)) {
            $response = $this->gatewayService->post($endpoint, $chargeWalletPayload);
        } else {
            throw new LocalizedException(__('Error missing gateway ID for Wallet token'));
        }

        if ($response === null) {
            throw new LocalizedException(__('Error getting Wallet token'));
        }

        if (!isset($response['data'])) {
            throw new LocalizedException(__('Error placing Wallet charge. Response returns empty data'));
        }

        if (!isset($response['data']['token'])) {
            throw new LocalizedException(__('No wallet token found'));
        }

        $walletData = $response['data'];
        $this->quoteHelper->updatePaydockHistory(['wallet_token_generated' => $walletData['charge']['_id']]);
        $this->quoteHelper->savePaydockWalletData($walletData);
        $this->quoteHelper->savePaydockCartData();

        return $walletData;
    }

    /**
     * Payload
     * @param Quote $quote
     * @return array
     * @throws LocalizedException
     */
    private function buildWalletChargePayload(Quote $quote): array {
        $paymentMethod = $quote->getPayment()->getMethod();
        $gatewayId = $this->configurationManagement->getGatewayIdByPayment($paymentMethod);

        if (empty($gatewayId)) {
            return [];
        }
        try {
            $store = $this->storeManager->getStore($quote->getStoreId());
        } catch (NoSuchEntityException $e) {
            throw new LocalizedException(__('Store not found'));
        }

        $storeName = $store->getName() ?: $quote->getStoreId();
        $payload = [
            'amount' => StoreHelper::formatAmount((float) $quote->getGrandTotal()),
            'currency' => $quote->getBaseCurrencyCode(),
            'reference' => $this->getReservedOrderId(),
            'meta' => [
                'store_id' => (string) $quote->getStoreId(),
                'store_name' => (string) $storeName,
            ],
            'customer' => [
                'payment_source' => [
                    'gateway_id' => $gatewayId
                ]
            ]
        ];

        if ($paymentMethod === "paydock_afterpay") {
            $checkoutUrl = $this->storeManager->getStore()->getCurrentUrl();

            $redirectMeta = [
                'checkout_url' => $checkoutUrl
            ];
            $payload['meta'] = array_merge($payload['meta'], $redirectMeta);
        }

        $customerData = [];
        $customerData['first_name'] = $quote->getCustomerFirstname();
        $customerData['last_name'] = $quote->getCustomerLastname();
        $customerData['email'] = $quote->getCustomerEmail();

        $billingAddress = $quote->getBillingAddress();
        $street = $billingAddress->getStreet();
        $streetFull = implode(", ", $street);
        $city = $billingAddress->getCity();
        $postcode = $billingAddress->getPostcode();
        $region = $billingAddress->getRegion();
        $countryId = $billingAddress->getCountryId();

        $paymentSourceAddress = [
            "address_line1" => $streetFull,
            "address_line1" => $streetFull,
            "address_city" => $city,
            "address_state" => $region,
            "address_country" => $countryId,
            "address_postcode" => $postcode,
        ];
        $paymentSourceAddress = array_filter($paymentSourceAddress);
        if (!empty($paymentSourceAddress)) {
            $payload['customer']['payment_source'] = array_merge($payload['customer']['payment_source'], $paymentSourceAddress);
        }

        $customerData = array_filter($customerData);
        if (!empty($customerData)) {
            $payload['customer'] = array_merge($payload['customer'], $customerData);
        }

        return $payload;
    }

    /**
     * @param OrderInterface $order
     * @param string $vaultToken
     * @return array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    private function buildChargePayload(OrderInterface $order, string $vaultToken): array {
        $paydockCustomerId = null;
        $payment = $order->getPayment();
        if ($this->paymentManagement->canSaveCard($payment) || $this->paymentManagement->isPaymentSources($payment)) {
            $customerId = $order->getCustomerId();
            if ($customerId) {
                $customer = $this->customerRepository->getById($customerId);
                $paydockCustomerIdAttribute = $customer->getCustomAttribute(PaydockCustomerInterface::CUSTOMER_ID);
                $paydockCustomerId = ($paydockCustomerIdAttribute?->getValue());
                if (empty($paydockCustomerId)) {
                    throw new LocalizedException(__('Error during capture request. Unable to retrieve paydock customer ID'));
                }
            }
        }

        $payload = [
            'amount' => $order->getBaseGrandTotal(),
            'currency' => $order->getBaseCurrencyCode(),
            'reference' => $this->getReservedOrderId(),
            'customer' => [
                'payment_source' => [
                    'vault_token' => $vaultToken,
                    'gateway_id' => $this->creditCardConfigurationManagement->getGatewayId()
                ]
            ]
        ];
        if ($paydockCustomerId) {
            $payload['customer_id'] = $paydockCustomerId;
        }

        return $payload;
    }

    /**
     * @inheritDoc
     * @throws LocalizedException
     */
    public function placeRefund(string $chargeId, float $amount, bool $fullRefund, ?int $storeId): array {
        $endpoint = sprintf(self::ENDPOINT_REFUNDS, $chargeId);

        $payload = [];
        if (!$fullRefund) {
            $payload['amount'] = $amount;
        }

        $response = $this->gatewayService->post($endpoint, $payload, [], $storeId);

        if ($response === null) {
            throw new LocalizedException(__("Error placing refund request"));
        }

        return $response;
    }

    /**
     * @param OrderInterface $order
     * @param string $vaultToken
     * @return array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    private function buildPaymentSourceDirectChargePayload(OrderInterface $order, string $vaultToken): array {
        $customerId = $order->getCustomerId();
        $customer = $this->customerRepository->getById($customerId);
        $paydockCustomerIdAttribute = $customer->getCustomAttribute(PaydockCustomerInterface::CUSTOMER_ID);
        $paydockCustomerId = ($paydockCustomerIdAttribute?->getValue());
        if (empty($paydockCustomerId)) {
            throw new LocalizedException(__('Error placing a payment source capture request. Unable to retrieve paydock customer ID'));
        }

        return [
            'amount' => $order->getBaseGrandTotal(),
            'currency' => $order->getBaseCurrencyCode(),
            'reference' => $this->getReservedOrderId(),
            'customer_id' => $paydockCustomerId
        ];
    }

    /**
     * @inheritDoc
     * @throws LocalizedException
     */
    public function directCharge(OrderInterface $order, string $vaultToken): array {
        $endpoint = self::ENDPOINT_DIRECT_CAPTURE;
        $chargePayload = $this->buildChargePayload($order, $vaultToken);
        $response = $this->gatewayService->post($endpoint, $chargePayload);

        if ($response === null) {
            throw new LocalizedException(__("Error placing Direct Charge request"));
        }

        return $response;
    }

    /**
     * @inheritDoc
     * @throws LocalizedException
     */
    public function paymentSourceDirectCharge(OrderInterface $order, string $vaultToken): array {
        $endpoint = self::ENDPOINT_DIRECT_CAPTURE;
        $chargePayload = $this->buildPaymentSourceDirectChargePayload($order, $vaultToken);
        $response = $this->gatewayService->post($endpoint, $chargePayload);

        if ($response === null) {
            throw new LocalizedException(__("Error placing Payment Source Direct Charge request"));
        }

        return $response;
    }

    /**
     * @inheritDoc
     * @throws LocalizedException
     */
    public function placeDirectChargeWith3dsChargeId(OrderInterface $order, string $charge3dsId): array {
        $endpoint = self::ENDPOINT_DIRECT_CAPTURE;
        $chargePayload = $this->buildChargePayload3ds($order, $charge3dsId);
        $response = $this->gatewayService->post($endpoint, $chargePayload);

        if ($response === null) {
            throw new LocalizedException(__("Error placing Direct Charge with 3DS request"));
        }

        return $response;
    }

    /**
     * @inheritDoc
     * @throws LocalizedException
     */
    public function placeDirectChargeWithVaultToken(OrderInterface $order, string $vaultToken): array {
        $endpoint = sprintf(self::ENDPOINT_DIRECT_CAPTURE, $vaultToken);
        $directCapturePayload = $this->buildDirectVaultTokenChargePayload($order, $vaultToken);
        $response = $this->gatewayService->post($endpoint, $directCapturePayload);

        if ($response === null) {
            throw new LocalizedException(__("Error placing Direct Charge with vault token  request"));
        }

        return $response;
    }

    /**
     * @param OrderInterface $order
     * @param string $charge3dsId
     * @return array
     */
    private function buildChargePayload3ds(OrderInterface $order, string $charge3dsId): array {
        return [
            'amount' => $order->getBaseGrandTotal(),
            'currency' => $order->getBaseCurrencyCode(),
            'reference' => $this->getReservedOrderId(),
            '_3ds' => [
                'id' => $charge3dsId
            ]
        ];
    }

    /**
     * @param OrderInterface $order
     * @param string $vaultToken
     * @return array
     */
    public function buildDirectVaultTokenChargePayload(OrderInterface $order, string $vaultToken): array {
        return [
            'amount' => $order->getBaseGrandTotal(),
            'currency' => $order->getBaseCurrencyCode(),
            'reference' => $this->getReservedOrderId(),
            'customer' => [
                'payment_source' => [
                    'vault_token' => $vaultToken,
                    'gateway_id' => $this->creditCardConfigurationManagement->getGatewayId()
                ]
            ]
        ];
    }

    /**
     * Verify Powerboard Wallet Charge
     * @return bool
     */
    public function verifyWalletCharge(array $walletData = []): bool
    {
        $this->paydockLogger->info('verifyWalletCharge::Verifying Paydock charge.');

        if (empty($walletData) || empty($walletData['charge_id'])  || empty($walletData['data']['charge']['amount'])) {

            $walletDataString = $this->quoteHelper->getPaydockWalletData();
            $this->paydockLogger->info('verifyWalletCharge::Retrieved wallet data.', ['wallet_data' => $walletDataString]);

            if (empty($walletDataString)) {
                $this->paydockLogger->error('verifyWalletCharge::Wallet data is null or empty.');
                return false;
            }

            $walletData = json_decode($walletDataString, true);

        }

        if ($walletData === null || empty($walletData['charge_id'])) {
            $this->paydockLogger->warning('verifyWalletCharge::Wallet data is null or charge ID is missing.');
            return false;
        }

        $chargeId = $walletData['charge_id'];
        $endpoint = self::ENDPOINT_DIRECT_CAPTURE . "/" . $chargeId;
        $this->paydockLogger->info('verifyWalletCharge::Calling Paydock API.', ['endpoint' => $endpoint]);

        $response = $this->gatewayService->get($endpoint);
        $this->paydockLogger->info('verifyWalletCharge::Received response from Paydock.', ['response' => $response]);

        if ($response === null || !isset($response['data'])) {
            $this->paydockLogger->error('verifyWalletCharge::Error verifying charge. Response is invalid.', ['response' => $response]);
            return false;
        }

        $chargeData = $response['data'];
        $this->paydockLogger->info('verifyWalletCharge::Charge data retrieved.', ['charge_data' => $chargeData]);

        return $chargeData['status'] == 'complete' && StoreHelper::formatAmount((float) $chargeData['amount']) === StoreHelper::formatAmount((float) $walletData['data']['charge']['amount']);
    }

    /**
     * Abandon Powerboard Wallet Charge
     * @return array
     */
    public function abandonWallet(): bool {
        $this->paydockLogger->info('abandonWallet');

        $walletDataString = $this->quoteHelper->getPaydockWalletData();
        $this->paydockLogger->info('abandonWallet::wallet data.', ['wallet_data' => $walletDataString]);

        $walletData = json_decode($walletDataString, true);

        if ($walletData === null || empty($walletData['charge_id'])) {
            $this->paydockLogger->warning('abandonWallet::Wallet data is null or charge ID is missing.');
            return false;
        }

        $chargeId = $walletData['charge_id'];
        $endpoint = sprintf(self::ENDPOINT_ABANDON_WALLET, $chargeId);

        $this->paydockLogger->info('abandonWallet::Calling Paydock API.', ['endpoint' => $endpoint]);

        $response = $this->gatewayService->post($endpoint);
        $this->paydockLogger->info('abandonWallet::Received response from Paydock.', ['response' => $response]);

        if ($response === null || !isset($response['data'])) {
            $this->paydockLogger->error('abandonWallet::Error abandoning charge. Response is invalid.', ['response' => $response]);
            return false;
        }

        $chargeData = $response['data'];
        $this->paydockLogger->info('abandonWallet::Charge data retrieved.', ['charge_data' => $chargeData]);

        $abandoned = $chargeData['status'] === 'abandoned';

        if ($abandoned) {
            $this->quoteHelper->clearPaydockWalletData();
            $this->quoteHelper->updatePaydockHistory(['wallet_token_abandoned' => $chargeId]);
        }

        return $abandoned;
    }

    /**
     * Get Reserved OrderId
     * @return string|null
     */
    private function getReservedOrderId(): string|null {
        try {
            $areaCode = $this->state->getAreaCode();
        } catch (LocalizedException $e) {
            $areaCode = '';
        }

        if ($areaCode === Area::AREA_ADMINHTML) {
            $this->sessionQuote->getQuote()->reserveOrderId()->save();
            $reservedOrderId = $this->sessionQuote->getQuote()->getReservedOrderId();
        } else {
            $this->checkoutSession->getQuote()->reserveOrderId()->save();
            $reservedOrderId = $this->checkoutSession->getQuote()->getReservedOrderId();
        }

        return $reservedOrderId;
    }
}
